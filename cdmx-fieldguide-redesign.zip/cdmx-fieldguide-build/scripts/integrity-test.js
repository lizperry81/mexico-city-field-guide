// Information-integrity scenarios. Run with the local server up:
//   python3 -m http.server 8765   then   node scripts/integrity-test.js
// Each scenario sets up a situation in a fresh browser profile and checks how the guide handles it.
const {chromium}=require('playwright');
const BASE=process.env.BASE||'http://localhost:8765/';
const res=[];const ok=(name,cond,detail)=>res.push([name,!!cond,detail||""]);
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:400,height:860}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.goto(BASE+'#home');await p.evaluate(()=>{try{localStorage.clear()}catch(e){}});await p.reload();await p.waitForTimeout(400);

 // 1. A historical claim with no source fails the content check
 const r1=await p.evaluate(()=>{const a=AD.centro.stops.zocalo;a.lead.push({p:["A test claim with no source."]});const r=runChecks();a.lead.pop();return r.unsourced.some(c=>c.text==="A test claim with no source.")});
 ok("Unsourced claim is caught by the content check",r1);

 // 2. Two credible sources disagreeing: the claim is shown as Scholarly debate
 await p.goto(BASE+'#museum-mna');await p.waitForTimeout(300);
 ok("Disputed interpretation shows as Scholarly debate",(await p.textContent('#main')).includes('Scholarly debate'));

 // 3. A disputed interpretation presented as fact: established claims resting on journalism only are downgraded to Reported
 const r3=await p.evaluate(()=>{const c=claimRegistry().find(c=>c.tag==="est"&&c.src.length&&!evidenceStrong(c.src));return c?{cls:c.cls,html:tagHTML(c.tag,c.src)}:null});
 ok("Journalism-only 'established' claim is labeled Reported",r3&&r3.cls==="rep"&&r3.html.includes("Reported"),JSON.stringify(r3));

 // 4. An outdated review is labeled as possibly out of date
 const r4=await p.evaluate(()=>{const c=submitContribution({place:"templo",type:"museum",f:{time:"Two hours was enough for the museum and ruins."},rating:4,visit:"2023-03",commercial:false});c.status="approved";return contribAge(c)});
 ok("Old community report is flagged as possibly out of date",/may be out of date/.test(r4),r4);

 // 5. A restaurant reported closed: pending until reviewed, then shown as a community report that conflicts with editorial info
 const r5=await p.evaluate(()=>{const k="food:centro:Café de Tacuba";const c=submitContribution({place:k,type:"closed",f:{what:"Shutters down and a sign saying closed for renovation."},visit:"2026-11",commercial:false});const before=visibleContribs(k).length;c.status="approved";return {st:c.flags.length?"flagged":"pending",before,after:visibleContribs(k).length,html:contribHTML(c,true)}});
 ok("Closed report is not shown before moderation",r5.before===0);
 ok("Approved closed report appears with a conflict note",r5.after===1&&r5.html.includes("differs from the guide's editorial information"));

 // 6. A suspicious cluster of five-star reviews is flagged, not published
 const r6=await p.evaluate(()=>{const out=[];for(let i=0;i<3;i++)out.push(submitContribution({place:"postal",type:"museum",f:{worth:"Amazing amazing place number "+i+", the best ever."},rating:5,visit:"2026-11",commercial:false}));return out.map(c=>c.status+": "+c.flags.join("|"))});
 ok("Third five-star review in 24h is flagged as a suspicious pattern",/Suspicious pattern/.test(r6[2]),r6.join(" / "));

 // 7. An unverified allegation is held for moderation
 const r7=await p.evaluate(()=>{const c=submitContribution({place:"food:centro:Café de Tacuba",type:"restaurant",f:{know:"The waiter scammed us and stole our change."},rating:1,visit:"2026-10",commercial:false});return c});
 ok("Unverified allegation is flagged",r7.status==="flagged"&&r7.flags.some(f=>/allegation/.test(f)),r7.flags.join("|"));
 // promotional content without disclosure
 const r7b=await p.evaluate(()=>submitContribution({place:"bellas",type:"museum",f:{worth:"Follow us for a discount on tours, use code BELLAS."},rating:5,visit:"2026-11",commercial:false}).flags);
 ok("Undisclosed promotion is flagged",r7b.some(f=>/Promotional/.test(f)),r7b.join("|"));
 // duplicate
 const r7c=await p.evaluate(()=>submitContribution({place:"templo",type:"museum",f:{time:"Two hours was enough for the museum and ruins."},rating:4,visit:"2026-11",commercial:false}).flags);
 ok("Duplicate contribution is flagged",r7c.some(f=>/Duplicate/.test(f)),r7c.join("|"));

 // 8. An AI answer that cannot be substantiated: the "How do we know?" panel says so
 const r8=await p.evaluate(()=>{const a={q:"x",text:"Something with no citations at all.",notes:[{title:"t",kind:"k",area:"a",text:"n",src:[],tag:"est"}],used:new Set()};return howKnowAnswer(a)});
 ok("Uncited AI answer is labeled as unverified",/cites none of the guide's notes/.test(r8));
 const r8b=await p.evaluate(()=>{const a={q:"x",text:"Fact [1]. Beyond the guide: something else.",notes:[{title:"t",kind:"k",area:"a",text:"n",src:["inah4463"],tag:"est"}],used:new Set([0])};return howKnowAnswer(a)});
 ok("'Beyond the guide' content is called out",/general knowledge from outside the guide/.test(r8b));
 const r8c=await p.evaluate(()=>systemFor([],false));
 ok("AI instructions forbid unsupported answers and separate kinds of information",/doesn't have enough evidence/.test(r8c)&&/Community report/.test(r8c)&&/never generalize one report/.test(r8c));

 // 9. A museum with temporarily changed hours: a community practical update is shown beside, not instead of, the editorial hours
 const r9=await p.evaluate(()=>{const c=submitContribution({place:"bellas",type:"logistics",f:{changes:"Closed early at 14:00 for an event; hours changed this week."},visit:"2026-12",commercial:false});c.status="approved";return contribHTML(c,true)});
 ok("Changed-hours report is marked as conflicting and unverified",r9.includes("differs from the guide's editorial information")&&r9.includes("self-reported"));

 // 10. Freshness labels come from real source dates, never invented
 const r10=await p.evaluate(()=>{const old=Object.keys(SRC).find(k=>srcDate(k)&&srcDate(k).y<2024);const none=freshness([],"x");return {old:old?freshness([old],"x").t:null,none:none.t,verified:VERIFY.length}});
 ok("Old source is labeled likely out of date",r10.old&&/likely out of date/.test(r10.old),r10.old);
 ok("Missing source is labeled verification needed",/Verification needed/.test(r10.none));
 ok("No verification is claimed without a logged check",r10.verified===0,"verification log entries: "+r10.verified);

 // UI: the community block, How do we know page and dashboard render
 await p.goto(BASE+'#stop-templo');await p.waitForTimeout(300);ok("Place page shows community reports separately",(await p.textContent('.community'))||false);
 await p.goto(BASE+'#howknow');await p.waitForTimeout(300);ok("How do we know page renders",(await p.textContent('h1')).includes('How the guide knows'));
 await p.goto(BASE+'#editorial');await p.waitForTimeout(400);const ed=await p.textContent('#main');
 ok("Dashboard shows a moderation queue with flagged items",/Moderation queue \(\d+\)/.test(ed)&&ed.includes('Suspicious pattern'));
 ok("Dashboard reports zero human-reviewed articles honestly",ed.includes('Articles reviewed by a person')&&ed.includes('0 so far'));
 await p.fill('#claimQ','Sun Stone');await p.click('#claimForm button');await p.waitForTimeout(300);ok("Claim inspector finds claims with sources and tiers",(await p.$$('.claimrow')).length>0&&(await p.textContent('.claimrow')).includes('Tier'));
 ok("No page errors",!errs.length,errs.join(" | "));

 const pass=res.filter(r=>r[1]).length;
 res.forEach(([n,c,d])=>console.log((c?"PASS ":"FAIL ")+n+(d&&!c?"  ("+d+")":"")));
 console.log(`\n${pass} of ${res.length} scenarios pass`);await b.close();process.exit(pass===res.length?0:1)})();
