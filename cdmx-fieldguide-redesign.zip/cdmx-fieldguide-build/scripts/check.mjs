#!/usr/bin/env node
/* Content checks from the command line. Run before publishing:
     node scripts/check.mjs           check sources, tags, food rule, freshness
     node scripts/check.mjs --links   also test that every source URL still responds (needs internet)
   Exits with code 1 if any claim is unsourced, any source reference is broken, or a stop misses the standard. */
import fs from "node:fs";
import vm from "node:vm";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = p => fs.readFileSync(path.join(root, p), "utf8");
const core = JSON.parse(read("data/core.json"));
const AD = {};
for (const a of core.areas.filter(a => a.file)) AD[a.id] = JSON.parse(read("data/" + a.file));

const ctx = { CHECKED: core.checked, SRC: core.sources, AD, THREADS: core.threads || [], SEASON: core.season || null, BASICS: core.basics || null, TRIPBOOK: core.tripBook || [], GLOSSARY: core.glossary || [], NIGHT: core.night || [], CTX: core.ctx || [], Date };
vm.createContext(ctx);
vm.runInContext(read("js/checks.js") + ";globalThis.__r=runChecks();", ctx);
const r = ctx.__r;

const ok = s => console.log("  PASS  " + s), note = s => console.log("  NOTE  " + s), fail = s => console.log("  FAIL  " + s);
console.log(`\nContent checks: ${r.total} claims, ${Object.keys(core.sources).length} sources, ${Object.keys(AD).length} areas\n`);
r.unsourced.length ? fail(`${r.unsourced.length} unsourced claim(s): ${r.unsourced.map(c => c.where + ': "' + c.text.slice(0, 60) + '…"').join("; ")}`) : ok("Every claim has a source or is tagged Unknown");
r.opinionOnly.length ? fail(`Facts resting only on forums or blogs: ${[...new Set(r.opinionOnly.map(c => c.where))].join(", ")}`) : ok("No fact rests only on forums or travel blogs");
r.missingIds.length ? fail(`Broken source references: ${[...new Set(r.missingIds)].join(", ")}`) : ok("Every source reference resolves");
r.journalismOnly.length ? note(`Established claims resting only on journalism: ${[...new Set(r.journalismOnly.map(c => c.where))].join(", ")}`) : ok("No Established claim rests only on journalism");
r.oneSourceFood.length ? note(`Food picks with one critic source: ${r.oneSourceFood.map(f => f.name).join(", ")}`) : ok("Every food pick has two critic sources");
r.stale ? note(`Facts last checked ${r.age} days ago (${core.checked}); recheck before the trip`) : ok(`Facts checked ${r.age <= 0 ? "today" : r.age + " day(s) ago"} (${core.checked})`);
r.unusedSrc.length ? note(`Unused sources: ${r.unusedSrc.join(", ")}`) : ok("Every listed source is used");
r.stdFail.length ? fail(`Stop standards not met (${r.stdFail.length}): ${r.stdFail.join("; ")}`) : ok("Every stop and walk meets the standard");
r.stdThin.length ? note(`Thin spots (${r.stdThin.length}): ${r.stdThin.join("; ")}`) : ok("No thin stops");
console.log(`  INFO  ${r.deb} Debated, ${r.unk} Unknown`);

let linkFail = 0;
if (process.argv.includes("--links")) {
  console.log("\nLink check:");
  for (const [id, s] of Object.entries(core.sources)) {
    try {
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
      let res = await fetch(s.u, { method: "HEAD", redirect: "follow", signal: ctl.signal });
      if (res.status === 405 || res.status === 403) res = await fetch(s.u, { method: "GET", redirect: "follow", signal: ctl.signal });
      clearTimeout(t);
      if (res.ok) console.log(`  ok    ${id}`); else { linkFail++; console.log(`  ${res.status}   ${id}  ${s.u}`); }
    } catch (e) { linkFail++; console.log(`  ERR   ${id}  ${s.u}  (${e.name})`); }
  }
  console.log(linkFail ? `\n${linkFail} link(s) need a look. Some sites block automated checks; open those by hand.` : "\nAll links respond.");
}

const hardFail = r.stdFail.length || r.unsourced.length || r.missingIds.length || r.opinionOnly.length;
console.log(hardFail ? "\nResult: FAIL\n" : "\nResult: PASS\n");
process.exit(hardFail ? 1 : 0);
