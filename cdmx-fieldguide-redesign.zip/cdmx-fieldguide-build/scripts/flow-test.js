// Flow tests: every walk from its start page through every stop to the recap,
// the look-and-find checklist, mode switching, and the place filters.
// Run: python3 -m http.server 8765 (in the project folder), then node scripts/flow-test.js
const {chromium}=require('playwright');
const fs=require('fs');
const BASE=process.env.BASE||'http://localhost:8765/';
const areas=JSON.parse(fs.readFileSync(__dirname+'/../data/core.json')).areas;
const fails=[];const ok=(c,m)=>{if(!c)fails.push(m)};
(async()=>{
 const b=await chromium.launch();const p=await b.newPage({viewport:{width:400,height:860}});
 const errs=[];p.on('pageerror',e=>errs.push(e.message+' @'+p.url()));
 await p.goto(BASE);await p.evaluate(()=>{try{localStorage.clear()}catch(e){}});await p.reload();await p.waitForTimeout(300);
 let walks=0,stops=0;
 for(const a of areas){const d=JSON.parse(fs.readFileSync(__dirname+'/../data/'+a.file));
  for(const w of d.walks){walks++;
   await p.goto(BASE+'#start-'+w.id);await p.waitForTimeout(250);
   ok(await p.$('[data-walkgo]'),w.id+': no Start button');
   ok((await p.textContent('body')).includes(w.q),w.id+': guiding question not on start page');
   ok(await p.$('text=Effort and comfort'),w.id+': no effort section');
   await p.click('[data-walkgo]');await p.waitForTimeout(250);
   const list=await p.evaluate(id=>walkStops(walkById(id)),w.id);// the app drops optional stops unless chosen
   for(let i=0;i<list.length;i++){stops++;const sid=list[i],st=d.stops[sid];
    const cnt=await p.textContent('.wbcount');ok(cnt&&cnt.includes(`Stop ${i+1} of ${list.length}`),`${w.id} stop ${i+1}: walkbar says "${cnt}"`);
    const site=await p.$('[data-mode="site"][aria-pressed="false"]');if(site){await site.click();await p.waitForTimeout(120)}
    const finds=await p.$$('.findbtn');ok(finds.length===(st.find||[]).length,`${w.id}/${sid}: ${finds.length} find items, expected ${(st.find||[]).length}`);
    if(finds.length){await finds[0].click();ok(await finds[0].getAttribute('aria-pressed')==='true',`${w.id}/${sid}: find item didn't tick`);await finds[0].click()}
    ok(!st.spot||(await p.$('.spot')),`${w.id}/${sid}: spot line missing`);
    const rd=await p.$('[data-mode="read"][aria-pressed="false"]');if(rd){await rd.click();await p.waitForTimeout(120);ok(await p.$('h2.lsec'),`${w.id}/${sid}: Read ahead has no sections`)}
    const go=await p.$(`[data-walk="${w.id}"][data-step="${i+1}"]`);
    if(i<list.length-1){ok(go,`${w.id}/${sid}: no "I'm there" button`);if(!go)break;await go.click();await p.waitForTimeout(220)}
   }
   ok(await p.$('.recap'),w.id+': recap missing at the end');
   ok((await p.textContent('.recap')||'').includes(w.q),w.id+': recap does not repeat the question');
  }}
 // place filters
 await p.goto(BASE+'#explore');await p.waitForTimeout(300);
 ok(await p.$('#topplaces'),'Explore: no top places');
 for(const f of ['must','high','ta45','all']){const x=await p.$(`[data-sfilt="${f}"]`);if(!x){fails.push('Explore: no filter '+f);continue}
  await x.click();await p.waitForTimeout(200);const n=(await p.$$('#topplaces .site-card, #topplaces .placecard, #topplaces button.nowitem, #topplaces article')).length;ok(n>0,'Explore filter '+f+' shows nothing')}
 for(const a of areas){await p.goto(BASE+'#'+a.id);await p.waitForTimeout(200);const t=await p.$('[data-tab="more"]');if(t){await t.click();await p.waitForTimeout(200);ok((await p.textContent('main')||'').length>200,a.id+': All places empty')}}
 // search
 await p.goto(BASE+'#around');await p.waitForTimeout(250);const s=await p.$('input[type="search"]');
 if(s){await s.fill('mayor');await p.waitForTimeout(300);ok((await p.textContent('body')).includes('Templo Mayor'),'Search "mayor" does not find the Templo Mayor')}else fails.push('Today: no search box');
 // Today: plan for a date, then "Next on your plan" and "Nearest place"
 await p.goto(BASE+'#trip');await p.waitForTimeout(250);
 await p.evaluate(()=>{S.start=mxDateKey();S.plan={};save();render()});await p.waitForTimeout(200);
 const dayChip=await p.$('[data-day]');if(dayChip){await dayChip.click();await p.waitForTimeout(250);
  const pl=await p.$('[data-plan]');if(pl){await pl.click();await p.waitForTimeout(200)}}
 await p.evaluate(()=>{setHere([19.4326,-99.1332],"Zócalo",true)});
 await p.goto(BASE+'#around');await p.waitForTimeout(300);
 const today=await p.textContent('main')||'';
 ok(/Next on your plan|Your plan today|Nothing planned/.test(today),'Today: no plan block');
 ok(today.includes("Nearest place you haven't seen"),'Today: no nearest place with a location set');
 ok(!errs.length,'Page errors: '+errs.join(' | '));
 // Field Guide: home, every story, every question, museums, missions, time machine
 const SD=JSON.parse(fs.readFileSync(__dirname+'/../data/stories.json'));
 await p.goto(BASE+'#home');await p.waitForTimeout(300);
 ok((await p.textContent('main')).includes('A city built on the ruins of another'),'Home: no cover headline');
 ok(await p.$('.bigqbtn'),'Home: no big question');
 for(const st of SD.stories){await p.goto(BASE+'#story-'+st.id);await p.waitForTimeout(200);const n=(await p.$$('.chapter')).length;ok(n>=1,'Story '+st.id+': no chapters rendered');ok((await p.textContent('h1'))===st.title,'Story '+st.id+': wrong title')}
 for(const q of SD.questions){await p.goto(BASE+'#q-'+q.id);await p.waitForTimeout(150);ok((await p.$$('.chapter')).length>=2,'Question '+q.id+': too few places')}
 for(const m of SD.museums){await p.goto(BASE+'#museum-'+m.id);await p.waitForTimeout(150);ok(m.gap||(await p.$$('.objcase')).length>=1,'Museum '+m.id+': no objects')}
 for(let i=0;i<SD.time.length;i++){await p.goto(BASE+'#time');await p.waitForTimeout(150);await p.click(`[data-timei="${i}"]`);await p.waitForTimeout(150);ok((await p.$$('#main .placerow')).length>=2,'Time machine '+SD.time[i].y+': no places')}
 // journal: save a story, write a note, record a mission observation
 await p.goto(BASE+'#story-conquest');await p.waitForTimeout(200);await p.click('[data-jsave]');await p.waitForTimeout(100);
 await p.goto(BASE+'#journal');await p.waitForTimeout(200);ok((await p.textContent('main')).includes('The Spanish conquest'),'Journal: saved story missing');
 await p.fill('.jnote textarea','The cathedral floor really does tilt.');await p.click('.jnote button[type=submit]');await p.waitForTimeout(200);
 ok((await p.textContent('main')).includes('really does tilt'),'Journal: note not saved');
 await p.goto(BASE+'#mission-urban');await p.waitForTimeout(200);await p.fill('[data-jobs="urban.0"] textarea','Extra steps at the Ángel');await p.click('[data-jobs="urban.0"] button[type=submit]');await p.waitForTimeout(200);
 ok(await p.$('.mcheck[aria-pressed="true"]'),'Mission: observation did not mark the item');
 await p.reload();await p.waitForTimeout(400);ok((await p.inputValue('[data-jobs="urban.0"] textarea'))==='Extra steps at the Ángel','Mission: observation lost on reload');
 // walking professor: three modes on a place page
 await p.goto(BASE+'#stop-templo');await p.waitForTimeout(250);
 for(const m of ['look','deeper','story']){await p.click(`[data-pmode="${m}"]`);await p.waitForTimeout(150);ok((await p.textContent('#profbody')).trim().length>200,'Professor '+m+': empty')}
 await p.click('[data-pmode="look"]');await p.waitForTimeout(150);ok(await p.$('#profbody .findbtn'),'Professor look: no find list');
 // ask: modes and lengths switch
 await p.goto(BASE+'#ask');await p.waitForTimeout(200);await p.click('[data-askmode="skeptic"]');await p.waitForTimeout(100);await p.click('[data-asklen="research"]');await p.waitForTimeout(100);
 ok((await p.textContent('h1')).includes('Skeptical'),'Ask: mode did not switch');ok(await p.$('[data-asklen="research"][aria-checked="true"]'),'Ask: length did not switch');
 // nav tabs
 for(const t of ['field','journal','around','stories']){await p.click(`.bar [data-nav="${t}"]`);await p.waitForTimeout(200);ok(await p.$(`.bar [data-nav="${t}"][aria-current="true"]`),'Tab '+t+' not current')}
 // Your photo: add, survives reload, remove
 await p.goto(BASE+'#stop-zocalo');await p.waitForTimeout(300);{const x=await p.$('[data-mode="site"][aria-pressed="false"]');if(x){await x.click();await p.waitForTimeout(200)}}
 const png=await p.screenshot({clip:{x:0,y:0,width:200,height:150}});
 const fin=await p.$('[data-photoin]');if(fin){await fin.setInputFiles({name:'me.png',mimeType:'image/png',buffer:png});await p.waitForTimeout(800);
  ok(await p.$('img.myph'),'Photo: not shown after adding');await p.reload();await p.waitForTimeout(700);ok(await p.$('img.myph'),'Photo: gone after reload');
  await p.click('[data-photodel]');await p.waitForTimeout(500);ok(!(await p.$('img.myph')),'Photo: not removed')}
 // Learn: the 1519 lake diagram renders
 await p.goto(BASE+'#ctx-mexica');await p.waitForTimeout(300);ok(await p.$('svg[aria-label^="Sketch map of the lake"]'),'Learn: lake diagram missing on the Mexica background');
 // Offline: load once so the service worker caches everything, then cut the network
 const ctx=await b.newContext({viewport:{width:400,height:860}});const q=await ctx.newPage();q.on('pageerror',e=>errs.push(e.message+' (offline)'));
 await q.goto(BASE);await q.evaluate(()=>navigator.serviceWorker&&navigator.serviceWorker.ready);await q.reload();await q.waitForTimeout(600);
 ok(await q.evaluate(()=>!!(navigator.serviceWorker&&navigator.serviceWorker.controller)),'Offline: service worker not controlling the page');
 await ctx.setOffline(true);
 for(const h of ['home','start-tenoch','walk-tenoch-3','explore','learn','trip']){await q.goto(BASE+'#'+h).catch(e=>fails.push('Offline: '+h+' failed to load: '+e.message));await q.waitForTimeout(350);
  ok(((await q.textContent('main').catch(()=>''))||'').length>200,'Offline: '+h+' rendered nothing')}
 ok(await q.$('#offbar'),'Offline: no offline notice');
 await ctx.setOffline(false);await q.waitForTimeout(200);ok(!(await q.$('#offbar')),'Offline notice stayed after reconnecting');
 ok(!errs.length,'Page errors: '+errs.join(' | '));
 console.log(`Flow tests: ${walks} walks, ${stops} stops`);
 console.log(fails.length?'FAIL\n - '+fails.join('\n - '):'Result: PASS');
 await b.close();process.exit(fails.length?1:0)})();
