/* Offline support: serve the app and its data from the cache, refresh in the background.
   Bump VERSION whenever you publish new content so phones pick it up. */
const VERSION = "cdmx-fieldguide-v48";
const TILES = "cdmx-tiles-v1";      /* map pieces you have viewed, kept for offline use */
const TILE_MAX = 1500;
const ASSETS = [
  "./", "index.html", "styles.css",
  "js/art.js", "js/storage.js", "js/checks.js", "js/map.js", "js/trip.js", "js/now.js", "js/ai.js", "js/terms.js", "js/ask.js", "js/phase2.js", "js/phase3.js", "js/learn.js", "js/app.js", "js/stories.js", "js/journal.js", "js/field.js", "js/integrity.js",
  "data/core.json", "data/centro.json", "data/chapul.json", "data/teo.json", "data/tlatelolco.json", "data/coyo.json", "data/roma.json", "data/south.json", "data/sanangel.json", "data/reforma.json", "data/stories.json", "data/verify.json",
  "manifest.webmanifest", "icon.svg", "icon-180.png", "icon-512.png"
];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(k => k !== VERSION && k !== TILES).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  const isFont = url.hostname === "fonts.googleapis.com" || url.hostname === "fonts.gstatic.com";
  const isLib = url.hostname === "cdnjs.cloudflare.com";
  /* Map tiles: only tiles you actually view are kept (no prefetching), capped at TILE_MAX,
     so areas you browsed on Wi-Fi still show offline. OpenStreetMap asks clients to cache, not to bulk-download. */
  if (url.hostname === "tile.openstreetmap.org") {
    e.respondWith(caches.open(TILES).then(async c => {
      const hit = await c.match(req);
      if (hit) return hit;
      const res = await fetch(req);
      if (res.ok) { c.put(req, res.clone()); c.keys().then(k => { if (k.length > TILE_MAX) k.slice(0, k.length - TILE_MAX).forEach(r => c.delete(r)); }); }
      return res;
    }));
    return;
  }
  if (url.origin !== location.origin && !isFont && !isLib) return;
  e.respondWith(caches.match(req).then(hit => {
    const fresh = fetch(req).then(res => {
      if (res.ok || res.type === "opaque") { const copy = res.clone(); caches.open(VERSION).then(c => c.put(req, copy)); }
      return res;
    }).catch(() => hit);
    return hit || fresh;
  }));
});
