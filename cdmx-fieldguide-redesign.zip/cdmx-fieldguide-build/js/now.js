/* "Right now": reacts to the time in Mexico City, where you are (S.here), your trip dates and
   what you've visited. Location comes from the phone (standalone app, with permission), from
   "I'm here" on a map pin, from typing a place, or automatically from the current walk stop. */
const WALK_M_PER_MIN=80;
function hav(a,b){const R=6371000,t=x=>x*Math.PI/180,dl=t(b[0]-a[0]),dg=t(b[1]-a[1]);const h=Math.sin(dl/2)**2+Math.cos(t(a[0]))*Math.cos(t(b[0]))*Math.sin(dg/2)**2;return 2*R*Math.asin(Math.sqrt(h))}
const walkMin=m=>Math.max(1,Math.round(m/WALK_M_PER_MIN));
const distText=m=>m<1500?`${walkMin(m)} min walk`:`${(m/1000).toFixed(1)} km`;
const fmtDur=h=>{const m=Math.round(h*60);return m<60?`${m} min`:`${Math.floor(m/60)} h${m%60?` ${m%60} min`:""}`};
function mxDateKey(){try{const p=new Intl.DateTimeFormat("en-CA",{timeZone:"America/Mexico_City",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date());return p}catch(e){return new Date().toISOString().slice(0,10)}}
function tripDayIndex(){const a=new Date(S.start+"T12:00:00"),b=new Date(mxDateKey()+"T12:00:00");return Math.round((b-a)/864e5)}

/* every place with a position and (if known) hours */
function nowPlaces(){const out=[];
 for(const aid in AD){const a=AD[aid];
  a.sites.forEach(s=>{if(!s.ll||s.link)return;const ws=Object.keys(a.stops).find(k=>a.stops[k].siteRef===s.id);out.push({id:ws||s.id,open:ws?`data-stop="${ws}"`:`data-more="${s.id}"`,name:s.name,area:aid,ll:s.ll,hours:s.hours,outdoor:s.outdoor,visited:S.visited.includes(s.id)||(ws&&S.visited.includes(ws))})});
  for(const k in a.stops){const st=a.stops[k];if(st.siteRef||!st.ll)continue;out.push({id:k,open:`data-stop="${k}"`,name:st.name,area:aid,ll:st.ll,hours:st.hours,outdoor:st.outdoor,visited:S.visited.includes(k)})}}
 return out}
function placeStatus(x,n){
 if(x.outdoor)return {s:"open",t:"Open-air"};
 if(!x.hours)return {s:"unk",t:"Hours not published"};
 if(!x.hours.days.includes(n.dow))return {s:"closed",t:"Closed today"};
 const r=(n.dow===0&&x.hours.sun)||(n.dow===6&&x.hours.sat)||x.hours.h;
 const on=r.find(([a,b])=>n.h>=a&&n.h<b);if(on)return {s:"open",t:`Open · closes in ${fmtDur(on[1]-n.h)}`,soon:on[1]-n.h<=1};
 const next=r.find(([a])=>n.h<a);if(next)return {s:"later",t:`Opens at ${fmtH(next[0])}`};
 return {s:"closed",t:"Closed for today"}}
function foodStatus(f,n){if(!f.hours)return null;if(f.days&&!f.days.includes(n.dow))return {s:"closed",t:"Closed today"};
 const on=f.hours.find(([a,b])=>n.h>=a&&n.h<b);if(on)return {s:"open",t:on[0]===0&&on[1]===24?"Open 24 hours":`Open · closes in ${fmtDur(on[1]-n.h)}`};
 const next=f.hours.find(([a])=>n.h<a);return next?{s:"later",t:`Opens at ${fmtH(next[0])}`}:{s:"closed",t:"Closed for today"}}
const statusPill=st=>`<span class="pill ${st.s==="open"?(st.soon?"warn":"ok"):st.s==="later"?"warn":st.s==="unk"?"":"no"}">${esc(st.t)}</span>`;

function setHere(ll,label,quiet){S.here={ll,label,t:Date.now()};save();if(!quiet&&cur().v==="areas")render()}
function hereFresh(){return S.here&&S.here.ll&&(Date.now()-(S.here.t||0))<8*3600e3}
function nearestArea(ll){let best=null;AREAS.filter(a=>AD[a.id]).forEach(a=>{const d=hav(ll,a.c);if(!best||d<best.d)best={a,d}});return best}

let INTENT=null,SEEF=null;
const ICONS={walk:'<path d="M13 4.5a1.5 1.5 0 1 0 0-.01M10 21l2-6 2.5 2V21M8 12l3-4 3 2 2 3M11 8l-1.5 5"/>',see:'<path d="M3 20h18M5 20v-8M9 20v-8M15 20v-8M19 20v-8M3 10l9-6 9 6z"/>',eat:'<path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10M17 3c-2 0-3 2-3 5s1 4 3 4v9M17 3v18"/>',drink:'<path d="M6 4h12l-1.5 7a4.5 4.5 0 0 1-9 0zM12 15.5V20M8.5 20h7"/>',relax:'<path d="M12 21v-6M12 15c-4 0-6-2.5-5-5.5.5-1.8 2.2-2.7 3.3-2.7.7-2 3.4-2.4 4.3-.4 2.3 0 3.6 2.5 2.7 4.6 1.3 2.5-.9 4-5.3 4zM5 21h14"/>',learn:'<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5zM4 20.5A2.5 2.5 0 0 0 6.5 23H20M9 8h7M9 12h5"/>'};
const MOON='<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>';
const INTENTS=[["walk","Walk"],["see","See"],["eat","Eat"],["drink","Drink"],["relax","Relax"],["learn","Learn"]];
function ctxNow(){const n=mxNow(),here=hereFresh()?S.here:null;const na=here?nearestArea(here.ll):null;return {n,here,areaId:na&&na.d<na.a.r*2.5?na.a.id:null}}
const RANK={open:0,later:1,unk:2,closed:3};
function placesNow(c){return nowPlaces().map(p=>{const st=placeStatus(p,c.n),d=c.here?hav(c.here.ll,p.ll):null;const meta=(getStop(p.id)||siteById(p.id)||{});return {...p,st,d,types:meta.types||[]}})}
const byNear=c=>(a,b)=>(RANK[a.st.s]-RANK[b.st.s])*(c.here?0.6:1)+(c.here?(a.d-b.d)/1500:(a.area===c.areaId?0:1)-(b.area===c.areaId?0:1));
function foodAll(c){const out=[];for(const aid in AD)AD[aid].food.forEach(f=>out.push({f,area:aid,st:foodStatus(f,c.n)||{s:"unk",t:"Hours not published"}}));return out}
const foodSort=c=>(a,b)=>((a.area===c.areaId?0:2)-(b.area===c.areaId?0:2))+(RANK[a.st.s]-RANK[b.st.s]);
function mealNow(n){const m=Object.entries(MEALS).find(([,r])=>n.h>=r[0]-1&&n.h<r[1]);return m?m[0]:n.h<MEALS.breakfast[0]?"breakfast":n.h<MEALS.lunch[0]?"lunch":"dinner"}
const where=(p,c)=>p.d!=null?distText(p.d):esc(AD[p.area].name);
function row(btn,name,pills,sub){return `<button class="nowitem" ${btn}><span class="nowname">${name}</span><span class="nowmeta">${pills}</span>${sub?`<span class="hint">${sub}</span>`:""}</button>`}
function walkInfo(w,c){const ws=walkStops(w),done=ws.filter(s=>S.visited.includes(s)).length,nx=ws.findIndex(s=>!S.visited.includes(s));const issues=[];
 ws.forEach(s=>{const st=getStop(s);if(!st.hours)return;const ps=placeStatus({hours:st.hours},c.n);if(ps.s==="closed")issues.push(`${st.name}: ${ps.t.toLowerCase()}`);else if(ps.s==="open"&&ps.soon)issues.push(`${st.name} ${ps.t.split(" · ")[1]}`)});
 const llOf=st=>st&&(st.ll||(siteById(st.siteRef)||{}).ll);const first=getStop(ws[Math.max(0,nx)]),ll=llOf(first),d=c.here&&ll?hav(c.here.ll,ll):null;
 let near=null;if(c.here)ws.forEach((s,j)=>{const l=llOf(getStop(s));if(!l)return;const dj=hav(c.here.ll,l);if(!near||dj<near.d)near={j,d:dj,name:getStop(s).name}});
 return {ws,done,nx,issues,d,first,near}}
function counts(c){const pl=placesNow(c),near=p=>!c.here||p.d<2500;
 const see=pl.filter(p=>p.st.s==="open"&&!p.outdoor&&near(p)).length,fa=foodAll(c);
 const eat=fa.filter(x=>x.st.s==="open"&&(!c.areaId||x.area===c.areaId)).length;
 let drink=fa.filter(x=>x.f.types.some(t=>t==="Bars and mezcal"||t==="Cafés and sweets")&&x.st.s!=="closed"&&(!c.areaId||x.area===c.areaId)).length;
 const relax=pl.filter(p=>p.types.includes("Parks and gardens")).length+fa.filter(x=>x.f.types.includes("Cafés and sweets")).length;
 let walk="";for(const aid in AD)for(const w of AD[aid].walks){const i=walkInfo(w,c);if(i.done>0&&i.nx>=0)walk="Continue"}
 const nw=Object.values(AD).reduce((s,a)=>s+a.walks.length,0);
 if(isEvening(c.n)){const k=mxDateKey().slice(5),tn=NIGHT.filter(x=>x.kind==="Show"&&inSeason(x,k)&&(nextShow(x,c.n)||{}).today).length;drink=null;var nightC=tn?`${tn} show${tn>1?"s":""} tonight`:"Bars, music, shows"}
 return {walk:walk||`${nw} walks`,see:`${see} open${c.here?" nearby":""}`,eat:eat?`${eat} open now`:"See picks",drink:nightC||(drink?`${drink} options`:"See picks"),relax:`${relax} place${relax===1?"":"s"}`,learn:"Ask or read"}}
function intentOut(k,c){const n=c.n;
 if(k==="walk"){const fh=(rainy()?rainPlan(c):"")+freeHTML(c);const list=[];for(const aid in AD)for(const w of AD[aid].walks)list.push([aid,w,walkInfo(w,c)]);
  list.sort((a,b)=>((b[2].done>0&&b[2].nx>=0)-(a[2].done>0&&a[2].nx>=0))||((a[0]===c.areaId?0:1)-(b[0]===c.areaId?0:1))||((a[2].d||0)-(b[2].d||0)));
  return fh+list.map(([aid,w,i])=>{const cont=i.done>0&&i.nx>=0,fin=i.nx<0;const pill=fin?`<span class="pill ok">Done</span>`:i.issues.length?`<span class="pill warn">${esc(i.issues[0])}</span>`:`<span class="pill ok">All stops open today</span>`;
   const join=!cont&&!fin&&i.near&&i.near.j>0&&i.near.d<700;
   return row(cont?`data-walk="${w.id}" data-step="${i.nx}"`:`data-walkfrom="${w.id}:${join?i.near.j:0}"`,esc(w.name),`${pill}<span class="hint">${esc(AD[aid].name)} · ${esc(w.time.replace("About ","~"))}</span>`,cont?`Continue at stop ${i.nx+1}: ${esc(i.first.name)}${i.d!=null?` (${distText(i.d)})`:""}`:join?`You're by stop ${i.near.j+1}, ${esc(i.near.name)} (${distText(i.near.d)}): start here and loop through the rest`:`${i.ws.length} stops · ${i.done} visited${i.d!=null?` · start is ${distText(i.d)}`:""}`)}).join("")}
 if(k==="see"){const types=STYPES.filter(t=>t!=="Parks and gardens");
  const pl=placesNow(c).filter(p=>!p.types.includes("Parks and gardens")||p.types.length>1).filter(p=>!SEEF||p.types.includes(SEEF)).filter(p=>p.st.s!=="closed"||!c.here).sort((a,b)=>byNear(c)(a,b)-0.6*(intScore(a.types)-intScore(b.types))).slice(0,6);
  const ints=S.prefs&&INTS.filter(([k])=>(S.prefs.ints||[]).includes(k)).map(x=>x[1]);
  return `<div class="chips">${types.map(t=>`<button class="chip" aria-pressed="${SEEF===t}" data-seef="${esc(t)}">${esc(t)}</button>`).join("")}</div>`+(ints&&ints.length?`<p class="hint">Your interests first: ${esc(ints.join(", "))}.</p>`:"")+(rainy()?`<p class="hint">☔ Indoor places only.</p>`:"")+(pl.length?pl.map(p=>row(p.open,`${esc(p.name)}${p.visited?" ✓":""}`,`${statusPill(p.st)}<span class="hint">${where(p,c)}</span>`)).join(""):`<p class="hint">Nothing matches right now.</p>`)}
 if(k==="eat"){const meal=mealNow(n);const fa=foodAll(c).filter(x=>!x.f.types.every(t=>t==="Bars and mezcal")).sort((a,b)=>foodSort(c)(a,b)||((servesMeal(b.f,meal)?1:0)-(servesMeal(a.f,meal)?1:0))).slice(0,6);
  const fm=EATMOOD?foodAll(c).filter(x=>moodsOf(x.f).includes(EATMOOD)).sort((a,b)=>foodSort(c)(a,b)||((servesMeal(b.f,meal)?1:0)-(servesMeal(a.f,meal)?1:0))).slice(0,6):fa;
  return moodChips(EATMOOD,"data-eatmood")+`<p class="hint">${meal==="breakfast"?"Breakfast time":meal==="lunch"?"Lunch time":"Dinner time"}${c.areaId?` near you in ${esc(AD[c.areaId].name)}`:""}. Open now first.</p>`+(fm.length?"":`<p class="hint">Nothing in the guide fits that mood.</p>`)+fm.map(x=>row(`data-eatarea="${x.area}"`,esc(x.f.name),`${statusPill(x.st)}<span class="price">${PRICES[x.f.price-1]}</span>${c.areaId&&x.area===c.areaId?"":`<span class="hint">${esc(AD[x.area].name)}</span>`}`,esc(x.f.order.split(";")[0].split(". ")[0]))).join("")}
 if(k==="drink"&&isEvening(n))return nightOut(c);
 if(k==="drink"){const di=dayInfo(Math.max(0,tripDayIndex())),ev=seasonFor(mxDateKey().slice(5)).concat(tripDayIndex()<0?[]:[]);
  const fa=foodAll(c).filter(x=>x.f.types.some(t=>t==="Bars and mezcal"||t==="Cafés and sweets")).sort(foodSort(c));
  const posada=ev.find(e=>e.id==="posadas"),reyes=ev.find(e=>e.id==="reyes");
  return (posada?`<p class="hint">🎄 It's posada season: look for ponche de frutas, hot fruit punch with guava, sugarcane and cinnamon.</p>`:"")+(reyes?`<p class="hint">👑 Día de Reyes: rosca with hot chocolate.</p>`:"")+fa.map(x=>row(`data-eatarea="${x.area}"`,esc(x.f.name),`${statusPill(x.st)}<span class="hint">${esc(x.f.types.filter(t=>t==="Bars and mezcal"||t==="Cafés and sweets").join(", "))}${c.areaId&&x.area===c.areaId?"":` · ${esc(AD[x.area].name)}`}</span>`,esc(x.f.order.split(";")[0].split(". ")[0]))).join("")}
 if(k==="relax"&&rainy()){const cafes=foodAll(c).filter(x=>x.f.types.includes("Cafés and sweets")).sort(foodSort(c)).slice(0,4);const ins=placesNow(c).filter(p=>p.st.s==="open"&&p.types.includes("Museums")).sort(byNear(c)).slice(0,3);
  return `<p class="hint">☔ Raining: somewhere dry to sit. Cafés first, then a museum.</p>`+cafes.map(x=>row(`data-eatarea="${x.area}"`,esc(x.f.name),`${statusPill(x.st)}<span class="hint">Café · ${esc(AD[x.area].name)}</span>`,esc(x.f.order.split(";")[0].split(". ")[0]))).join("")+ins.map(p=>row(p.open,esc(p.name),`${statusPill(p.st)}<span class="hint">${where(p,c)}</span>`)).join("")}
 if(k==="relax"){const parks=placesNow(c).filter(p=>p.types.includes("Parks and gardens")).sort(byNear(c));const cafes=foodAll(c).filter(x=>x.f.types.includes("Cafés and sweets")).sort(foodSort(c)).slice(0,3);
  return `<p class="hint">Green space and a seat. Parks first, then cafés.</p>`+parks.map(p=>row(p.open,esc(p.name),`${statusPill(p.st)}<span class="hint">${where(p,c)}</span>`)).join("")+cafes.map(x=>row(`data-eatarea="${x.area}"`,esc(x.f.name),`${statusPill(x.st)}<span class="hint">Café · ${esc(AD[x.area].name)}</span>`,esc(x.f.order.split(";")[0].split(". ")[0]))).join("")}
 if(k==="learn"){let next=null;for(const aid in AD)for(const w of AD[aid].walks){const i=walkInfo(w,c);if(!next&&i.nx>=0&&(i.done>0||aid===c.areaId))next=[w,i]}
  return `<form class="search" id="askForm"><label for="askq" style="position:absolute;left:-9999px">Ask the guide</label><input id="askq" placeholder="Why does the cathedral lean?" autocomplete="off"><button type="submit">Ask</button></form>`
   +(next?row(`data-stop="${next[0].stops.includes(next[0].stops[0])?walkStops(next[0])[Math.max(0,next[1].nx)]:""}"`,`Read ahead: ${esc(next[1].first.name)}`,`<span class="hint">Next on ${esc(next[0].name)}</span>`):"")
   +row(`data-go="glossary:"`,"Glossary",`<span class="hint">Words from the guide, with pronunciation</span>`)+THREADS.map(t=>row(`data-thread="${t.id}"`,esc(t.name),`<span class="hint">Thread · ${t.steps.length} places</span>`)).join("")}
 return ""}
function nowInner(){
 const c=ctxNow(),n=c.n,ti=tripDayIndex(),inTrip=ti>=0&&ti<tripLen(),cnt=counts(c);
 const tripLine=inTrip?`Day ${ti+1} of your trip`:ti<0?`Trip starts in ${-ti} day${ti===-1?"":"s"}`:"After your trip";
 const loc=c.here?`<button class="locchip" data-hereclear title="Change where you are">📍 ${esc(c.here.label)}</button>`:`<button class="locchip off" data-herehelp>📍 Set where you are</button>`;
 const alerts=[];
 if(c.here){const soon=placesNow(c).find(p=>p.st.soon&&p.d<1200);if(soon)alerts.push(`⏳ ${esc(soon.name)} ${esc(soon.st.t.split(" · ")[1])}.`)}
 if(WX&&WX.wet&&!(S.rain&&Date.now()-S.rain.t<6*3600e3))alerts.push(`☔ It's raining in the city now (Open-Meteo), so indoor places come first. <button class="linkbtn" data-rain>Turn off</button>`);
 if(S.walkOn&&WALKIDX[S.walkOn.w]){const w=walkById(S.walkOn.w),i=walkInfo(w,c);if(i.nx>=0)alerts.unshift(`▶ You're on <b>${esc(w.name)}</b>. <button class="linkbtn" data-walk="${w.id}" data-step="${i.nx}">Continue at stop ${i.nx+1}</button> · <button class="linkbtn" data-walkend="${w.id}">End</button>`)}
 const di=inTrip?dayInfo(ti):null;
 if(di){const ev=seasonFor(di.k);if(ev.length)alerts.push(`🎄 Today: ${ev.map(e=>esc(e.name)).join(", ")}. <button class="linkbtn" data-go="season:">What it means</button>`);
  const closed=Object.values(AD).filter(a=>(a.closures||[]).some(x=>x.lvl==="no"&&((x.dows&&x.dows.includes(di.dow))||(x.dates&&x.dates.includes(di.k))))).map(a=>a.name);if(closed.length)alerts.push(`🚫 Main museums closed today in ${esc(closed.join(" and "))}.`);
  Object.values(AD).forEach(a=>(a.closures||[]).filter(x=>x.lvl==="warn"&&x.dates&&x.dates.includes(di.k)).forEach(x=>alerts.push(`⚠️ ${esc(a.name)}: ${esc(x.t)}`)))}
 const top=planNextHTML(c,ti)+nearestHTML(c);
 return `${top?`<div class="nowtop">${top}</div>`:""}<div class="nowhead"><span class="hint"><strong style="color:var(--ink)">${esc(n.label)}</strong> in Mexico City · ${esc(tripLine)}</span><span style="display:flex;gap:6px;flex-wrap:wrap">${loc}<button class="locchip ${rainy()?"":"off"}" data-rain aria-pressed="${rainy()}">☔ ${rainy()?"Rain plan on":"Raining?"}</button></span></div>
  <div id="herehelp" class="hint" hidden><p>Tap a pin on the map and choose "I'm here". On a walk, the guide follows your stops.</p>${!window.__ARTIFACT__&&navigator.geolocation?`<p style="margin-top:6px"><button class="btn small primary" data-heregps>Use my location</button></p>`:""}</div>
  <h2 class="nowq">What now?</h2>

  <div class="intents" role="group" aria-label="What do you want to do">${INTENTS.map(([k,l])=>{const ev=k==="drink"&&isEvening(n);return `<button class="intent" aria-pressed="${INTENT===k}" data-intent="${k}"><svg viewBox="0 0 24 24" aria-hidden="true">${ev?MOON:ICONS[k]}</svg><b>${ev?"Night out":l}</b><span>${esc(cnt[k])}</span></button>`}).join("")}</div>
  ${INTENT?`<div class="nowlist intentout">${intentOut(INTENT,c)}</div>`:""}
  ${alerts.length?`<ul class="nowlines">${alerts.map(l=>`<li>${l}</li>`).join("")}</ul>`:""}
  ${!S.prefs||!S.prefs.done?prefsHTML(true):""}`}
function nowHTML(){return `<section class="filters nowcard" id="now">${nowInner()}</section>`}
function refreshNow(){const el=document.getElementById("now");if(el)el.innerHTML=nowInner()}
let NOWTIMER=null;
function startNowTimer(){if(NOWTIMER)clearInterval(NOWTIMER);NOWTIMER=setInterval(()=>{const el=document.getElementById("now");if(!el||cur().v!=="areas"){clearInterval(NOWTIMER);NOWTIMER=null;return}const a=document.activeElement;if(a&&a.id==="askq")return;el.innerHTML=nowInner()},60000)}

function locateForNow(){if(!navigator.geolocation)return;const el=document.getElementById("now");
 navigator.geolocation.getCurrentPosition(pos=>{const ll=[pos.coords.latitude,pos.coords.longitude];const near=nowPlaces().map(p=>({p,d:hav(ll,p.ll)})).sort((a,b)=>a.d-b.d)[0];
  setHere(ll,near&&near.d<600?near.p.name:"your location")},
  ()=>{if(el){const p=document.createElement("p");p.className="hint";p.textContent="Location isn't available. Allow location for this site in your phone's settings, or type where you are.";el.appendChild(p)}},{enableHighAccuracy:true,timeout:10000})}

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(b.hasAttribute("data-heregps")){locateForNow();return}
 if(b.hasAttribute("data-herehelp")){const h=document.getElementById("herehelp");if(h)h.hidden=!h.hidden;return}
 if(b.hasAttribute("data-hereclear")){S.here=null;save();render();return}
 if(d.intent){INTENT=INTENT===d.intent?null:d.intent;refreshNow();return}
 if(d.seef!==undefined){SEEF=SEEF===d.seef?null:d.seef;refreshNow();return}
 if(d.herepin!==undefined){const p=mapPins()[+d.herepin];if(p){setHere(p.ll,p.name)}return}});

/* Today: the next thing on the plan you chose for this date, and the nearest place you haven't seen */
function planDayIndex(ti){return ti>=0&&ti<tripLen()?ti:ti<0?0:null}
function planNextHTML(c,ti){{const x=itinNextHTML(c,ti);if(x)return x}const i=planDayIndex(ti);if(i==null)return "";const di=dayInfo(i),pid=(S.plan||{})[di.k],d=pid&&DAYS.find(x=>x.id===pid);
 const lbl=ti===i?"today":`on ${di.label}`;
 if(!d){const bp=bxPlanAt(i);if(bp){const items=bp.out.filter(x=>x.kind!=="go"),nx2=ti===i?items.find(x=>x.t>=c.n.h-0.25):items[0];
  if(!nx2)return `<section class="filters plannext"><span class="kicker">Your plan ${esc(lbl)}</span><p>Day ${i+1} is done.</p><div><button class="btn small" data-go="build:">See your days</button></div></section>`;
  const nm=nx2.kind==="place"?nx2.p.name:(nx2.m?nx2.m.f.name:nx2.lbl),btn=nx2.kind==="place"?nx2.p.open:nx2.m?`data-eatarea="${nx2.m.area}"`:`data-go="build:"`;
  return `<section class="filters plannext"><span class="kicker">Next on your plan · Day ${i+1}</span><button class="nowitem" ${btn}><span class="nowname">${bxHM(nx2.t)} · ${esc(nm)}</span><span class="hint">${nx2.kind==="place"?esc(AD[nx2.p.area].name):esc(nx2.lbl)}</span></button><div><button class="linkbtn" data-go="build:">The whole day</button></div></section>`}}
 if(!d){const fit=daysFitting(di);return `<section class="filters plannext"><span class="kicker">Next on your plan</span><p>Nothing planned ${esc(lbl)} yet.${fit.length?` ${fit.length} sample day${fit.length>1?"s":""} fit${fit.length>1?"":"s"} this date.`:""}</p><div><button class="btn small" data-go="build:">Build ${ti===i?"today":"day "+(i+1)}</button></div></section>`}
 const steps=d.steps.filter(x=>x[1]),hm=t=>{const[h,m]=t.split(":").map(Number);return h+(m||0)/60};
 const nx=ti===i?steps.find(x=>hm(x[0])>=c.n.h-0.25):steps[0];
 if(!nx)return `<section class="filters plannext"><span class="kicker">Your plan ${esc(lbl)}</span><p><b>${esc(d.name)}</b> is done for today.</p><div><button class="btn small" data-day="${d.id}">See the day</button></div></section>`;
 const r=resolveStep(nx[1],d.area);if(!r)return "";
 const btn=r.btn;
 return `<section class="filters plannext"><span class="kicker">Next on your plan · ${esc(d.name)}</span><button class="nowitem" ${btn}><span class="nowname">${esc(nx[0])} · ${esc(r.name)}</span><span class="hint">${esc(r.kind)}${nx[2]?` · ${esc(nx[2])}`:""}</span></button><div><button class="linkbtn" data-day="${d.id}">The whole day</button></div></section>`}
function nearestHTML(c){if(!c.here)return "";
 const pl=placesNow(c).filter(p=>!p.visited&&p.d!=null&&p.st.s!=="closed").sort((a,b)=>a.d-b.d)[0];if(!pl)return "";
 const meta=getStop(pl.id)||siteById(pl.id)||{};
 return `<section class="filters plannext"><span class="kicker">Nearest place you haven't seen</span>${row(pl.open,esc(pl.name),`${statusPill(pl.st)}<span class="hint">${distText(pl.d)}</span>`,esc(meta.what||meta.summary||""))}</section>`}
