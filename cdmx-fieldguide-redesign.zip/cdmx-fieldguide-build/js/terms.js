/* Tappable terms and glossary. Terms come from core.json "glossary" (each with a sourced definition
   and an approximate pronunciation). The first mention of a term in each paragraph becomes a button
   that opens a small sheet with the meaning and suggested questions for Ask. */
let GLOSSARY=[],TERMRE=null,TERMMAP={};
function buildTerms(){TERMMAP={};const forms=[];GLOSSARY.forEach((g,i)=>g.forms.forEach(f=>{TERMMAP[f.toLowerCase()]=i;forms.push(f)}));
 forms.sort((a,b)=>b.length-a.length);TERMRE=forms.length?new RegExp(`(?<![\\p{L}\\p{N}])(${forms.map(f=>f.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")})(?![\\p{L}\\p{N}])`,"gu"):null}
function termify(escaped){if(!TERMRE)return escaped;const seen=new Set();
 return escaped.replace(TERMRE,(m)=>{const i=TERMMAP[m.toLowerCase()];if(i==null||seen.has(i))return m;seen.add(i);return `<button class="term" data-term="${i}">${m}</button>`})}
function termSheet(i){const g=GLOSSARY[i];if(!g)return;let el=document.getElementById("termsheet");if(!el){el=document.createElement("div");el.id="termsheet";el.className="termsheet";document.body.appendChild(el)}
 const fn=new Footnotes();
 el.innerHTML=`<div class="termcard" role="dialog" aria-label="${esc(g.term)}"><div style="display:flex;justify-content:space-between;gap:10px;align-items:start"><div><b style="font-size:20px;font-weight:800">${esc(g.term)}</b>${g.pron?`<div class="hint">Say it: ${esc(g.pron)} <span style="opacity:.7">(approximate)</span></div>`:""}</div><button class="back" data-termclose aria-label="Close">×</button></div>
 <p style="font-size:16px;line-height:1.55">${esc(g.def[0])}${fn.mark(g.def[1])} ${tagHTML(g.def[2])}</p>
 <div class="chips"><button class="chip" data-termask="${i}">Ask about ${esc(g.term)}</button><button class="chip" data-go="glossary:">Glossary</button></div>${fn.html()}</div>`;el.hidden=false}
function closeTermSheet(){const el=document.getElementById("termsheet");if(el)el.hidden=true}
function vGlossary(){const fn=new Footnotes();const list=GLOSSARY.map((g,i)=>[g,i]).sort((a,b)=>a[0].term.localeCompare(b[0].term));
 return `<section style="display:grid;gap:6px"><h1>Glossary</h1><p class="hint">Words from the guide, with an approximate pronunciation. Tap any underlined word in the guide to see its entry.</p></section>
 <section class="filters"><dl style="margin:0;display:grid;gap:14px">${list.map(([g,i])=>`<div><dt style="font-weight:800;font-size:17px">${esc(g.term)}${g.pron?` <span class="hint" style="font-weight:500">· ${esc(g.pron)}</span>`:""}</dt><dd style="margin:4px 0 0;font-size:15.5px">${esc(g.def[0])}${fn.mark(g.def[1])} <button class="linkbtn" data-termask="${i}">Ask</button></dd></div>`).join("")}</dl></section>${fn.html()}`}
function objHTML(o,fn){return `<div class="objcard"><h3>${esc(o.name)}</h3><p>${termify(esc(o.p[0]))}${fn.mark(o.p[1])} ${tagHTML(o.p[2])}</p>${o.look&&o.look.length?`<div class="looklist"><span class="lbl">Look for</span><ul>${o.look.map(l=>`<li>${termify(esc(l[0]))}${fn.mark(l[1])} ${l[2]?tagHTML(l[2]):""}</li>`).join("")}</ul></div>`:""}<div><button class="btn small" data-objask="${esc(o.name)}">Ask about ${esc(o.name)}</button></div></div>`}
document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b){if(e.target.id==="termsheet")closeTermSheet();return}const d=b.dataset;
 if(d.term!==undefined){e.preventDefault();termSheet(+d.term);return}
 if(b.hasAttribute("data-termclose")){closeTermSheet();return}
 if(d.termask!==undefined){const g=GLOSSARY[+d.termask];closeTermSheet();ASKCTX=null;startAsk(null,undefined,[`What is ${g.term}?`,`Where in the city can I see ${g.term}?`,`Why does ${g.term} matter?`]);return}
 if(d.objask){const n=d.objask;ASKCTX=null;startAsk(null,undefined,[`Tell me more about ${n}.`,`What should I notice about ${n}?`,`What do historians debate about ${n}?`]);return}
 if(d.go==="glossary:"){closeTermSheet()}});
