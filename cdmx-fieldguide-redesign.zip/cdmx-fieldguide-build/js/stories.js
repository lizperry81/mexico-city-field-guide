/* The Stories: the intellectual heart of the Field Guide.
   Stories, question-led explorations, the time machine and the museum decoder are editorial
   structures defined in data/stories.json. They don't hold new history of their own: each
   chapter pulls in the guide's existing sourced material (an era in core.ctx, a thread, a
   place's dated history, a museum tour) so every fact keeps its footnote. */
let STORIES=[],QUESTIONS=[],MISSIONS=[],TIMEM=[],MUSEUMS=[],BIGQ=[];
function useStories(d){d=d||{};STORIES=d.stories||[];QUESTIONS=d.questions||[];MISSIONS=d.missions||[];TIMEM=d.time||[];MUSEUMS=d.museums||[];BIGQ=d.big||[]}
const storyById=id=>STORIES.find(s=>s.id===id);
const questionById=id=>QUESTIONS.find(q=>q.id===id);
const placeName=id=>String(id).startsWith("food:")?String(id).split(":").slice(2).join(":"):(getStop(id)||siteById(id)||{}).name||id;
const placeAttr=id=>STOPIDX[id]?`data-stop="${id}"`:SITEIDX[id]?`data-more="${id}"`:"";
const placeExists=id=>!!(STOPIDX[id]||SITEIDX[id]);

/* ---------- reading helpers ---------- */
const wordsOf=html=>String(html).replace(/<[^>]+>/g," ").split(/\s+/).filter(Boolean).length;
const readMins=html=>Math.max(1,Math.round(wordsOf(html)/200));
function placeStoryPts(id){const st=getStop(id),site=siteById(id);const L=(st&&(st.lead||st.read))||(site&&site.read)||[];
 const pts=L.filter(b=>b.pt&&!b.pt.look);return pts.slice().sort((a,b)=>(a.pt.ord??99)-(b.pt.ord??99))}
function placeAllBlocks(id){const st=getStop(id),site=siteById(id);return [].concat((st&&st.lead)||[],(st&&st.read)||[],(site&&site.read)||[],(st&&st.more)||[])}
/* every Debated / Unknown sentence in a set of blocks, for "What historians debate" */
function contested(blocks,label){const out=[];const seen=new Set();
 const walk=b=>{if(!b)return;if(Array.isArray(b)){b.forEach(walk);return}
  if(b.p&&(b.p[2]==="deb"||b.p[2]==="unk")&&!seen.has(b.p[0])){seen.add(b.p[0]);out.push({p:b.p,label})}
  if(b.pt){walk(b.pt.blocks);(b.pt.more||[]).forEach(m=>walk(m.blocks))}
  if(b.obj){if(b.obj.p&&(b.obj.p[2]==="deb"||b.obj.p[2]==="unk"))out.push({p:b.obj.p,label:b.obj.name});(b.obj.look||[]).forEach(l=>{if(l[2]==="deb"||l[2]==="unk")out.push({p:l,label:b.obj.name})})}
  if(b.blocks)walk(b.blocks);(b.more||[]).forEach&&b.more&&b.more.forEach&&b.more.forEach(m=>m&&m.blocks&&walk(m.blocks))};
 walk(blocks);return out}
function storyBlocks(s){let all=[];(s.ctx||[]).forEach(id=>{const c=ctxById(id);if(c)all=all.concat(c.blocks||[],c.more||[])});
 (s.threads||[]).forEach(id=>{const t=THREADS.find(x=>x.id===id);if(t)t.steps.forEach(st=>(st.p||[]).forEach(p=>all.push({p})))});
 (s.chapters||[]).forEach(ch=>{if(ch.p)ch.p.forEach(p=>all.push({p}))});
 (s.places||[]).forEach(id=>all=all.concat(placeAllBlocks(id)));
 (s.tours||[]).forEach(id=>{const t=tourById(id);if(t)all=all.concat(t.blocks||[],t.background||[])});return all}

/* one chapter of a story, pulled from wherever it lives */
function chapterHTML(ch,fn,i){const [k,id]=(ch.from||":").split(":");let body="",link="";
 if(ch.p)body=ch.p.map(p=>blockHTML({p},fn)).join("");
 else if(k==="ctx"){const c=ctxById(id);if(c){body=`${c.key?`<ul class="keymom">${c.key.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`:""}${(c.blocks||[]).filter(b=>b.p).slice(0,3).map(b=>blockHTML(b,fn)).join("")}`;link=`<button class="linkbtn" data-ctxpage="${id}">The full background: ${esc(c.title)}</button>`}}
 else if(k==="thread"){const t=THREADS.find(x=>x.id===id);if(t){body=t.steps.map(st=>`<div class="tstep"><span class="tsw">${esc(st.when||"")}</span><button class="tsplace" ${placeAttr(st.ref)}>${esc(placeName(st.ref))}</button>${(st.p||[]).map(p=>blockHTML({p},fn)).join("")}</div>`).join("");link=`<button class="linkbtn" data-thread="${id}">Follow it on the map: ${esc(t.name)}</button>`}}
 else if(k==="place"){const pts=placeStoryPts(id).slice(0,4);body=pts.map(b=>`<h4>${b.pt.when?`<span class="when">${esc(b.pt.when)}</span> `:""}${esc(b.pt.h)}</h4>${b.pt.blocks.map(x=>blockHTML(x,fn)).join("")}`).join("");if(placeExists(id))link=`<button class="linkbtn" ${placeAttr(id)}>Go to ${esc(placeName(id))}</button>`}
 else if(k==="tour"){const t=tourById(id);if(t){const objs=(t.blocks||[]).filter(b=>b.obj).slice(0,4);body=`<p class="hint">${esc(t.summary||"")}</p>`+objs.map(b=>`<h4>${esc(b.obj.name)}</h4>${blockHTML({p:b.obj.p},fn)}`).join("");link=`<button class="linkbtn" data-tour="${id}">The museum tour: ${esc(t.name)}</button>`}}
 if(!body)return "";
 return `<section class="chapter" id="ch-${i}"><span class="chno">${["I","II","III","IV","V","VI","VII","VIII"][i]||i+1}</span><h2>${esc(ch.h)}</h2><div class="chbody">${body}</div>${link?`<p class="chlink">${link}</p>`:""}</section>`}

/* ---------- Home: the cover ---------- */
function bigQuestion(){const ids=BIGQ.length?BIGQ:QUESTIONS.map(q=>q.id);const d=new Date();const k=Math.floor((d-new Date(d.getFullYear(),0,0))/864e5);
 const s=storyById(ids[k%ids.length]);if(s)return {kind:"story",id:s.id,q:s.q,t:s.title};const q=questionById(ids[k%ids.length]);return q?{kind:"q",id:q.id,q:q.q,t:"An exploration"}:null}
function vHome(){
 const bq=bigQuestion(),J=journal();
 const started=STORIES.filter(s=>J.read[s.id]||J.saved["story:"+s.id]);
 const walks=[];for(const aid in AD)AD[aid].walks.forEach(w=>walks.push([aid,w]));
 const feat=walks.filter(([a])=>["centro","tlatelolco","chapul","teo"].includes(a)).slice(0,4);
 const featured=bq&&bq.kind==="story"?storyById(bq.id):null;
 const related=(featured&&featured.related||[]).map(storyById).filter(Boolean).slice(0,3);
 const places=(featured&&featured.places||[]).filter(placeExists).slice(0,3);
 const firstMission=MISSIONS[0];
 const progress=firstMission?missionDone(firstMission):0;
 return `
 <section class="cover home-cover">
  <div class="coverart">${FIG.lake?FIG.lake():""}</div>
  <p class="masthead">Mexico City Field Guide <span>·</span> A learning companion</p>
  <h1 class="coverh">A city is not a list of places. It is a story still being argued over.</h1>
  <p class="coverdek">History, power, art, food, memory, and the people who make Mexico City what it is.</p>
  <div class="home-principle"><span class="eyebrow">The idea</span><p>Go beyond seeing the city. Learn to read it.</p></div>
 </section>
 ${featured?`<section class="home-investigation">
  <div class="home-kicker"><span class="eyebrow">Start with a big question</span><span class="home-index">01 / TODAY</span></div>
  <h2>${esc(featured.q)}</h2>
  <p class="home-investigation-dek">${esc(Array.isArray(featured.intro)?featured.intro[0]:featured.intro||"Follow this question through the city's places, histories, and competing interpretations.")}</p>
  <div class="home-investigation-actions"><button class="btn primary" data-story="${featured.id}">Investigate this story <span aria-hidden="true">→</span></button><span class="home-reading-note">A guided historical investigation</span></div>
  ${places.length?`<div class="home-place-strip"><span class="eyebrow">Follow the question on the ground</span><div>${places.map(id=>`<button class="home-place-link" ${placeAttr(id)}>${esc(placeName(id))}<span aria-hidden="true"> ↗</span></button>`).join("")}</div></div>`:""}
 </section>`:bq?`<section class="bigq"><span class="eyebrow">Today's question</span><button class="bigqbtn" ${bq.kind==="story"?`data-story="${bq.id}"`:`data-question="${bq.id}"`}><span class="bq">${esc(bq.q)}</span><span class="bqgo">Start investigating →</span></button></section>`:""}
 ${started.length?`<section class="shelf"><div class="home-section-head"><div><span class="eyebrow">Pick up where you left off</span><h2 class="sech">Continue your investigation</h2></div><button class="linkbtn" data-nav="journal">Your journal →</button></div><div class="hscroll">${started.map(s=>storyTile(s)).join("")}</div></section>`:""}
 <section class="askbar home-ask"><form id="homeAsk" class="askline"><label for="homeAskQ" class="eyebrow">Ask the guide</label><div class="askrow"><input id="homeAskQ" placeholder="Why does Mexico City keep sinking?" autocomplete="off"><button type="submit">Ask</button></div></form>
  <div class="modechips">${ASKMODES.map(m=>`<button class="mchip" data-askmode="${m.id}" data-askgo>${esc(m.cue)}</button>`).join("")}</div>
  <p class="home-microcopy">Ask for evidence, competing interpretations, or the story behind something you're looking at.</p>
 </section>
 ${related.length?`<section class="home-related"><div class="home-section-head"><div><span class="eyebrow">Keep following the thread</span><h2 class="sech">Where this question leads</h2></div></div><div class="home-related-grid">${related.map(s=>`<button class="home-story-card" data-story="${s.id}"><span class="home-card-no">${String(s.n).padStart(2,"0")}</span><b>${esc(s.title)}</b><span>${esc(s.q)}</span><i>Explore story →</i></button>`).join("")}</div></section>`:""}
 <section class="home-stories"><div class="home-section-head"><div><span class="eyebrow">The editorial library</span><h2 class="sech">Stories that change how you see the city</h2></div><span class="home-count">${STORIES.length} investigations</span></div>
  <p class="secdek">Each story connects places, people, objects, and the arguments historians are still having.</p>
  <ol class="toc">${STORIES.map(s=>`<li><button data-story="${s.id}"><span class="tocn">${s.n}</span><span class="toct"><b>${esc(s.title)}</b><span>${esc(s.q)}</span></span>${J.read[s.id]?`<span class="tocr">Read</span>`:""}</button></li>`).join("")}</ol></section>
 <section class="home-field-study">
  <div class="home-field-top"><span class="eyebrow">Take the guide outside</span><span class="home-index">02 / IN THE FIELD</span></div>
  <h2>Don't just look. Learn to notice.</h2>
  <p>Short investigations turn the street, a building, a mural, or a market into evidence. Observe first; interpret with context.</p>
  ${firstMission?`<button class="home-mission-feature" data-mission="${firstMission.id}"><span class="home-mission-label">Featured field mission</span><b>${esc(firstMission.title)}</b><span>${esc(firstMission.intro)}</span><span class="home-progress"><i style="width:${Math.round(progress/Math.max(1,firstMission.items.length)*100)}%"></i></span><small>${progress} of ${firstMission.items.length} observations recorded <strong>Open mission →</strong></small></button>`:""}
  <div class="home-field-actions"><button class="btn primary" data-nav="field">Explore The Field</button><button class="btn" data-nav="journal">Open my journal</button></div>
 </section>
 <section><div class="home-section-head"><div><span class="eyebrow">Choose your next route</span><h2 class="sech">The city, in the field</h2></div></div><p class="secdek">Walks are organized around places and ideas—not just proximity.</p><div class="hscroll">${feat.map(([a,w])=>`<button class="fieldtile" style="--line:${LINECOL[a]}" data-walkfrom="${w.id}:0"><span class="linebadge">${LINECODE[a]}</span><b>${esc(w.name)}</b><span>${esc(AD[a].name)} · ${esc(w.time.replace(/^About /,""))}</span></button>`).join("")}<button class="fieldtile more" data-nav="field"><b>All walks, museums and missions</b><span>The Field →</span></button></div></section>
 <section class="home-tools"><button class="duob" data-go="time:"><span class="eyebrow">Historical time machine</span><b>See the city in another time</b><span>Explore the city's changing landscape.</span></button><button class="duob" data-go="eras:"><span class="eyebrow">The big picture</span><b>Eight eras, in context</b><span>Follow the long arc of the city's history.</span></button></section>
 <section class="nearrow home-quicklinks"><button class="btn" data-go="near:">What's around me?</button><button class="btn" data-go="museums:">Museum decoder</button><button class="btn" data-nav="journal">My journal</button></section>`;
}
function storyTile(s){return `<button class="storytile" data-story="${s.id}"><span class="tocn">${s.n}</span><b>${esc(s.title)}</b><span>${esc(s.q)}</span></button>`}

/* ---------- One story ---------- */
function vStory(){const s=storyById(cur().id);if(!s)return `<p class="empty">That story isn't in the guide.</p>`;const fn=new Footnotes(),J=journal();markRead(s.id);
 const chapters=(s.chapters||[]).map((ch,i)=>chapterHTML(ch,fn,i)).filter(Boolean);
 const debates=contested(storyBlocks(s)).slice(0,8);
 const objs=[];(s.tours||[]).forEach(id=>{const t=tourById(id);if(t)(t.blocks||[]).filter(b=>b.obj).slice(0,6).forEach(b=>objs.push([t,b.obj]))});
 const cast=[];(s.threads||[]).forEach(id=>{const t=THREADS.find(x=>x.id===id);if(t&&t.cast)t.cast.forEach(c=>cast.push([c.n||c.name||c[0],c.d||c.role||c[1]]))});(s.people||[]).forEach(p=>cast.push(p));
 const keys=[];(s.ctx||[]).forEach(id=>{const c=ctxById(id);if(c&&c.key)keys.push([c.era,c.title,c.key])});
 const places=(s.places||[]).filter(placeExists);
 const body=chapters.join("");const mins=readMins(body);
 return `<article class="story">
 <header class="storyhead"><span class="eyebrow">Story ${s.n} of ${STORIES.length}</span><h1>${esc(s.title)}</h1><p class="storyq">${esc(s.q)}</p>
  <div class="storymeta"><span>${mins} min read</span><span>${chapters.length} chapters</span><span>${places.length} places</span></div>
  <p class="edline">${edStatusHTML("story",s.id)}</p><div class="storyacts">${saveBtn("story",s.id)}<button class="btn small" data-askabout-story="${s.id}">Ask the guide</button></div></header>
 <div class="storyintro">${s.intro.map(p=>`<p>${esc(p)}</p>`).join("")}</div>
 ${s.fig&&FIG[s.fig]?`<figure class="figure">${FIG[s.fig]()}<figcaption>A sketch of the valley around 1519, not to scale: island, causeways, aqueduct and lake.</figcaption></figure>`:""}
 ${chapters.length>1?`<nav class="chapnav" aria-label="Chapters">${(s.chapters||[]).map((c,i)=>`<button class="chip" data-jump="ch-${i}">${esc(c.h)}</button>`).join("")}</nav>`:""}
 ${body}
 ${keys.length?`<section class="aside"><h3>Key dates</h3>${keys.map(([era,t,k])=>`<p class="asidek">${esc(t)} · ${esc(era)}</p><ul class="keymom">${k.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`).join("")}</section>`:""}
 ${cast.length?`<section class="aside"><h3>People</h3><dl class="cast">${cast.map(([n,d])=>`<div><dt>${esc(n)}</dt><dd>${esc(d||"")}</dd></div>`).join("")}</dl></section>`:""}
 ${objs.length?`<section class="aside"><h3>Objects</h3><div class="objrow">${objs.map(([t,o])=>`<button class="objtile" data-tour="${t.id}"><b>${esc(o.name)}</b><span>${esc(t.name)}</span></button>`).join("")}</div></section>`:""}
 ${debates.length?`<section class="aside debate"><h3>What historians debate, or can't establish</h3><p class="hint">Every sentence the guide's sources mark as debated or unknown, gathered from this story's places and eras.</p>${debates.map(d=>`<div class="debitem">${d.label?`<span class="deblbl">${esc(d.label)}</span>`:""}${blockHTML({p:d.p},fn)}</div>`).join("")}</section>`:""}
 <section class="aside"><h3>See it in person</h3><p class="inperson">${esc(s.inperson||"")}</p>
  <div class="placelist">${places.map(id=>{const a=STOPIDX[id]||SITEIDX[id];return `<button class="placerow" style="--line:${LINECOL[a]||"var(--accent)"}" ${placeAttr(id)}><span class="dotl"></span><b>${esc(placeName(id))}</b><span>${esc(AD[a].name)}</span></button>`}).join("")}</div>
  ${(s.walks||[]).length?`<div class="mc-btns">${s.walks.filter(w=>WALKIDX[w]).map(w=>`<button class="btn small" data-walkfrom="${w}:0">Walk: ${esc(walkById(w).name)}</button>`).join("")}</div>`:""}</section>
 ${(s.related||[]).length?`<section class="aside"><h3>Related stories</h3><div class="hscroll">${s.related.map(storyById).filter(Boolean).map(storyTile).join("")}</div></section>`:""}
 ${(s.gaps||[]).length?`<section class="gaps"><h3>Not yet in this guide</h3><p class="hint">Research this story still needs. Nothing here has been filled in with guesses.</p><ul>${s.gaps.map(g=>`<li>${esc(g)}</li>`).join("")}</ul></section>`:""}
 <nav class="storynav">${(()=>{const i=STORIES.indexOf(s),p=STORIES[i-1],n=STORIES[i+1];return `${p?`<button class="btn" data-story="${p.id}">← ${esc(p.title)}</button>`:"<span></span>"}${n?`<button class="btn" data-story="${n.id}">${esc(n.title)} →</button>`:""}`})()}</nav>
 </article>${fn.html()}`}

/* ---------- A question-led exploration ---------- */
function vQuestion(){const q=questionById(cur().id);if(!q)return `<p class="empty">Not found.</p>`;const fn=new Footnotes();
 const stops=q.stops.filter(placeExists);
 return `<article class="story"><header class="storyhead"><span class="eyebrow">An exploration</span><h1>${esc(q.q)}</h1><div class="storyacts">${saveBtn("question",q.id)}</div></header>
 <div class="storyintro"><p>${esc(q.intro)}</p></div>
 ${stops.map((id,i)=>{const pts=placeStoryPts(id).slice(0,2);return `<section class="chapter"><span class="chno">${i+1}</span><h2>${esc(placeName(id))}</h2><div class="chbody">${pts.map(b=>`<h4>${b.pt.when?`<span class="when">${esc(b.pt.when)}</span> `:""}${esc(b.pt.h)}</h4>${b.pt.blocks.slice(0,2).map(x=>blockHTML(x,fn)).join("")}`).join("")||`<p>${esc((getStop(id)||siteById(id)).summary||"")}</p>`}</div><p class="chlink"><button class="linkbtn" ${placeAttr(id)}>Open ${esc(placeName(id))} with the walking professor</button></p></section>`}).join("")}
 <section class="aside"><h3>Look for these on the ground</h3><ul class="prompts">${q.prompts.map(p=>`<li>${esc(p)}</li>`).join("")}</ul></section>
 ${q.walk&&WALKIDX[q.walk]?`<section class="aside"><h3>A route</h3><p>The guide's walk <b>${esc(walkById(q.walk).name)}</b> covers several of these places.</p><div class="mc-btns"><button class="btn" data-walkfrom="${q.walk}:0">Open the walk</button></div></section>`:""}
 <section class="aside"><h3>Read deeper</h3><div class="hscroll">${q.stories.map(storyById).filter(Boolean).map(storyTile).join("")}</div></section></article>${fn.html()}`}

/* ---------- The time machine ---------- */
function vTime(){const i=Math.max(0,Math.min(TIMEM.length-1,S.timeI||0)),t=TIMEM[i];if(!t)return "";const c=ctxById(t.ctx),fn=new Footnotes();
 return `<section class="storyhead"><span class="eyebrow">Time machine</span><h1>Show me this city in another time</h1><p class="lede">Pick a year. Each view gathers what the guide knows about that moment and the places where you can still see it.</p></section>
 <div class="years" role="tablist">${TIMEM.map((x,j)=>`<button role="tab" aria-selected="${j===i}" data-timei="${j}"><b>${esc(x.y)}</b><span>${esc(x.label)}</span></button>`).join("")}</div>
 <article class="timeview"><h2>${esc(t.y)}: ${esc(t.label)}</h2><p class="lede">${esc(t.t)}</p>
  ${t.fig&&FIG[t.fig]?`<figure class="figure">${FIG[t.fig]()}<figcaption>Reconstruction sketch, approximate and not to scale. It shows the lake and causeways around 1519; no reliable street-level map of the city in this year is in the guide.</figcaption></figure>`:""}
  ${c?`<h3>What was happening</h3><ul class="keymom">${(c.key||[]).map(x=>`<li>${esc(x)}</li>`).join("")}</ul><p><button class="linkbtn" data-ctxpage="${c.id}">Read the era: ${esc(c.title)}</button></p>`:""}
  <h3>Where you can still see it</h3><div class="placelist">${t.places.filter(placeExists).map(id=>{const a=STOPIDX[id]||SITEIDX[id];return `<button class="placerow" style="--line:${LINECOL[a]}" ${placeAttr(id)}><span class="dotl"></span><b>${esc(placeName(id))}</b><span>${esc(AD[a].name)}</span></button>`}).join("")}</div>
 </article><p class="hint">Historical maps for 1700, 1910 and 1968 aren't in the guide yet, so those years show text and places only rather than an invented map.</p>${fn.html()}`}

/* ---------- Museum decoder ---------- */
function vMuseums(){return `<section class="storyhead"><span class="eyebrow">Museum decoder</span><h1>Investigations, not checklists</h1><p class="lede">Each museum gets one question and a handful of objects. For every object: what it is, what to look for, and what's disputed.</p></section>
 <div class="qlist">${MUSEUMS.map(m=>`<button class="qcard" data-museum="${m.id}"><span class="eyebrow">${esc(m.museum)}</span><span class="qq">${esc(m.title)}</span><span class="qp">${esc(m.intro)}</span></button>`).join("")}</div>`}
function vMuseum(){const m=MUSEUMS.find(x=>x.id===cur().id);if(!m)return "";const fn=new Footnotes();const t=m.tour?tourById(m.tour):null;
 const objs=t?(t.blocks||[]).filter(b=>b.obj):[];
 let body="";
 if(objs.length)body=objs.map((b,i)=>{const o=b.obj,deb=(o.look||[]).filter(l=>l[2]==="deb"||l[2]==="unk").concat(o.p[2]==="deb"||o.p[2]==="unk"?[o.p]:[]);
  return `<section class="objcase" id="obj-${i}"><span class="chno">${i+1}</span><h2>${esc(o.name)}</h2>
   <h4>What am I looking at?</h4>${blockHTML({p:o.p},fn)}
   ${(o.look||[]).length?`<h4>Look closely</h4><ul class="prompts">${o.look.map(l=>`<li>${esc(l[0])}${fn.mark(l[1])} ${tagHTML(l[2])}</li>`).join("")}</ul>`:""}
   ${deb.length?`<h4>What's disputed</h4>${deb.map(p=>blockHTML({p},fn)).join("")}`:""}
   <h4>Go further</h4><div class="mc-btns">${[["skeptic","How do we know what it meant?"],["people","What does it reveal about the society that made it?"],["art","Why is it displayed this way?"]].map(([md,qq])=>`<button class="mchip" data-askmode="${md}" data-askq="${esc(qq+" ("+o.name+", "+m.museum+")")}">${esc(qq)}</button>`).join("")}</div>
   ${saveBtn("object",m.id+":"+i,o.name)}</section>`}).join("");
 else{const pts=placeAllBlocks(m.place).filter(b=>b.pt);body=pts.map((b,i)=>`<section class="objcase"><span class="chno">${i+1}</span><h2>${esc(b.pt.h)}</h2>${b.pt.blocks.map(x=>blockHTML(x,fn)).join("")}</section>`).join("")}
 return `<section class="storyhead"><span class="eyebrow">Museum decoder · ${esc(m.museum)}</span><h1>${esc(m.title)}</h1><p class="lede">${esc(m.intro)}</p><div class="storyacts">${placeExists(m.place)?`<button class="btn small" ${placeAttr(m.place)}>Visiting: hours and practicalities</button>`:""}${t?`<button class="btn small" data-tour="${t.id}">The full room-by-room tour</button>`:""}</div></section>
 ${m.gap?`<section class="gaps"><h3>Needs content</h3><p>This investigation needs researched object entries before it can be useful. What the guide has so far is below.</p></section>`:""}
 ${body||`<p class="empty">No objects in the guide for this museum yet.</p>`}${fn.html()}`}

/* ---------- Eras page (the earlier Learn hub, kept) ---------- */
function vEras(){return vLearnHub()}

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.story){nav({v:"story",id:d.story});return}
 if(d.question){nav({v:"question",id:d.question});return}
 if(d.museum){nav({v:"museum",id:d.museum});return}
 if(d.timei!==undefined){S.timeI=+d.timei;save();render();return}
 if(d.askaboutStory){const s=storyById(d.askaboutStory);startAsk(null,null,[`What's the main argument of "${s.title}"?`,`What do historians still debate about ${s.title.toLowerCase()}?`,`Where in the city can I see ${s.title.toLowerCase()}?`]);return}});
document.addEventListener("submit",e=>{if(e.target.id==="homeAsk"){e.preventDefault();const q=document.getElementById("homeAskQ").value.trim();if(q){ASKCTX=null;ask(q)}else nav({v:"ask"})}});
