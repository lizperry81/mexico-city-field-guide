/* Home-screen map. Standalone (with Leaflet loaded): a real OpenStreetMap street map.
   Inside Claude, or if Leaflet can't load: a drawn map with the same pins that pans and zooms.
   Pins come from the "ll" field of each stop and site; area circles from core.json. */
let LMAP=null,SMAP=null,MAPVIEW=null;

function walkOfStop(id){for(const aid in AD)for(const w of AD[aid].walks){const j=w.stops.indexOf(id);if(j>=0)return {w,j}}return null}
function foodReview(f){for(const id of f.crit||[]){const s=SRC[id];if(s&&s.t!=="Official site")return {u:s.u,n:s.n.split(/,| \(/)[0]}}return null}
function foodWeb(f){if(f.web)return f.web;const ids=[f.hsrc].concat(f.crit||[]).filter(Boolean);for(const id of ids){const s=SRC[id];if(s&&s.t==="Official site")return s.u}return null}
function mapPins(){const out=[],L=S.mapLayers||["sites","food","night"];
 for(const aid in AD){const a=AD[aid];
  if(L.includes("sites")){
  a.sites.forEach(s=>{if(!s.ll)return;const ws=Object.keys(a.stops).find(k=>a.stops[k].siteRef===s.id);
   out.push({id:s.id,name:s.name,area:a.name,summary:s.summary,ll:s.ll,addr:s.addr,kind:ws?"stop":"site",stopId:ws||null,obj:s,open:s.link?`data-stop="${s.link}"`:`data-more="${s.id}"`,visited:S.visited.includes(s.id)||(ws&&S.visited.includes(ws))})});
  for(const k in a.stops){const st=a.stops[k];if(st.siteRef||!st.ll)continue;
   out.push({id:k,name:st.name,area:a.name,summary:st.summary,ll:st.ll,addr:"",kind:"stop",stopId:k,obj:st,open:`data-stop="${k}"`,visited:S.visited.includes(k)})}}
  if(L.includes("food"))a.food.forEach(f=>{if(!f.ll)return;out.push({id:"food:"+f.name,name:f.name,area:a.name,aid,summary:f.why||"",ll:f.ll,addr:f.addr,kind:"food",obj:f})})}
 if(L.includes("night"))(typeof NIGHT!=="undefined"?NIGHT:[]).forEach(x=>{if(!x.ll)return;out.push({id:"night:"+x.id,name:x.name,area:x.where,summary:x.summary,ll:x.ll,addr:x.addr,kind:"night",obj:x,open:`data-night="${x.id}"`})});
 return out}
const cssVar=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim()||"#a33b26";
const PINCOL={stop:"--accent",site:"--accent-2",food:"--food",night:"--night"};
function mapCardHTML(p,i){const q=encodeURIComponent(p.addr?`${p.name}, ${p.addr}, Ciudad de México`:`${p.ll[0]},${p.ll[1]}`),n=mxNow(),o=p.obj||{};
 const dir=`<a class="btn small" href="https://www.google.com/maps/search/?api=1&query=${q}" target="_blank" rel="noopener">Directions ↗</a>`;
 const head=(kick,st)=>`<div class="mc-top"><div class="mc-h"><span class="kicker">${kick}</span><b class="mc-name">${esc(p.name)}</b>${st?`<div class="meta">${statusPill(st)}</div>`:""}</div><button class="back" data-mapclose aria-label="Close">×</button></div>`;
 if(p.kind==="food"){const f=o,st=foodStatus(f,n)||{s:"unk",t:"Hours not confirmed"},web=foodWeb(f),rev=foodReview(f);
  return head(`Food · ${esc(p.area)} · ${PRICES[f.price-1]}`,st)+`<p class="mc-sum"><span class="hint">${esc(f.types.join(" · "))}</span></p>
   <p class="mc-sum"><b>Order:</b> ${esc(f.order)}</p>${f.why?`<p class="mc-sum hint">${esc(f.why)}</p>`:""}
   <div class="mc-btns">${web?`<a class="btn primary small" href="${web}" target="_blank" rel="noopener">Website ↗</a>`:""}${rev?`<a class="btn ${web?"":"primary "}small" href="${rev.u}" target="_blank" rel="noopener">Review: ${esc(rev.n)} ↗</a>`:""}${dir}<button class="btn small" data-eatarea="${p.aid}">All food here</button></div>${web?"":`<p class="hint" style="font-size:12.5px">No official website we could confirm, so the main link is the critic's review.</p>`}`}
 if(p.kind==="night"){const st=nightStatus(o,n);
  return head(`${esc(o.kind)} · ${esc(o.where)}`,st)+`<p class="mc-sum">${esc(p.summary)}</p><div class="mc-btns"><button class="btn primary small" ${p.open}>Read more</button>${dir}</div>`}
 const st=o.hours?placeStatus(o,n):o.outdoor?{s:"open",t:"Open-air"}:null;const wk=p.stopId?walkOfStop(p.stopId):null;
 return head(`${p.kind==="stop"?"Walk stop":"Site"} · ${esc(p.area)}${p.visited?" · visited ✓":""}`,st)+`<p class="mc-sum">${esc(p.summary)}</p>
  ${o.time||o.cost?`<p class="hint mc-sum">${[o.time?"Time: "+esc(o.time):"",o.cost?"Cost: "+esc(o.cost):""].filter(Boolean).join(" · ")}</p>`:""}
  <div class="mc-btns"><button class="btn primary small" ${p.open}>Read the write-up</button>${dir}${wk?`<button class="btn small" data-walkfrom="${wk.w.id}:${wk.j}">Start walk here</button>`:""}${i!=null?`<button class="btn small" data-herepin="${i}">I'm here</button>`:""}</div>`}
function vibeHTML(a){if(!a||!a.vibe)return "";return `<span class="vibe"><b class="vlbl">Vibe</b> ${esc(a.vibe)}</span><span class="good" aria-label="Good for">${(a.good||[]).map(g=>`<i>${esc(g)}</i>`).join("")}</span>`}
function areaCardHTML(a){const d=AD[a.id];return `<div class="mc-top"><div class="mc-h"><span class="kicker">Area</span><b class="mc-name">${esc(a.name)}</b></div><button class="back" data-mapclose aria-label="Close">×</button></div><p class="mc-sum">${esc(d.tagline||"")}</p><div class="mc-btns"><button class="btn primary small" data-openarea="${a.id}">Open ${esc(a.name)}</button></div>`}
function showMapCard(p,i){const c=document.getElementById("mapcard");if(!c)return;c.innerHTML=mapCardHTML(p,i);c.hidden=false}
function showAreaCard(a){const c=document.getElementById("mapcard");if(!c)return;c.innerHTML=areaCardHTML(a);c.hidden=false}
function homeMapHTML(){const real=!!(window.L&&!window.__ARTIFACT__);
 return `<section class="mapwrap" aria-label="Map of the guide's areas and sites"><div id="cmap" class="cmap"></div>
  <div class="mapbtns"><button data-mapzoom="1" aria-label="Zoom in">+</button><button data-mapzoom="-1" aria-label="Zoom out">−</button>${real&&navigator.geolocation?`<button data-maplocate aria-label="Show my location" title="Show my location">◎</button>`:""}<button data-mapfit aria-label="Show everything" title="Show everything">⤢</button></div>
  <div class="maplayers" role="group" aria-label="Show on map">${[["sites","Sights"],["food","Food"],["night","Night"]].map(([k,l])=>`<button class="chip" aria-pressed="${(S.mapLayers||["sites","food","night"]).includes(k)}" data-maplayer="${k}">${l}</button>`).join("")}</div>
  <div id="mapcard" class="mapcard" hidden></div></section>
 <p class="hint maplegend"><span class="dot stop"></span>Walk stop <span class="dot site"></span>Site <span class="dot food"></span>Food <span class="dot night"></span>Night <span class="dot visited"></span>Visited <span class="ring"></span>Area coming next · ${real?"Pins are placed from addresses and may be off by a few doors; Directions uses the address.":"Drawn map: streets are simplified. Pins are placed from addresses; Directions uses the address."}</p>`}

function initHomeMap(){
 if(LMAP){LMAP.remove();LMAP=null}SMAP=null;
 const el=document.getElementById("cmap");if(!el)return;
 if(window.L&&!window.__ARTIFACT__){try{return leafletMap(el)}catch(e){}}
 svgMap(el)}

/* ----- real map (standalone) ----- */
function leafletMap(el){
 const acc=cssVar("--accent"),jade=cssVar("--accent-2"),gold=cssVar("--warn"),muted=cssVar("--muted");
 LMAP=L.map(el,{zoomControl:false,attributionControl:true});
 const tiles=L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,crossOrigin:"anonymous",attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors'}).addTo(LMAP);
 let loaded=0,failed=0;tiles.on("tileload",()=>{loaded++;window.__tiles=(window.__tiles||0)+1});tiles.on("tileerror",()=>{failed++;window.__tileErr=(window.__tileErr||0)+1;if(failed>6&&!loaded){LMAP.remove();LMAP=null;el.innerHTML="";svgMap(el)}});
 AREAS.forEach(a=>{const live=!!AD[a.id];L.circle(a.c,{radius:a.r,color:live?acc:muted,weight:2,dashArray:live?null:"6 6",fillColor:live?acc:muted,fillOpacity:live?.06:.03,interactive:false}).addTo(LMAP).bindTooltip(a.name,{permanent:true,direction:"center",className:"area-label"+(live?"":" soon")})});
 mapPins().forEach((p,i)=>{const col=p.visited?gold:cssVar(PINCOL[p.kind]);const m=L.circleMarker(p.ll,{radius:8,color:"#fff",weight:2,fillColor:col,fillOpacity:1}).addTo(LMAP).bindTooltip(p.name,{direction:"top",offset:[0,-6]});const hit=L.circleMarker(p.ll,{radius:20,stroke:false,fillOpacity:0}).addTo(LMAP);const go=ev=>{L.DomEvent.stopPropagation(ev);showMapCard(p,i)};m.on("click",go);hit.on("click",go)});
 if(MAPVIEW&&MAPVIEW.c)LMAP.setView(MAPVIEW.c,MAPVIEW.z);else fitAll();
 LMAP.on("moveend",()=>{const c=LMAP.getCenter();MAPVIEW={c:[c.lat,c.lng],z:LMAP.getZoom()}});
 LMAP.on("click",()=>{const c=document.getElementById("mapcard");if(c)c.hidden=true});
}
function fitAll(){const live=AREAS.filter(a=>AD[a.id]&&!a.far);
 if(LMAP){LMAP.fitBounds(L.latLngBounds(live.map(a=>L.latLng(a.c).toBounds(a.r*2.2))).pad(.05));return}
 if(SMAP)SMAP.fit()}

/* ----- drawn map (inside Claude, or offline without Leaflet) ----- */
const MERC=([lat,lng])=>{const s=Math.sin(lat*Math.PI/180);return [(lng+180)/360*65536,(.5-Math.log((1+s)/(1-s))/(4*Math.PI))*65536]};
const MPU=lat=>40075016*Math.cos(lat*Math.PI/180)/65536; /* meters per base unit */
const STREETS=[
 {n:"Paseo de la Reforma",pts:[[19.4367,-99.1478],[19.4335,-99.1545],[19.4290,-99.1610],[19.4270,-99.1677],[19.4243,-99.1726],[19.4237,-99.1789],[19.4263,-99.1858],[19.4280,-99.1925]]},
 {n:"Madero / Juárez",pts:[[19.4334,-99.1338],[19.4340,-99.1405],[19.4348,-99.1420],[19.4367,-99.1478]]}];
const FOREST=[[[19.4245,-99.1772],[19.4278,-99.1880],[19.4238,-99.1955],[19.4165,-99.1950],[19.4135,-99.1845],[19.4185,-99.1765]],[[19.4165,-99.1950],[19.4175,-99.2120],[19.4040,-99.2120],[19.4045,-99.1960]]];
function svgMap(el){
 const pins=mapPins(),acc=cssVar("--accent");
 const V={x:0,y:0,s:1};
 const W=()=>el.clientWidth||360,H=()=>el.clientHeight||420;
 const toScr=ll=>{const [x,y]=MERC(ll);return [(x-V.x)*V.s+W()/2,(y-V.y)*V.s+H()/2]};
 function fit(){const live=AREAS.filter(a=>AD[a.id]&&!a.far);let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
  live.forEach(a=>{const [x,y]=MERC(a.c),r=a.r/MPU(a.c[0]);x0=Math.min(x0,x-r);x1=Math.max(x1,x+r);y0=Math.min(y0,y-r);y1=Math.max(y1,y+r)});
  V.x=(x0+x1)/2;V.y=(y0+y1)/2;V.s=Math.min(W()/(x1-x0),H()/(y1-y0))*.8;draw()}
 function draw(){
  const showNames=V.s>90;
  const poly=pts=>pts.map(p=>toScr(p).map(n=>n.toFixed(1)).join(",")).join(" ");
  el.innerHTML=`<svg class="smap" width="100%" height="100%" role="img" aria-label="Drawn map of the guide's areas and sites">
   <rect width="100%" height="100%" fill="var(--soft)"/>
   ${FOREST.map(f=>`<polygon points="${poly(f)}" fill="var(--jade-soft)" stroke="var(--accent-2)" stroke-opacity=".3"/>`).join("")}
   ${STREETS.map(s=>`<polyline points="${poly(s.pts)}" fill="none" stroke="var(--paper)" stroke-width="${Math.max(4,Math.min(12,V.s*3))}" stroke-linecap="round" stroke-linejoin="round"/>`).join("")}
   ${V.s>40?STREETS.map(s=>{const [x,y]=toScr(s.pts[Math.floor(s.pts.length/2)]);return `<text x="${x}" y="${y-8}" font-size="11" font-family="Archivo,sans-serif" fill="var(--muted)" text-anchor="middle">${esc(s.n)}</text>`}).join(""):""}
   ${AREAS.map(a=>{const live=!!AD[a.id],[x,y]=toScr(a.c),r=a.r/MPU(a.c[0])*V.s;if(x+r<-50||x-r>W()+50||y+r<-50||y-r>H()+50)return "";return `<g ${live?`data-maparea="${a.id}" style="cursor:pointer"`:""}><circle cx="${x}" cy="${y}" r="${r}" fill="${live?(LINECOL[a.id]||"var(--accent)"):"var(--muted)"}" fill-opacity="${live?.08:.04}" stroke="${live?(LINECOL[a.id]||"var(--accent)"):"var(--muted)"}" stroke-width="3" ${live?"":`stroke-dasharray="6 6"`}/><text x="${x}" y="${y-r-6>14?y-r-6:y}" text-anchor="middle" font-size="13.5" font-weight="800" font-family="Archivo,sans-serif" fill="${live?(LINECOL[a.id]||"var(--accent)"):"var(--muted)"}" stroke="var(--soft)" stroke-width="4" paint-order="stroke">${esc(a.name)}${live?"":" · soon"}</text></g>`}).join("")}
   ${(()=>{const boxes=[],pts=pins.map(p=>toScr(p.ll));pts.forEach(([x,y])=>boxes.push([x-8,y-8,x+8,y+8]));const hit=b=>boxes.some(o=>b[0]<o[2]&&b[2]>o[0]&&b[1]<o[3]&&b[3]>o[1]);
    return pins.map((p,i)=>{const [x,y]=pts[i];if(x<-20||x>W()+20||y<-20||y>H()+20)return "";let lab="";
     if(showNames){const w=p.name.length*6.3,b=[x+9,y-8,x+12+w,y+7];const own=boxes.indexOf(boxes.find(o=>o[0]===x-8&&o[1]===y-8));const others=boxes.filter((o,k)=>k!==i);if(!others.some(o=>b[0]<o[2]&&b[2]>o[0]&&b[1]<o[3]&&b[3]>o[1])){boxes.push(b);lab=`<text x="${x+10}" y="${y+4}" font-size="11.5" font-family="Archivo,sans-serif" fill="var(--ink)" stroke="var(--soft)" stroke-width="3" paint-order="stroke">${esc(p.name)}</text>`}}
     return `<g data-mappin="${i}" style="cursor:pointer"><circle cx="${x}" cy="${y}" r="20" fill="transparent"/><circle cx="${x}" cy="${y}" r="7" fill="${p.visited?"var(--warn)":`var(${PINCOL[p.kind]})`}" stroke="var(--paper)" stroke-width="2"/>${lab}</g>`}).join("")})()}
  </svg>`}
 function zoomAt(f,px,py){const w=W(),h=H();px=px==null?w/2:px;py=py==null?h/2:py;const bx=V.x+(px-w/2)/V.s,by=V.y+(py-h/2)/V.s;V.s=Math.max(2,Math.min(6000,V.s*f));V.x=bx-(px-w/2)/V.s;V.y=by-(py-h/2)/V.s;draw();MAPVIEW={svg:{...V}}}
 const pt=e=>{const r=el.getBoundingClientRect();return [e.clientX-r.left,e.clientY-r.top]};
 const ptrs=new Map();let moved=0,last=null;
 el.style.touchAction="none";
 el.onpointerdown=e=>{el.setPointerCapture(e.pointerId);ptrs.set(e.pointerId,pt(e));moved=0;last=null};
 el.onpointermove=e=>{if(!ptrs.has(e.pointerId))return;const prev=ptrs.get(e.pointerId),q=pt(e);ptrs.set(e.pointerId,q);
  if(ptrs.size===1){const dx=q[0]-prev[0],dy=q[1]-prev[1];moved+=Math.abs(dx)+Math.abs(dy);V.x-=dx/V.s;V.y-=dy/V.s;draw()}
  else if(ptrs.size===2){const [a,b]=[...ptrs.values()],d=Math.hypot(a[0]-b[0],a[1]-b[1]);moved+=10;if(last)zoomAt(d/last,(a[0]+b[0])/2,(a[1]+b[1])/2);last=d}};
 const up=e=>{const wasTap=ptrs.size===1&&moved<6;ptrs.delete(e.pointerId);if(ptrs.size<2)last=null;MAPVIEW={svg:{...V}};
  if(!wasTap)return;const t=document.elementFromPoint(e.clientX,e.clientY),g=t&&t.closest("[data-mappin],[data-maparea]");
  if(g&&g.dataset.mappin!==undefined)showMapCard(pins[+g.dataset.mappin],+g.dataset.mappin);
  else if(g&&g.dataset.maparea){const a=AREAS.find(x=>x.id===g.dataset.maparea);if(a)showAreaCard(a)}
  else{const c=document.getElementById("mapcard");if(c)c.hidden=true}};
 el.onpointerup=up;el.onpointercancel=e=>{ptrs.delete(e.pointerId);last=null};
 el.onwheel=e=>{e.preventDefault();const q=pt(e);zoomAt(Math.exp(-e.deltaY*.0015),q[0],q[1])};
 SMAP={zoom:f=>zoomAt(f),fit};
 if(MAPVIEW&&MAPVIEW.svg){Object.assign(V,MAPVIEW.svg);draw()}else{fit();requestAnimationFrame(fit)}
}

function locateMe(){if(!LMAP||!navigator.geolocation)return;
 navigator.geolocation.getCurrentPosition(pos=>{const ll=[pos.coords.latitude,pos.coords.longitude];
  if(window._meMarker)window._meMarker.remove();
  window._meMarker=L.circleMarker(ll,{radius:9,color:"#fff",weight:3,fillColor:"#2b6cb0",fillOpacity:1}).addTo(LMAP).bindTooltip("You are here");
  LMAP.setView(ll,Math.max(LMAP.getZoom(),15))},
  ()=>{const c=document.getElementById("mapcard");if(c){c.innerHTML=`<span class="hint">Location isn't available. Check that this site may use your location in your phone's settings.</span>`;c.hidden=false}},{enableHighAccuracy:true,timeout:10000})}

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.mapzoom){if(LMAP)d.mapzoom==="1"?LMAP.zoomIn():LMAP.zoomOut();else if(SMAP)SMAP.zoom(d.mapzoom==="1"?1.6:1/1.6);return}
 if(b.hasAttribute("data-mapfit")){MAPVIEW=null;fitAll();return}
 if(b.hasAttribute("data-maplocate")){locateMe();return}
 if(d.maplayer){const L=S.mapLayers||["sites","food","night"],k=d.maplayer;S.mapLayers=L.includes(k)?L.filter(x=>x!==k):L.concat(k);save();MAPVIEW=MAPVIEW||null;render();return}
 if(d.openarea){useArea(d.openarea);areaTab="see";nav({v:"area",a:d.openarea});return}
 if(b.hasAttribute("data-mapclose")){const c=document.getElementById("mapcard");if(c)c.hidden=true;return}});
