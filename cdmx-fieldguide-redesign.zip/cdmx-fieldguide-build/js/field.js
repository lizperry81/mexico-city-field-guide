/* The Field: learning in the physical city.
   - vField: the Field landing (near you, walks, museums, missions, ask about a photo)
   - vNear: places around you, ranked by distance, each with one line on why it matters
   - placePage: the Walking Professor. Every place opens in three registers:
       Tell me the story · Teach me to look · Go deeper
     plus practicalities. It replaces the earlier article-card place page and reuses its parts. */
function vField(){const J=journal();const walks=[];for(const aid in AD)AD[aid].walks.forEach(w=>walks.push([aid,w]));
 return `<section class="storyhead"><span class="eyebrow">The Field</span><h1>Learn it on the ground</h1><p class="lede">Walks with a professor at your side, museums decoded, and missions that teach you to read the street.</p></section>
 <section class="nearrow"><button class="btn primary" data-go="near:">What's around me?</button><button class="btn" data-askphoto>Ask about a photo</button></section>
 <section><h2 class="sech">Walks</h2><div class="walklist">${walks.map(([a,w])=>{const ws=walkStops(w),done=ws.filter(x=>S.visited.includes(x)).length;return `<button class="walkline" style="--line:${LINECOL[a]}" data-walkfrom="${w.id}:0"><span class="linebadge">${LINECODE[a]}</span><span class="wlt"><b>${esc(w.name)}</b><span>${esc(AD[a].name)} · ${esc(w.time.replace(/^About /,""))} · ${ws.length} stops${done?` · ${done} seen`:""}</span>${w.q?`<i>${esc(w.q)}</i>`:""}</span></button>`}).join("")}</div></section>
 <section><h2 class="sech">Museum decoder</h2>${`<div class="qlist">${MUSEUMS.filter(m=>!m.gap).map(m=>`<button class="qcard" data-museum="${m.id}"><span class="eyebrow">${esc(m.museum)}</span><span class="qq">${esc(m.title)}</span></button>`).join("")}</div>`}<p><button class="linkbtn" data-go="museums:">All museum investigations</button></p></section>
 <section><h2 class="sech">Field missions</h2>${missionList()}</section>
 <section><h2 class="sech">By question</h2><div class="qlist">${QUESTIONS.map(q=>`<button class="qcard" data-question="${q.id}"><span class="qq">${esc(q.q)}</span></button>`).join("")}</div></section>`}

function vNear(){const c=ctxNow();
 if(!c.here)return `<section class="storyhead"><span class="eyebrow">Around me</span><h1>What's around you?</h1><p class="lede">Set where you are and the guide lists the nearest places that have a story to tell, with the one thing to know about each.</p></section>
 <section class="nearrow">${!window.__ARTIFACT__&&navigator.geolocation?`<button class="btn primary" data-heregps>Use my location</button>`:""}<button class="btn" data-nav="explore">Pick a spot on the map</button></section>
 <p class="hint">On a walk, the guide follows your stops automatically. Inside Claude, location isn't available, so choose a pin on the map and tap "I'm here".</p>`;
 const pl=placesNow(c).filter(p=>p.d!=null).sort((a,b)=>a.d-b.d).slice(0,12);
 return `<section class="storyhead"><span class="eyebrow">Around me · near ${esc(c.here.label)}</span><h1>Within reach</h1><p class="lede">The closest places with something to teach. Distances are straight-line.</p></section>
 <div class="placelist">${pl.map(p=>{const m=getStop(p.id)||siteById(p.id)||{};const s=STORIES.find(s=>(s.places||[]).includes(p.id));return `<button class="placerow tall" style="--line:${LINECOL[p.area]}" ${p.open}><span class="dotl"></span><b>${esc(p.name)}</b><span>${distText(p.d)} · ${esc(p.st.t)}</span><span class="why">${esc(m.what||m.summary||"")}</span>${s?`<span class="instory">In the story: ${esc(s.title)}</span>`:""}</button>`}).join("")}</div>
 <p><button class="linkbtn" data-hereclear>Change where I am</button></p>`}

/* ---------- The Walking Professor ---------- */
const PMODES=[["story","Tell me the story"],["look","Teach me to look"],["deeper","Go deeper"]];
function speakable(){return typeof window.speechSynthesis!=="undefined"&&typeof SpeechSynthesisUtterance!=="undefined"}
function placePage(kind,id){
 const fn=new Footnotes(),now=mxNow();
 const st=kind==="stop"?getStop(id):siteById(id);
 const site=kind==="stop"?(st.siteRef?siteById(st.siteRef):null):st;
 const aid=kind==="stop"?STOPIDX[id]:SITEIDX[id],area=AD[aid];
 const L=(kind==="stop"?(st.lead||st.read):st.read)||[];
 const P={story:[],look:[],plain:[],ctx:[],prac:[],route:[],after:[],where:null};let sec=null;
 L.forEach(b=>{if(b.sec){sec=b.sec;return}if(b.where){P.where=b;return}if(b.ctx){P.ctx.push(b.ctx);return}
  if(sec==="Before you go in"){P.prac.push(b);return}if(sec==="Your route"){P.route.push(b);return}if(sec==="After"){P.after.push(b);return}
  if(b.pt){(b.pt.look?P.look:P.story).push(b);return}if(b.gobtns)return;P.plain.push(b)});
 if(kind==="stop"&&st.read&&st.read!==st.lead){(st.read||[]).forEach(b=>{if(b.pt&&!L.some(x=>x.pt&&x.pt.h===b.pt.h))(b.pt.look?P.look:P.story).push(b)})}
 P.story.sort((a,b)=>(a.pt.ord??99)-(b.pt.ord??99));
 const more=(kind==="stop"?st.more:[])||[];
 const mode=PMODES.some(m=>m[0]===S.pmode)?S.pmode:"story";
 const take=st.take||(site&&site.take);
 const stories=STORIES.filter(s=>(s.places||[]).includes(id)||(st.siteRef&&(s.places||[]).includes(st.siteRef)));
 let walkBtn="";for(const w of area.walks){const ws=walkStops(w);const j=ws.findIndex(s=>s===id||(area.stops[s]&&area.stops[s].siteRef===id));if(j>=0){walkBtn=`<button class="btn small" data-walk="${w.id}" data-step="${j}">On the walk "${esc(w.name)}", stop ${j+1}</button>`;break}}
 const hrsX=st.hours?st:site&&site.hours?site:null;const open=hrsX?siteOpen(hrsX,now):(st.outdoor?true:null);const cost=(site&&site.cost)||st.cost;
 const timeNeed=st.time||(kind==="site"&&typeof visitMins==="function"?fmtDur(visitMins({id})/60):"");

 /* Tell me the story: the dated history as one continuous narrative */
 const storyPts=P.story.length?P.story:[];
 const storyHTML=storyPts.length?storyPts.map(b=>`<section class="beat">${b.pt.when?`<span class="when">${esc(b.pt.when)}</span>`:""}<h3>${esc(b.pt.h)}</h3>${b.pt.blocks.map(x=>blockHTML(x,fn)).join("")}</section>`).join(""):P.plain.map(b=>blockHTML(b,fn)).join("");
 const storyBody=storyHTML?`<div class="pnarr">${storyHTML}</div>${take?blockHTML({take},fn):""}`:`<p class="empty">The guide doesn't have a dated history for this place yet.</p>`;
 /* Teach me to look */
 const findL=st.find&&st.find.length?`<h3 class="ph">Find these</h3><ul class="findlist">${st.find.map((t,j)=>{const fd=((S.found||{})[id]||[]).includes(j);return `<li><button class="findbtn" data-found="${id}" data-fi="${j}" aria-pressed="${fd}"><span class="fbox" aria-hidden="true">${fd?"✓":""}</span><span>${esc(t)}</span></button></li>`}).join("")}</ul>`:"";
 const lookBody=[st.spot?`<p class="spotline"><b>How to spot it.</b> ${esc(st.spot)}</p>`:"",P.where?`<p class="spotline"><b>Where to stand.</b> ${esc(P.where.where)}</p>`:"",findL,
  P.look.map(b=>`<section class="beat"><h3>${esc(b.pt.h)}</h3>${b.pt.blocks.map(x=>blockHTML(x,fn)).join("")}${(b.pt.more||[]).map(m=>`<details class="ptmore"><summary>${esc(m.label==="More"?"More":m.label)}</summary>${m.blocks.map(x=>blockHTML(x,fn)).join("")}</details>`).join("")}</section>`).join(""),
  storyPts.length?P.plain.map(b=>blockHTML(b,fn)).join(""):"",
  P.route.length?`<h3 class="ph">A route through it</h3>${P.route.map(b=>blockHTML(b,fn)).join("")}`:"",tourCard(st),
  `<div class="mc-btns"><button class="mchip" data-askmode="art" data-askq="${esc("Teach me how to look at "+st.name+": what details should I notice?")}" data-askctxid="${id}">Ask the art and architecture expert</button></div>`].join("");
 /* Go deeper */
 const deb=contested(L.concat(st.read||[],more,(site&&site.read)||[]));
 const ctxs=P.ctx.map(c=>ctxById(c)).filter(Boolean);
 const deeperBody=[
  storyPts.some(b=>(b.pt.more||[]).length)?`<h3 class="ph">More detail</h3>${storyPts.filter(b=>(b.pt.more||[]).length).map(b=>(b.pt.more||[]).map(m=>`<details class="ptmore"><summary>${esc(b.pt.h)}: ${esc(m.label==="More"?"more":m.label)}</summary>${m.blocks.map(x=>blockHTML(x,fn)).join("")}</details>`).join("")).join("")}`:"",
  deb.length?`<h3 class="ph">What's debated or unknown</h3>${deb.map(d=>blockHTML({p:d.p},fn)).join("")}`:"",
  ctxs.length?`<h3 class="ph">The bigger history</h3>${P.ctx.map(c=>ctxBlockHTML(c,fn)).join("")}`:"",
  stories.length?`<h3 class="ph">Part of these stories</h3><div class="hscroll">${stories.map(storyTile).join("")}</div>`:"",
  threadChips(id),
  more.length?`<h3 class="ph">Nearby, if you have time</h3>${more.map(b=>blockHTML(b,fn)).join("")}`:"",
  `<h3 class="ph">Question it</h3><div class="mc-btns">${[["people","Whose perspective is missing from this place's story?"],["skeptic","What do we actually know, and how?"],["story","Tell me the story of this place"]].map(([m,q])=>`<button class="mchip" data-askmode="${m}" data-askq="${esc(q)}" data-askctxid="${id}">${esc(q)}</button>`).join("")}</div>`].join("");
 const bodies={story:storyBody,look:lookBody,deeper:deeperBody};
 const mins=readMins(bodies[mode]);
 const plan=`<div class="kv"><div class="meta">${openPill(open)}</div>
  <p><b>Hours.</b> ${hrsX?esc(siteHours(hrsX))+(hrsX.hsrc?" "+srcTag([hrsX.hsrc]):""):st.outdoor?"Open-air, no set hours.":"Hours not published; check before you go."}</p>${hrsX||cost?`<p>${freshHTML(hrsX&&hrsX.hsrc?[hrsX.hsrc]:[],site?site.id:id)}</p>`:""}${site&&site.hoursNote?`<p class="hint">${esc(site.hoursNote)}</p>`:""}
  ${cost?`<p><b>Cost.</b> ${esc(cost)}</p>`:""}${timeNeed?`<p><b>Time needed.</b> ${esc(timeNeed)}</p>`:""}
  <p><b>Where.</b> ${site&&site.addr?esc(site.addr)+" · ":""}<a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(st.name+" Ciudad de México")}" target="_blank" rel="noopener">Map ↗</a> · <a href="${dirURL(kind==="stop"?st:Object.assign({},st))}" target="_blank" rel="noopener">Directions ↗</a></p></div>
  ${P.prac.map(b=>blockHTML(b,fn)).join("")}${P.after.map(b=>blockHTML(b,fn)).join("")}${st.voices?voicesHTML(st.voices):""}
  ${st.rec||st.ta?`<div class="ratingsline"><span class="kind">Editorial rating:</span>${recHTML(st.rec)}<span class="kind">Tripadvisor aggregate:</span>${starsHTML(st.ta)}</div>`:""}`;
 const notes=notesFor("place:"+id);
 return `<section class="placehead" style="--line:${LINECOL[aid]||"var(--accent)"}">
  <div class="pband">${kind==="stop"?stopArt(id,st):(ILLCAT[st.cat]||ILLCAT.museum)}</div>
  <span class="eyebrow">${esc(aid==="teo"?"Day trip · Teotihuacan":area.name)}${st.types?" · "+esc(st.types.join(", ")):""}</span>
  <h1>${esc(st.name)}</h1><p class="placedek">${esc(st.what||st.summary||"")}</p>
  <div class="storyacts">${saveBtn("place",id)}${walkBtn}${st.photos?`<a class="btn small" href="${st.photos}" target="_blank" rel="noopener">Photos ↗</a>`:""}</div></section>
 <div class="profseg" role="tablist" aria-label="How much do you want">${PMODES.map(([k,l])=>`<button role="tab" aria-selected="${k===mode}" data-pmode="${k}">${l}</button>`).join("")}</div>
 <div class="profmeta"><span>${mins} min read</span>${mode==="story"&&speakable()&&storyHTML?`<button class="linkbtn" data-speak>▶ Listen</button>`:""}</div>
 <article class="prof" id="profbody">${bodies[mode]}</article>
 <details class="practical"><summary><span>Visiting</span><span class="hint">${esc([hrsX?(open?"Open now":"Closed now"):st.outdoor?"Open-air":"",cost?cost.split(/[.;]/)[0]:""].filter(Boolean).join(" · "))}</span></summary>${plan}</details>
 ${communityBlockHTML(id,st.name)}
 <p class="edline">${edStatusHTML(kind==="stop"?"place":"place",id)} · <button class="linkbtn" data-go="howknow:">How do we know?</button></p>
 <section class="jsec"><h2 class="sech">Your notes here</h2>${noteList(notes)}${noteForm("place:"+id)}${typeof photoSlotHTML==="function"?photoSlotHTML(id):""}</section>
 ${LEGEND}${fn.html()}`}

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.pmode){S.pmode=d.pmode;save();if(speakable())speechSynthesis.cancel();render();const el=document.querySelector(".profseg");if(el)el.scrollIntoView({block:"start"});return}
 if(b.hasAttribute("data-speak")){if(!speakable())return;if(speechSynthesis.speaking){speechSynthesis.cancel();b.textContent="▶ Listen";return}const el=document.getElementById("profbody");if(!el)return;const c=el.cloneNode(true);c.querySelectorAll("sup,.tag").forEach(x=>x.remove());const u=new SpeechSynthesisUtterance(c.innerText);u.lang="en-US";u.rate=.98;u.onend=()=>{b.textContent="▶ Listen"};speechSynthesis.speak(u);b.textContent="■ Stop";return}
 if(b.hasAttribute("data-askphoto")){nav({v:"ask"});setTimeout(()=>{const i=document.getElementById("askphoto");if(i)i.click()},60);return}});
