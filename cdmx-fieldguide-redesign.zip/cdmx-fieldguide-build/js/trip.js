/* Trip tab: your dates, the holiday season, city basics and safety, sample days,
   progress backup, and a phone check. Data comes from core.json (season, basics, days, tripBook). */
let SEASON=null,BASICS=null,DAYS=[],TRIPBOOK=[];

function seasonFor(k){return SEASON?SEASON.events.filter(e=>e.dates.includes(k)):[]}
function daysFitting(di){return DAYS.filter(d=>{if(!d.dows.includes(di.dow))return false;const a=AD[d.area];if(!a)return false;return !(a.closures||[]).some(c=>c.lvl==="no"&&((c.dows&&c.dows.includes(di.dow))||(c.dates&&c.dates.includes(di.k))))})}
function resolveStep(ref,area){const [k,v]=ref.split(":");
 if(k==="stop"){const st=getStop(v);return st?{name:st.name,btn:`data-stop="${v}"`,kind:"Walk stop"}:null}
 if(k==="site"){const s=siteById(v);return s?{name:s.name,btn:`data-more="${v}"`,kind:"Site"}:null}
 if(k==="food"){const f=AD[area].food.find(x=>x.name===v);return f?{name:f.name,btn:`data-eatarea="${area}"`,kind:"Food",f}:null}
 return null}

function vTrip(){const fn=new Footnotes();
 const days=tripIdx().map(i=>{const di=dayInfo(i),ev=seasonFor(di.k),fit=daysFitting(di);
  const closed=Object.values(AD).flatMap(a=>(a.closures||[]).filter(c=>c.lvl==="no"&&((c.dows&&c.dows.includes(di.dow))||(c.dates&&c.dates.includes(di.k)))).map(c=>a.name));
  return `<div style="display:grid;gap:6px;border-top:1px solid var(--rule);padding-top:10px"><strong>Day ${i+1} · ${esc(di.label)}</strong>
   <button class="linkbtn" style="justify-self:start;text-align:left" data-itday="${isoOf(di.d)}">Itinerary: ${esc(itinDay(isoOf(di.d)).title||"add plans")} →</button>
   ${ev.length?`<span class="hint">${ev.map(e=>`<span class="pill warn">Season</span> ${esc(e.name)}`).join(" ")}</span>`:""}
   ${closed.length?`<span class="hint"><span class="pill no">Closures</span> Main museums closed in ${esc([...new Set(closed)].join(" and "))}.</span>`:""}
   ${(Object.values(AD).flatMap(a=>(a.closures||[]).filter(c=>c.lvl==="warn"&&c.dates&&c.dates.includes(di.k)).map(c=>`<span class="hint"><span class="pill warn">Holiday hours</span> ${esc(a.name)}: ${esc(c.t)}</span>`))).join("")}
   ${(S.plan||{})[di.k]&&DAYS.find(x=>x.id===S.plan[di.k])?`<span class="hint"><span class="pill ok">Planned</span> ${esc(DAYS.find(x=>x.id===S.plan[di.k]).name)} <button class="linkbtn" data-unplan="${di.k}">Clear</button></span>`:""}
   ${fit.length?`<span class="hint">Sample days that work on this date (open, nothing closed). Tap one to see it and plan it here:</span><div class="chips">${fit.map(d=>`<button class="chip" data-day="${d.id}">${esc(d.name)} →</button>`).join("")}</div>`:`<span class="hint">None of the sample days fit; a good day for streets, markets and food.</span>`}</div>`}).join("");
 const B=TRIPBOOK,done=B.filter(b=>S.book.includes(b.id)).length;
 return `<section style="display:grid;gap:8px"><span class="kicker">Your trip</span><h1>Plan around your dates</h1><p class="lede muted">Which sample days fit each date, what's happening in the season, and what's closed.</p></section>
 <div class="area-grid" style="grid-template-columns:1fr">${itinCardHTML()}</div>
 <section class="walkon"><span class="kicker">Day by day</span><p>Build each day from the guide's places and food, ordered by walking distance and opening hours, with what Reddit travelers say about pairing areas.</p><div><button class="btn primary small" data-go="build:">Build your days →</button></div></section>
 <section class="filters"><label class="hint" for="tripStart">First day of your trip</label><input id="tripStart" type="date" value="${esc(S.start)}" style="font:inherit;color:var(--ink);background:var(--paper);border:1px solid var(--rule);border-radius:10px;padding:8px 10px"><label class="hint" for="tripEnd">Last day (you fly home)</label><input id="tripEnd" type="date" value="${esc(S.end)}" min="${esc(S.start)}" style="font:inherit;color:var(--ink);background:var(--paper);border:1px solid var(--rule);border-radius:10px;padding:8px 10px">${days}</section>
 <div class="area-grid">
  <button class="area-card" data-go="season:"><span class="badge live">Dec 12 – Jan 6</span><b>The holiday season</b><span>Posadas, Nochebuena, New Year and Reyes: what happens and what to eat.</span></button>
  <button class="area-card" data-go="basics:"><span class="badge live">Read first</span><b>City basics and safety</b><span>Airport, Metro, taxis, safety, altitude, water, money and tipping.</span></button></div>
 <section style="display:grid;gap:10px"><span class="kicker">Sample days</span><h2>Ready-made days</h2><p class="hint">Built from the walks and food picks, with times set by opening hours.</p>
  <div class="food-grid">${DAYS.map(d=>`<button class="food" style="text-align:left" data-day="${d.id}"><div class="food-h"><b style="font-size:18px">${esc(d.name)}</b><span class="price">${esc(AD[d.area].name)}</span></div><p class="hint">${esc(d.summary)}</p><p class="hint">Works ${esc(dayRange(d.dows))}</p></button>`).join("")}</div></section>
 <section class="filters"><div style="display:flex;justify-content:space-between;align-items:baseline;gap:10px"><span class="kicker">Before you go</span><span class="hint">${done} of ${B.length} done</span></div>
  <div style="display:grid;gap:8px">${B.map(b=>`<label style="display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:start;font-size:14.5px"><input type="checkbox" data-book="${b.id}" ${S.book.includes(b.id)?"checked":""} style="margin-top:3px;accent-color:var(--accent)"><span>${esc(b.t)}${fn.mark(b.s)}</span></label>`).join("")}</div><p class="hint">Each area also has its own checklist.</p></section>${fn.html()}
 <section class="filters"><span class="kicker">Where you're staying</span><p class="hint">Used by "Take a break" to get you back. Stored on this device.</p>${S.hotel?`<p>${esc(S.hotel)} <button class="linkbtn" data-hotelchange>Change</button></p>`:`<form id="hotelForm2" class="search"><label for="hotelin2" style="position:absolute;left:-9999px">Hotel</label><input id="hotelin2" placeholder="Hotel name or address" autocomplete="off"><button type="submit">Save</button></form>`}</section>
 ${progressHTML()}${phoneCheckHTML()}`}

function vSeason(){const fn=new Footnotes();
 return `<section style="display:grid;gap:8px"><span class="kicker">The holiday season</span><h1>Guadalupe to Reyes</h1></section>
 <article class="article">${LEGEND}${SEASON.intro.map(([t,s,g])=>`<p>${esc(t)}${fn.mark(s)} ${tagHTML(g)}</p>`).join("")}
 ${SEASON.events.map(e=>{const mine=tripIdx().map(i=>dayInfo(i)).filter(di=>e.dates.includes(di.k));return `<h3>${esc(e.name)} <span class="hint" style="font-family:var(--f-ui);font-size:14px;font-weight:600">· ${esc(e.when)}${mine.length?` · on your trip (${mine.map(d=>esc(d.label)).join(", ")})`:""}</span></h3>
  ${e.p.map(([t,s,g])=>`<p>${esc(t)}${fn.mark(s)} ${tagHTML(g)}</p>`).join("")}
  ${e.eat?`<div class="callout take"><span class="lbl">What to eat</span><span>${esc(e.eat[0])}${fn.mark(e.eat[1])}</span></div>`:""}`}).join("")}
 ${SEASON.unknown.map(([t,s,g])=>`<p>${esc(t)}${fn.mark(s)} ${tagHTML(g)}</p>`).join("")}</article>${fn.html()}`}

function vBasics(){const fn=new Footnotes();
 return `<section style="display:grid;gap:8px"><span class="kicker">City basics</span><h1>Getting around and staying safe</h1><p class="lede muted">${esc(BASICS.intro)}</p></section>${LEGEND}
 ${BASICS.sections.map(s=>`<section class="filters"><span class="kicker">${esc(s.h)}</span><dl style="display:grid;grid-template-columns:auto 1fr;gap:10px 14px;margin:0">${s.items.map(([k,v,src,g])=>`<dt style="font-weight:700">${esc(k)}</dt><dd style="margin:0;min-width:0">${esc(v)}${fn.mark(src)} ${tagHTML(g)}</dd>`).join("")}</dl></section>`).join("")}
 ${voicesHTML(BASICS.voices)}${fn.html()}`}

function vDay(){const d=DAYS.find(x=>x.id===cur().id),fits=tripIdx().map(i=>dayInfo(i)).filter(di=>daysFitting(di).includes(d));
 return `<section style="display:grid;gap:8px"><span class="kicker">Sample day · ${esc(AD[d.area].name)}</span><h1>${esc(d.name)}</h1><p class="lede">${esc(d.summary)}</p>
  ${fits.length?`<div class="chips"><span class="hint" style="align-self:center">Plan it for:</span>${fits.map(f=>`<button class="chip" aria-pressed="${(S.plan||{})[f.k]===d.id}" data-plan="${f.k}" data-planday="${d.id}">${esc(f.label)}</button>`).join("")}</div>`:""}
  <p class="hint">${fits.length?`Fits your trip on ${fits.map(f=>esc(f.label)).join(", ")}.`:"Doesn't fit any of your trip days as set; change your start date on the Trip tab."} Works ${esc(dayRange(d.dows))}.</p></section>
 <ol class="thread dayline">${d.steps.map(([t,ref,note],i)=>{if(!ref)return `<li><span class="n">${esc(t)}</span><div style="display:grid;gap:4px;min-width:0"><span class="kicker">Getting there</span><p>${esc(note)}</p></div></li>`;const r=resolveStep(ref,d.area);if(!r)return "";return `<li><span class="n">${esc(t)}</span><div style="display:grid;gap:4px;min-width:0"><span class="kicker">${r.kind}</span><h3>${esc(r.name)}</h3>${note?`<p class="hint">${esc(note)}</p>`:""}${r.f?`<p class="hint">${esc(hoursText(r.f))}</p>`:""}<div><button class="btn small" ${r.btn}>Open →</button></div></div></li>`}).join("")}</ol>
 <p class="hint">Times are suggestions built from the opening hours in this guide. Holiday hours can differ; check the Trip tab for your dates.</p>`}

/* ----- progress backup ----- */
const encodeState=()=>{try{return btoa(unescape(encodeURIComponent(JSON.stringify(S))))}catch(e){return ""}};
const decodeState=c=>{try{return JSON.parse(decodeURIComponent(escape(atob(c.trim()))))}catch(e){return null}};
function progressHTML(){return `<section class="filters" id="progress"><span class="kicker">Your progress</span>
 <p class="hint">${S.visited.length} places visited, ${S.book.length} checklist items done. ${window.__ARTIFACT__?"Inside Claude, progress also saves to your account.":"The phone app saves progress on this device only. Copy this code somewhere safe, or paste it into the app on another device."}</p>
 <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn small" data-export>Show my backup code</button><button class="btn small" data-import>Restore from a code</button></div>
 <div id="progressBox"></div></section>`}
function showExport(){const box=document.getElementById("progressBox");if(!box)return;box.innerHTML=`<textarea id="expCode" readonly rows="3" style="width:100%;font:12px var(--f-mono);border:1px solid var(--rule);border-radius:10px;padding:8px;background:var(--paper);color:var(--ink)">${esc(encodeState())}</textarea><div><button class="btn small" data-copy="expCode">Copy code</button> <span class="hint" id="copyMsg"></span></div>`}
function showImport(){const box=document.getElementById("progressBox");if(!box)return;box.innerHTML=`<textarea id="impCode" rows="3" placeholder="Paste your backup code" style="width:100%;font:12px var(--f-mono);border:1px solid var(--rule);border-radius:10px;padding:8px;background:var(--paper);color:var(--ink)"></textarea><div id="impMsg" class="hint"></div><div><button class="btn small primary" data-impcheck>Restore</button></div>`}
function copyText(id){const t=document.getElementById(id),msg=document.getElementById(id==="diagText"?"copyMsg2":"copyMsg");if(!t)return;
 const fallback=()=>{t.focus();t.select();if(msg)msg.textContent="Selected; copy it with your phone's menu."};
 try{navigator.clipboard.writeText(t.value).then(()=>{if(msg)msg.textContent="Copied."},fallback)}catch(e){fallback()}}

/* ----- phone check ----- */
function phoneCheckHTML(){return `<section class="filters" id="phonecheck"><span class="kicker">Phone check</span>
 <p class="hint">Run this on your phone after installing the app, and again with flight mode on. If anything says "No", copy the report and send it to Claude.</p>
 <ul id="diag" style="margin:0;padding:0;list-style:none;display:grid;gap:6px;font-size:14px"><li class="hint">Checking…</li></ul>
 <details class="legend"><summary>Things to try by hand</summary><p class="hint" style="line-height:1.7">1. Pinch-zoom the home map and tap a pin.<br>2. Tap ◎ on the map and allow location.<br>3. Open a walk, tap "On site", and pick a fork option.<br>4. Turn on flight mode, reopen the app, and open a stop and the food guide.<br>5. Still offline, check that the map shows the areas you viewed earlier.</p></details>
 <div><button class="btn small" data-copy="diagText">Copy report</button> <span class="hint" id="copyMsg2"></span></div><textarea id="diagText" readonly rows="2" style="position:absolute;left:-9999px"></textarea></section>`}
async function runPhoneCheck(){const el=document.getElementById("diag");if(!el)return;const rows=[];const add=(ok,t)=>rows.push([ok,t]);
 add(true,window.__ARTIFACT__?"Version: inside Claude":"Version: phone app / website");
 add(navigator.onLine,`Online: ${navigator.onLine?"yes":"no"}`);
 const inst=(window.matchMedia&&matchMedia("(display-mode: standalone)").matches)||navigator.standalone===true;
 if(!window.__ARTIFACT__)add(inst?true:"warn",`Installed on home screen: ${inst?"yes":"no (open from the home-screen icon)"}`);
 let ls=false;try{localStorage.setItem("__t","1");localStorage.removeItem("__t");ls=true}catch(e){}add(ls,`Saving progress on this device: ${ls?"yes":"no"}`);
 if(!window.__ARTIFACT__){
  add(!!window.L,`Street map library loaded: ${window.L?"yes":"no (the drawn map is used)"}`);
  add((window.__tiles||0)>0?true:"warn",`Street map tiles loaded this session: ${window.__tiles||0}${window.__tileErr?`, ${window.__tileErr} failed`:""}`);
  const sw=!!(navigator.serviceWorker&&navigator.serviceWorker.controller);add(sw?true:"warn",`Offline support active: ${sw?"yes":"not yet (reload once)"}`);
  try{const keys=await caches.keys();const app=keys.find(k=>k.startsWith("cdmx-companion"));const tiles=keys.find(k=>k.startsWith("cdmx-tiles"));
   add(!!app,`Guide saved for offline: ${app?"yes":"no"}`);
   if(tiles){const n=(await (await caches.open(tiles)).keys()).length;add(n>0?true:"warn",`Map pieces saved for offline: ${n}`)}else add("warn","Map pieces saved for offline: 0 (browse the map on Wi-Fi)")}catch(e){add("warn","Offline storage: can't check")}
  if(navigator.permissions&&navigator.permissions.query){try{const p=await navigator.permissions.query({name:"geolocation"});add(p.state==="denied"?false:true,`Location permission: ${p.state}`)}catch(e){add("warn","Location permission: can't check")}}}
 el.innerHTML=rows.map(([ok,t])=>`<li><span class="pill ${ok===true?"ok":ok==="warn"?"warn":"no"}">${ok===true?"Yes":ok==="warn"?"Check":"No"}</span> ${esc(t)}</li>`).join("");
 const ta=document.getElementById("diagText");if(ta)ta.value="Phone check "+new Date().toISOString()+"\n"+rows.map(([ok,t])=>`${ok===true?"OK":ok==="warn"?"CHECK":"NO"} ${t}`).join("\n")+"\n"+navigator.userAgent}

/* ----- update banner ----- */
function showUpdateBar(){if(document.getElementById("updbar"))return;const d=document.createElement("div");d.id="updbar";d.className="updbar";d.innerHTML=`<span>This guide was updated.</span><button class="btn small primary" data-reload>Refresh</button>`;document.body.appendChild(d)}

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.day){nav({v:"day",id:d.day});return}
 if(d.eatarea){useArea(d.eatarea);areaTab="eat";nav({v:"area",a:d.eatarea});return}
 if(b.hasAttribute("data-export")){showExport();return}
 if(b.hasAttribute("data-import")){showImport();return}
 if(d.copy){copyText(d.copy);return}
 if(b.hasAttribute("data-impcheck")){const t=document.getElementById("impCode"),m=document.getElementById("impMsg"),v=t&&decodeState(t.value);
  if(!v||typeof v!=="object"){m.textContent="That code isn't valid. Copy the whole code and try again.";return}
  window.__pendingImport=v;m.innerHTML=`This replaces the progress on this device (${(v.visited||[]).length} places visited in the backup). <button class="btn small primary" data-impyes>Yes, restore</button> <button class="btn small" data-impno>Cancel</button>`;return}
 if(b.hasAttribute("data-impyes")){S=merge(window.__pendingImport);window.__pendingImport=null;save();render();return}
 if(b.hasAttribute("data-impno")){const box=document.getElementById("progressBox");if(box)box.innerHTML="";return}
 if(b.hasAttribute("data-reload")){location.reload();return}});

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.plan){S.plan=S.plan||{};if(S.plan[d.plan]===d.planday)delete S.plan[d.plan];else S.plan[d.plan]=d.planday;save();render();return}
 if(d.unplan){if(S.plan)delete S.plan[d.unplan];save();render();return}});
