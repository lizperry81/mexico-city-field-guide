/* Time-aware helpers: museum routes by available time, a free-time planner, walks that start
   where you are, the "Take a break" sheet, and your hotel for getting back. */
let TOURT={},FREET=0;
const VISIT_BY_TYPE={"Museums":60,"Murals and art":40,"Archaeology":30,"Architecture":15,"Parks and gardens":30,"Views":45};
function visitMins(p){const st=getStop(p.id);if(st&&st.mins)return st.mins;const s=siteById(p.id)||{};return Math.max(...(s.types||["Architecture"]).map(t=>VISIT_BY_TYPE[t]||20))}

/* ----- museum tours: route by time ----- */
function tourUnits(blocks){const units=[];let curU=null;
 blocks.forEach((b,i)=>{if(b.where||b.obj){curU={key:b.where||b.obj.name,side:b.side,blocks:[b],i};units.push(curU)}
  else if(b.fork||b.take||b.prac){curU=null;units.push({fixed:true,blocks:[b]})}
  else if(curU)curU.blocks.push(b);else units.push({fixed:true,blocks:[b]})});return units}
function tourBody(t,fn){const blocks=orderSite(t.blocks),units=tourUnits(blocks),plan=t.plan||{},T=TOURT[t.id]||0,pick=S.forks[(t.blocks.find(b=>b.fork)||{fork:{}}).fork.id];
 const opts=[[30,"30 min"],[60,"1 hour"],[120,"2 hours"],[0,"Everything"]];
 const picker=`<section class="filters"><span class="kicker">How much time do you have?</span><div class="chips">${opts.map(([m,l])=>`<button class="chip" aria-pressed="${T===m}" data-tourt="${t.id}:${m}">${l}</button>`).join("")}</div>${T?"":`<p class="hint">Pick a time and the tour keeps only what fits, must-sees first.</p>`}</section>`;
 if(!T)return picker+blocks.map(b=>blockHTML(b,fn)).join("");
 const cand=units.filter(u=>!u.fixed&&plan[u.key]).map(u=>({u,pri:plan[u.key][0]-(pick&&u.side===pick?.5:0),m:plan[u.key][1]})).sort((a,b)=>a.pri-b.pri||a.u.i-b.u.i);
 let used=0;const chosen=new Set();cand.forEach(c=>{if(used+c.m<=T){chosen.add(c.u);used+=c.m}});
 const inRoute=units.filter(u=>u.fixed?!u.blocks[0].take:chosen.has(u)),rest=units.filter(u=>!u.fixed&&!chosen.has(u));
 return picker+`<p class="hint">Your ${T>=60?T/60+"-hour":T+"-minute"} route: ${chosen.size} stops, about ${used} minutes (the guide's estimates, not official).</p>`
  +inRoute.map(u=>u.blocks.map(b=>blockHTML(b,fn)).join("")).join("")
  +(rest.length?`<details class="deeper"><summary>If you have more time (${rest.length})</summary><div class="article">${rest.map(u=>u.blocks.map(b=>blockHTML(b,fn)).join("")).join("")}</div></details>`:"")}

/* ----- free time: a mini route from where you are ----- */
function freePlan(c,mins){if(!c.here)return null;let pos=c.here.ll,left=mins;const route=[];
 const pool=placesNow(c).filter(p=>(p.st.s==="open"||p.outdoor)&&!p.visited);
 while(route.length<5){let best=null;
  pool.forEach(p=>{if(route.some(r=>r.p===p))return;const d=hav(pos,p.ll),wk=walkMin(d),v=Math.min(visitMins(p),45);
   if(p.st.s==="open"&&!p.outdoor&&p.hours){const r=((c.n.dow===0&&p.hours.sun)||(c.n.dow===6&&p.hours.sat)||p.hours.h).find(([a,b])=>c.n.h>=a&&c.n.h<b);if(r&&(r[1]-c.n.h)*60<(mins-left)+wk+v)return}
   if(wk+v<=left&&(!best||d<best.d))best={p,d,wk,v}});
  if(!best)break;route.push(best);left-=best.wk+best.v;pos=best.p.ll}
 return route}
function freeHTML(c){const opts=[30,60,90,120];
 let out=`<div class="freet"><span class="hint">Short on time? I have:</span><div class="chips">${opts.map(m=>`<button class="chip" aria-pressed="${FREET===m}" data-freet="${m}">${m<60?m+" min":(m/60)+" h"}</button>`).join("")}</div></div>`;
 if(!FREET)return out;
 const r=freePlan(c,FREET);
 if(!r)return out+`<p class="hint">Set where you are first (tap 📍 above), and the guide will build a route that fits.</p>`;
 if(!r.length)return out+`<p class="hint">Nothing open in the guide fits ${FREET} minutes from here. Try more time, or Eat or Relax.</p>`;
 const tot=r.reduce((s,x)=>s+x.wk+x.v,0);
 return out+`<p class="hint">About ${tot} minutes, ${r.length} stop${r.length>1?"s":""} (walking at an easy pace):</p>`+r.map((x,i)=>row(x.p.open,`${i+1}. ${esc(x.p.name)}`,`${statusPill(x.p.st)}<span class="hint">${x.wk} min walk · ~${x.v} min there</span>`)).join("")
  +`<div><a class="btn small primary" href="${dirURL({ll:r[0].p.ll,name:r[0].p.name})}" target="_blank" rel="noopener">Directions to ${esc(r[0].p.name)} ↗</a></div>`}

/* ----- take a break ----- */
function breakSheet(wid,i){let el=document.getElementById("breaksheet");if(!el){el=document.createElement("div");el.id="breaksheet";el.className="termsheet";document.body.appendChild(el)}
 const c=ctxNow(),w=wid?walkById(wid):null,stops=w?walkStops(w):[],fn=new Footnotes();
 const fa=foodAll(c).filter(x=>x.st.s==="open"&&(!c.areaId||x.area===c.areaId)).sort((a,b)=>(b.f.types.includes("Cafés and sweets")?1:0)-(a.f.types.includes("Cafés and sweets")?1:0)).slice(0,3);
 const parks=c.here?placesNow(c).filter(p=>p.types.includes("Parks and gardens")&&p.d<2500).sort((a,b)=>a.d-b.d):[];
 const must=w?stops.map((s,j)=>[s,j]).filter(([s,j])=>j>i+1&&(getStop(s).pri||3)===1):[];
 const hotel=S.hotel||"";
 el.innerHTML=`<div class="termcard" role="dialog" aria-label="Take a break" style="max-height:85vh;overflow:auto"><div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:20px;font-weight:800">Take a break</b><button class="back" data-breakclose aria-label="Close">×</button></div>
 <span class="kicker">Sit down nearby</span><div class="nowlist">${fa.map(x=>row(`data-eatarea="${x.area}"`,esc(x.f.name),`${statusPill(x.st)}<span class="hint">${esc(x.f.types[0])}</span>`)).join("")}${parks.map(p=>row(p.open,esc(p.name),`<span class="pill ok">Open-air</span><span class="hint">${distText(p.d)}</span>`)).join("")}${!fa.length&&!parks.length?`<p class="hint">Nothing with confirmed hours is open nearby right now.</p>`:""}</div>
 ${w?`<span class="kicker">Shorten this walk</span>${must.length?`<div class="nowlist">${must.map(([s,j])=>row(`data-walk="${w.id}" data-step="${j}"`,`Skip ahead to ${esc(getStop(s).name)}`,`<span class="pill ok">Must-see</span><span class="hint">stop ${j+1}</span>`)).join("")}</div>`:`<p class="hint">No must-see stops are left on this walk; you can stop here.</p>`}<div><button class="btn small" data-walk="${w.id}" data-step="${stops.length-1}">Jump to the end and the recap</button></div>`:""}
 <span class="kicker">Get back to your hotel</span>
 ${hotel?`<p class="hint">${esc(hotel)} <button class="linkbtn" data-hotelchange>Change</button></p><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn small primary" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(hotel)}&travelmode=transit">Directions ↗</a><a class="btn small" target="_blank" rel="noopener" href="https://m.uber.com/ul/?action=setPickup&pickup=my_location&dropoff%5Bformatted_address%5D=${encodeURIComponent(hotel)}">Uber ↗</a></div>`
  :`<form id="hotelForm" class="search"><label for="hotelin" style="position:absolute;left:-9999px">Hotel address</label><input id="hotelin" placeholder="Your hotel's name or address" autocomplete="off"><button type="submit">Save</button></form>`}
 <p class="hint">Street taxis: official ones are white and pink, and the city's app has a "Mi Taxi" module to check the plate.${fn.mark(["cdmxairport"])}</p>${fn.html()}</div>`;el.hidden=false}
function closeBreak(){const el=document.getElementById("breaksheet");if(el)el.hidden=true}

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b){if(e.target.id==="breaksheet")closeBreak();return}const d=b.dataset;
 if(d.tourt){const [id,m]=d.tourt.split(":");TOURT[id]=+m;render();return}
 if(d.freet){FREET=FREET===+d.freet?0:+d.freet;refreshNow();return}
 if(d.walkfrom){const [wid,j]=d.walkfrom.split(":");S.wstart=S.wstart||{};S.wstart[wid]=+j;save();S.walkOn&&S.walkOn.w===wid?nav({v:"walk",w:wid,i:0}):nav({v:"walkstart",w:wid});return}
 if(b.hasAttribute("data-breakopen")){breakSheet(d.breakopen||null,+(d.breaki||0));return}
 if(b.hasAttribute("data-breakclose")){closeBreak();return}
 if(b.hasAttribute("data-hotelchange")){S.hotel="";save();const s=document.getElementById("breaksheet");if(s&&!s.hidden){const x=s.querySelector('[data-breakclose]');breakSheet(window.__bw,window.__bi)}else render();return}
 if(d.walk!==undefined||d.eatarea||d.more||d.stop)closeBreak()},true);
document.addEventListener("submit",e=>{if(e.target.id!=="hotelForm"&&e.target.id!=="hotelForm2")return;e.preventDefault();const v=(e.target.querySelector("input").value||"").trim();if(!v)return;S.hotel=v;save();if(e.target.id==="hotelForm")breakSheet(window.__bw,window.__bi);else render()});
