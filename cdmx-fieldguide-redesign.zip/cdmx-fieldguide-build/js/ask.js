/* "Ask the guide". Finds the passages in the guide that best match a question, then:
   - inside Claude, asks Claude to answer ONLY from those passages, citing them;
   - in the standalone app (no Claude connection), shows the matching passages themselves.
   Facts in answers therefore always trace back to the guide's sourced content. */
let PASSAGES=null,ASKS=[],ASKQ="",ASKCTX=null,ASKCTL=null,ASKPROMPTS=null,PENDINGIMG=null;
const STOP=new Set("a an the of and or to in on at for is are was were be it its this that what which who whom why how when where do does did can could should would i me my we you your near nearby there here with from about as by into than then so if not no any some much many more most tell me please guide el la los las de del y en que por para un una es".split(" "));
const SYN={cathedral:["catedral"],palace:["palacio"],castle:["castillo"],temple:["templo"],museum:["museo"],square:["zocalo","plaza"],lean:["tilt","sink","settling"],leaning:["tilt","sink","settling"],sinking:["sink","settling","lean"],sun:["sol"],stone:["piedra"],mural:["murals","rivera"],aztec:["mexica"],aztecs:["mexica"],eat:["food"],kings:["reyes"],christmas:["nochebuena","navidad","posadas"],safe:["safety","safe"],subway:["metro"],airport:["aicm"],tip:["tipping"],water:["tap"],tacos:["taco"]};
const baseTok=q=>norm(q).replace(/[^a-z0-9ñ ]+/g," ").split(/\s+/).filter(w=>w.length>1&&!STOP.has(w)).map(w=>w.length>4&&w.endsWith("s")?w.slice(0,-1):w);
const tokens=q=>baseTok(q);
const qTokens=q=>{const t=baseTok(q),out=new Set(t);norm(q).split(/[^a-z0-9ñ]+/).forEach(w=>(SYN[w]||[]).forEach(x=>out.add(x.length>4&&x.endsWith("s")?x.slice(0,-1):x)));t.forEach(w=>(SYN[w]||[]).forEach(x=>out.add(x)));return [...out]};
function buildPassages(){const P=[];const add=(title,kind,area,text,src,tag,go)=>P.push({title,kind,area,text,src:src||[],tag:tag||"est",go});
 for(const aid in AD){const a=AD[aid];
  a.overview.forEach(o=>add(a.name,"Area overview",a.name,o[0],o[1],o[2],{v:"area",a:aid}));
  a.walks.forEach(w=>(w.logistics||[]).forEach(l=>add(w.name,"Walk logistics",a.name,`${l[0]}: ${l[1]}`,l[2],l[3],{v:"walk",w:w.id,i:0})));
  (a.tours||[]).forEach(t=>(t.blocks||[]).concat(t.background||[]).forEach(b=>{if(b.p)add(t.name,"Museum tour",a.name,b.p[0],b.p[1],b.p[2],{v:"tour",id:t.id});if(b.obj){add(b.obj.name,"Museum object",a.name,b.obj.p[0],b.obj.p[1],b.obj.p[2],{v:"tour",id:t.id});(b.obj.look||[]).forEach(l=>add(b.obj.name+": look for","Museum object",a.name,l[0],l[1],l[2],{v:"tour",id:t.id}))}}));
  const flat=l=>(l||[]).flatMap(b=>b.steps?b.steps.items.filter(it=>it[1]&&it[1].length).map(it=>({p:it})):b.deep?flat(b.deep.blocks):b.pt?flat(b.pt.blocks).concat((b.pt.more||[]).flatMap(m=>flat(m.blocks))):[b]);
  for(const k in a.stops){const st=getStop(k);flat(st.read).concat(flat(st.lead),flat(st.more)).forEach(b=>{if(b.p)add(st.name,"Walk stop",a.name,b.p[0],b.p[1],b.p[2],{v:"stop",id:k});if(b.prac)add(st.name,"Walk stop",a.name,b.prac[0],b.prac[1],b.prac[2],{v:"stop",id:k});if(b.detour)add(b.detour.h,"Detour",a.name,b.detour.p[0],b.detour.p[1],b.detour.p[2],{v:"stop",id:k})})}
  a.sites.forEach(s=>{if(s.link)return;(s.read||[]).forEach(b=>{if(b.p)add(s.name,"Site",a.name,b.p[0],b.p[1],b.p[2],{v:"more",id:s.id})});add(s.name,"Site",a.name,`Hours: ${siteHours(s)}. Cost: ${s.cost}. Address: ${s.addr}.`,s.hsrc?[s.hsrc]:[],s.hours?"est":"unk",{v:"more",id:s.id})});
  a.food.forEach(f=>add(f.name,"Food pick",a.name,`${f.types.join(", ")}, price ${PRICES[f.price-1]}. Order: ${f.order} Hours: ${hoursText(f)}${f.note?". "+f.note:""}. Address: ${f.addr}. ${f.why}`,f.crit,"est",{eat:aid,name:f.name}))}
 if(BASICS)BASICS.sections.forEach(s=>s.items.forEach(i=>add(`${s.h}: ${i[0]}`,"City basics","Mexico City",i[1],i[2],i[3],{v:"basics"})));
 if(SEASON)SEASON.events.forEach(e=>{e.p.forEach(p=>add(`${e.name} (${e.when})`,"Holiday season","Mexico City",p[0],p[1],p[2],{v:"season"}));if(e.eat)add(`${e.name}: what to eat`,"Holiday season","Mexico City",e.eat[0],e.eat[1],"est",{v:"season"})});
 (typeof CTX!=="undefined"?CTX:[]).forEach(c=>c.blocks.concat(c.more||[]).forEach(b=>{if(b.p)add(c.title,"Big picture",c.era,b.p[0],b.p[1],b.p[2],{v:"ctx",id:c.id})}));
 NIGHT.forEach(x=>{x.p.forEach(p=>add(x.name,"Evening",x.where,p[0],p[1],p[2],{v:"night",id:x.id}));add(x.name,"Evening",x.where,`${x.summary} ${x.sched?"Schedule: "+schedText(x)+".":""}${x.hours?" Hours: "+hoursTextN(x)+".":""} Cost: ${x.cost}. Address: ${x.addr}.${x.book?" Tickets: "+x.book:""}`,x.ssrc?[x.ssrc]:x.hsrc?[x.hsrc]:[],x.sched||x.hours?"est":"unk",{v:"night",id:x.id})});
 (GLOSSARY||[]).forEach(g=>add(`${g.term} (glossary)`,"Glossary","Mexico City",g.def[0],g.def[1],g.def[2],{v:"glossary"}));
 THREADS.forEach(t=>t.steps.forEach(s=>s.p.forEach(p=>add(t.name,"Thread","Mexico City",p[0],p[1],p[2],{v:"thread",id:t.id}))));
 (typeof STORIES!=="undefined"?STORIES:[]).forEach(s=>(s.chapters||[]).forEach(ch=>(ch.p||[]).forEach(p=>add(s.title,"Story","Mexico City",p[0],p[1],p[2],{v:"story",id:s.id}))));
 if(typeof community==="function")community().filter(c=>c.status==="approved").forEach(c=>add(`${placeName(c.place)}: community report`,"Community report (one traveler, visit "+(c.visit||"undated")+", self-reported)",placeName(c.place),Object.entries(c.f||{}).map(([k,v])=>v).join(" ")+(c.rating?` Their rating: ${c.rating}/5.`:""),[],"comm",null));
 const df={};P.forEach(p=>{p.toks=new Set(tokens(p.title+" "+p.text));p.ttoks=new Set(tokens(p.title));p.toks.forEach(t=>df[t]=(df[t]||0)+1)});
 P.forEach(p=>p.idf=t=>Math.log(1+P.length/(df[t]||1)));PASSAGES=P;return P}
const FOODWORDS=new Set(["eat","food","hungry","taco","lunch","dinner","breakfast","restaurant","drink","bar","coffee","cafe","mezcal","churro","torta","seafood","cheap","comer","comida"]);
function retrieve(q,ctx){const P=PASSAGES||buildPassages(),qt=qTokens(q),foodish=qt.some(t=>FOODWORDS.has(t));
 const scored=P.map(p=>{let s=0;qt.forEach(t=>{const w=p.idf(t);if(p.ttoks.has(t))s+=3*w;else if(p.toks.has(t))s+=w;else{for(const x of p.toks){if(x.length>4&&t.length>4&&(x.startsWith(t.slice(0,5))||t.startsWith(x.slice(0,5)))){s+=.5*w;break}}}});
  if(ctx&&p.go&&(p.go.id===ctx||p.title===ctx))s=s*1.5+2;if(foodish&&p.kind==="Food pick")s+=1.5;return [s,p]}).filter(x=>x[0]>0).sort((a,b)=>b[0]-a[0]);
 return scored.slice(0,(typeof askLen==='function'?askLen().k:12)).map(x=>x[1])}
function goAttr(go){if(!go)return "";if(go.eat)return `data-eatarea="${go.eat}"`;if(go.v==="stop")return `data-stop="${go.id}"`;if(go.v==="more")return `data-more="${go.id}"`;if(go.v==="walk")return `data-walk="${go.w}"`;if(go.v==="area")return `data-area="${go.a}"`;if(go.v==="thread")return `data-thread="${go.id}"`;if(go.v==="tour")return `data-tour="${go.id}"`;if(go.v==="night")return `data-night="${go.id}"`;if(go.v==="ctx")return `data-ctxpage="${go.id}"`;if(go.v==="season")return `data-go="season:"`;if(go.v==="basics")return `data-go="basics:"`;return ""}
function contextLine(){const n=mxNow(),ti=tripDayIndex(),here=hereFresh()?S.here:null;
 return `It is ${n.label} in Mexico City. ${ti>=0&&ti<tripLen()?`The traveler is on day ${ti+1} of a ${tripLen()}-day trip.`:ti<0?`The trip starts in ${-ti} days (first day ${S.start}).`:""} ${here?`The traveler says they are near ${here.label}.`:"The traveler's location is unknown."} Places already visited: ${S.visited.map(id=>(getStop(id)||siteById(id)||{}).name).filter(Boolean).join(", ")||"none"}.`}
function nearbyNames(km){if(!hereFresh())return [];return nowPlaces().map(p=>({p,d:hav(S.here.ll,p.ll)})).filter(x=>x.d<km*1000).sort((a,b)=>a.d-b.d).slice(0,12).map(x=>`${x.p.name} (${Math.round(x.d)} m)`)}
/* Inquiry modes change the approach, not just the opening line. Lengths change depth and how
   much of the guide is retrieved as grounding. */
const ASKMODES=[
 {id:"story",name:"The Storyteller",cue:"Tell me the story",how:"Tell it as a story: who, where, what happened, in order, with the concrete details that make a place come alive. Begin in the scene, not with a definition. Keep it accurate: every fact still needs a note."},
 {id:"people",name:"The People's Historian",cue:"Whose perspective is missing?",how:"Ask who had power, who benefited, who paid and whose voices are missing: Indigenous communities (as contemporary as well as historical peoples), workers, women, the poor. Use the notes for evidence. Don't romanticize anyone, don't treat Mexico as one culture, and don't turn interpretation into fact: say when a reading is an argument some historians make."},
 {id:"art",name:"The Art and Architecture Expert",cue:"Teach me how to look",how:"Teach the traveler to look: materials, composition, symbols, inscriptions, styles and techniques, and where to stand. Walk the eye through the object step by step, then say what the details meant to the people who made it."},
 {id:"skeptic",name:"The Skeptical Historian",cue:"What do we actually know?",how:"Separate evidence from interpretation. For each claim say what kind of source supports it (archaeology, a colonial chronicle, a later legend, a museum label) and how sure we can be. Lay out the main competing interpretations fairly. Use the notes' Debated and Unknown tags explicitly."},
 {id:"local",name:"The Practical Local Guide",cue:"Where should I go next?",how:"Be practical and specific: what to do next, in what order, how to get there, what it costs and when it's open, using only the notes for hours, prices and places. Then add one line on why the place matters, so the practical advice still teaches something."}];
const ASKLENS=[
 {id:"quick",name:"Quick answer",sub:"About 20 seconds",k:8,how:"Length: about 50 to 70 words, one short paragraph."},
 {id:"walk",name:"Walking explanation",sub:"About 2 minutes",k:12,how:"Length: about 250 to 320 words, three or four short paragraphs, easy to read while standing."},
 {id:"deep",name:"Deep dive",sub:"5 to 10 minutes",k:20,how:"Length: about 800 to 1,300 words in short paragraphs. You may use a few short subheadings, each on its own line starting with '## '."},
 {id:"research",name:"Research mode",sub:"Sources and debates",k:28,how:"Length: as long as the material supports, up to about 1,500 words, organized with short subheadings on their own lines starting with '## '. Cite a note for every factual sentence. End with a section '## What's debated or unknown' and a section '## Sources to read' listing the source names behind the notes you used."}];
const askMode=()=>ASKMODES.find(m=>m.id===S.askMode)||ASKMODES[0];
const askLen=()=>ASKLENS.find(m=>m.id===S.askLen)||ASKLENS[1];
function systemFor(notes,withImage){const M=askMode(),Ln=askLen();
 return `You are the guide inside the Mexico City Field Guide, an app that helps travelers understand the city they are standing in. You combine a historian, a cultural interpreter, an art and architecture educator and a knowledgeable local friend. You are talking with a traveler on their phone.

MODE: ${M.name}. ${M.how}
${Ln.how}

Grounding rules:
- Use the numbered NOTES below, the guide's own sourced content. Put the note number in square brackets right after each fact it supports, like [2].
- Never invent quotations, sources, dates, events, opening hours, prices or visitor information.
- Notes tagged Debated mean sources disagree: say so and give the sides. Notes tagged Unknown mean the guide doesn't know: say that plainly.
- Distinguish established facts, debated interpretations and unknowns. Present political interpretations as interpretations, with more than one perspective where historians disagree.
- If the notes don't cover something important, you may add ONE paragraph that begins exactly with "Beyond the guide:" from general knowledge. Keep it cautious, flag uncertainty, and never give hours, prices, safety advice or place recommendations in it.
- Plain prose, no bullet lists unless the traveler asks for steps. Paragraphs separated by a blank line.
- Keep kinds of information apart and say which is which. Notes are labeled by kind: historical claims (with an evidence class), Food pick and editorial notes (the guide's own judgment), Community report (one traveler's self-reported experience: attribute it, never generalize one report into a consensus, never treat its allegations as fact), and practical details (hours, prices: say how old the source is if the note shows a date).
- For "is this place worth it" questions, answer in this order with short labels: the cultural or historical context; what community reports say, if any (attributed); current practical information and its age; and why the guide does or doesn't recommend it.
- Never say a place is "locally loved", "historically important" or "highly regarded" unless a note says so.
- If the notes don't support an answer, say plainly that the guide doesn't have enough evidence, say what is missing, and if possible name the kind of source that would settle it (an INAH page, the venue's official site). Don't fill the gap with a confident guess.
- Only if it genuinely helps, end with a line "FOLLOW-UPS:" and up to three specific follow-up questions separated by " | ". Leave it out when the answer is complete.
Use the SITUATION line for time and place; don't invent distances.${withImage?`

The traveler attached a photo they just took and wants to know what they're looking at. Say what it most likely shows, using the notes, the NEARBY list and anything clearly visible (signs, inscriptions, distinctive features). If you aren't confident, say so and name the two most likely candidates. Then explain the important details to notice and connect it to the guide's stories.`:""}

SITUATION: ${contextLine()}${withImage?`\nNEARBY: ${nearbyNames(1.5).join("; ")||"unknown (location not set)"}`:""}

NOTES:
${notes.map((p,i)=>`[${i+1}] ${p.title} (${p.kind}, ${p.area}) [${p.tag==="comm"?"Community report, unverified":TAGS[(p.tag==="est"&&p.src.length&&typeof evidenceStrong==="function"&&!evidenceStrong(p.src))?"rep":(p.tag||"est")]?TAGS[(p.tag==="est"&&p.src.length&&typeof evidenceStrong==="function"&&!evidenceStrong(p.src))?"rep":(p.tag||"est")][0]:"Well established"}]: ${p.text}${p.src&&p.src.length?` (sources: ${p.src.map(x=>(SRC[x]||{}).n).filter(Boolean).join("; ")})`:""}`).join("\n")}`}
function splitAnswer(t){t=t||"";let follow=[];const fi=t.search(/FOLLOW-?UPS:/i);if(fi>=0){follow=t.slice(fi).replace(/FOLLOW-?UPS:/i,"").split("|").map(x=>x.trim().replace(/^[-*\d.\s]+/,"")).filter(x=>x.length>3).slice(0,3);t=t.slice(0,fi)}
 let beyond="";const bi=t.search(/Beyond the guide:/i);if(bi>=0){beyond=t.slice(bi).replace(/Beyond the guide:\s*/i,"").trim();t=t.slice(0,bi)}
 return {main:t.trim(),beyond,follow}}
function citeHTML(text,notes){return esc(text).replace(/\[(\d+(?:\s*,\s*\d+)*)\]/g,(m,g)=>g.split(",").map(x=>{const i=+x.trim()-1,p=notes[i];return p?`<button class="citebtn" ${goAttr(p.go)} title="${esc(p.title)}">${i+1}</button>`:""}).join(""))}
function notesHTML(notes,used){const list=used?notes.map((p,i)=>[p,i]).filter(([,i])=>used.has(i)):notes.slice(0,5).map((p,i)=>[p,i]);
 return `<div class="asknotes">${list.map(([p,i])=>`<div class="asknote"><span class="citebtn static">${i+1}</span><div style="min-width:0;display:grid;gap:3px"><b>${esc(p.title)}</b><span class="hint">${esc(p.kind)} · ${esc(p.area)}</span><span style="font-size:14.5px">${esc(p.text.length>260?p.text.slice(0,257)+"…":p.text)} ${tagHTML(p.tag)}</span><span>${srcTag(p.src)} ${goAttr(p.go)?`<button class="btn small" ${goAttr(p.go)}>Open</button>`:""}</span></div></div>`).join("")}</div>`}
function turnHTML(a){const sp=splitAnswer(a.text);
 return `<article class="askentry">
 <div class="askq">${a.mode?`<span class="eyebrow">${esc(a.mode)} · ${esc(a.len)}</span>`:""}${a.img?`<img src="${a.img}" alt="Your photo" class="askimg">`:""}<span>${esc(a.q)}</span>${a.ctxName?` <span class="hint">· about ${esc(a.ctxName)}</span>`:""}</div>
 ${a.state==="thinking"&&!a.text?`<p class="hint">Thinking… <button class="btn small" data-askstop>Stop</button></p>`:""}
 ${sp.main?`<div class="askanswer">${sp.main.split(/\n\s*\n|\n(?=## )/).map(x=>x.trim()).filter(Boolean).map(x=>x.startsWith("## ")?`<h3>${esc(x.slice(3))}</h3>`:`<p>${citeHTML(x,a.notes).replace(/\n/g,"<br>")}</p>`).join("")}</div>`:""}
 ${sp.beyond?`<div class="beyond"><span class="lbl">Beyond the guide · general knowledge, not from its sources</span><p>${esc(sp.beyond)}</p></div>`:""}
 ${a.err?`<p class="hint">${esc(a.err)}${a.errSettings?` <button class="linkbtn" data-aiopen>Open AI settings</button>`:""}</p>`:""}
 ${a.state==="done"&&sp.follow.length?`<div class="chips">${sp.follow.map(f=>`<button class="chip followup" data-asksug="${esc(f)}">${esc(f)}</button>`).join("")}</div>`:""}
 ${a.notes&&a.notes.length&&a.state==="done"?`<details class="legend howknow" ${a.text?"":"open"}><summary>${a.text?"How do we know?":"Best matches in the guide"}</summary>${a.text?howKnowAnswer(a):""}${notesHTML(a.notes,a.text?a.used:null)}</details>`:""}
 ${a.notes&&!a.notes.length&&!a.text&&a.state==="done"?`<p class="empty">Nothing in the guide matches that yet. Try other words, or ask about a place, a person or a food.</p>`:""}</article>`}
function vAsk(){const ctxName=ASKCTX?(getStop(ASKCTX)||siteById(ASKCTX)||nightById(ASKCTX)||{}).name:null;const M=askMode(),Ln=askLen();
 const sugg=ASKPROMPTS||(ctxName?[`Tell me the story of ${ctxName}`,`What should I notice at ${ctxName}?`,`Whose story is missing at ${ctxName}?`]:["What did the Spanish actually conquer in 1519?","Why does the cathedral lean?","Who gets to tell the story of Mexico?","What is the Sun Stone, and what do we really know about it?"]);
 return `<section class="storyhead"><span class="eyebrow">Ask the guide</span><h1>${esc(M.name)}</h1><p class="lede">${esc(M.cue)}. Answers draw on the guide's sourced passages, with numbered links back to them; anything else is marked "Beyond the guide".</p></section>
 <div class="modegrid" role="radiogroup" aria-label="How should the guide answer">${ASKMODES.map(m=>`<button role="radio" aria-checked="${m.id===M.id}" data-askmode="${m.id}"><b>${esc(m.name.replace(/^The /,""))}</b><span>${esc(m.cue)}</span></button>`).join("")}</div>
 <div class="lengrid" role="radiogroup" aria-label="How long">${ASKLENS.map(l=>`<button role="radio" aria-checked="${l.id===Ln.id}" data-asklen="${l.id}"><b>${esc(l.name)}</b><span>${esc(l.sub)}</span></button>`).join("")}</div>
 ${ctxName?`<p class="hint">Asking about <strong>${esc(ctxName)}</strong>. <button class="linkbtn" data-askctxclear>Ask about anything</button></p>`:""}
 <div id="askout" style="display:grid;gap:14px">${ASKS.length?"":`<p class="hint">Follow-up questions keep the conversation's thread; "New conversation" starts fresh.</p>`}${ASKS.map(turnHTML).join("")}</div>
 ${ASKS.length&&!ASKPROMPTS?"":`<div class="chips">${sugg.map(s=>`<button class="chip" data-asksug="${esc(s)}">${esc(s)}</button>`).join("")}</div>`}
 <form class="composer" id="askForm2">${PENDINGIMG?`<span class="pendimg"><img src="${PENDINGIMG.url}" alt="Photo to ask about"><button type="button" class="pendx" data-imgclear aria-label="Remove photo">×</button></span>`:""}
  <label class="cambtn" for="askphoto" title="What am I looking at?" aria-label="Ask about a photo"><svg viewBox="0 0 24 24"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg></label><input type="file" id="askphoto" accept="image/*" capture="environment" hidden>
  <label for="askq2" style="position:absolute;left:-9999px">Your question</label><input id="askq2" placeholder="${PENDINGIMG?"What am I looking at?":"Ask anything about the city"}" autocomplete="off"><button type="submit">Ask</button></form>
 ${ASKS.length?`<div><button class="btn small" data-asknew>New conversation</button></div>`:""}
 <details class="legend" id="aidetails"><summary>AI settings</summary>${aiSettingsHTML()}</details>`}
function refreshAsk(){const o=document.getElementById("askout");if(o){o.innerHTML=ASKS.map(turnHTML).join("");const last=o.lastElementChild;if(last&&ASKS.length&&ASKS[ASKS.length-1].state!=="done")last.scrollIntoView({block:"nearest"})}}
async function ask(q,img){q=(q||"").trim();if(!q&&img)q="What am I looking at?";if(!q)return;
 const ctxName=ASKCTX?(getStop(ASKCTX)||siteById(ASKCTX)||nightById(ASKCTX)||{}).name:null;
 const prevQ=ASKS.length?ASKS[ASKS.length-1].q:"";
 let notes=retrieve(q+(ctxName?" "+ctxName:"")+" "+prevQ,ASKCTX);
 if(img){const near=nearbyNames(1.5).map(n=>n.replace(/ \(\d+ m\)$/,""));if(near.length){const extra=retrieve(near.slice(0,4).join(" "),null).filter(p=>!notes.includes(p)).slice(0,6);notes=notes.slice(0,8).concat(extra)}}
 const a={q,ctxName,notes,state:"thinking",text:"",used:new Set(),img:img?img.url:null,mode:askMode().name,len:askLen().name};ASKS.push(a);
 if(cur().v==="ask")render();else nav({v:"ask"});
 const mode=await aiMode();
 if(mode==="none"){a.state="done";if(!window.__ARTIFACT__){a.err=img?"Photo questions need AI answers, which aren't set up on this device yet.":"Add your Anthropic API key to get written answers. Meanwhile, here are the best matches.";a.errSettings=true}refreshAsk();return}
 if(ASKCTL)ASKCTL.abort();ASKCTL=new AbortController();
 const hist=[];ASKS.slice(0,-1).slice(-4).forEach(t=>{if(t.text){hist.push({role:"user",content:t.q});hist.push({role:"assistant",content:t.text})}});
 hist.push({role:"user",content:q+(ctxName?` (I'm asking about ${ctxName}.)`:"")});
 try{a.text=await aiAsk(hist,{system:systemFor(notes,!!img),image:img,signal:ASKCTL.signal,onText:t=>{a.text=t;a.state="streaming";refreshAsk()}});a.state="done"}
 catch(e){a.state="done";a.text=e&&e.text||a.text||"";a.err=aiErrText(e);a.errSettings=["no_key","bad_key"].includes(e&&e.code)}
 (a.text.match(/\[(\d+(?:\s*,\s*\d+)*)\]/g)||[]).forEach(m=>m.slice(1,-1).split(",").forEach(x=>a.used.add(+x.trim()-1)));
 if(a.text&&!a.used.size)notes.slice(0,3).forEach((p,i)=>a.used.add(i));
 refreshAsk()}
function startAsk(q,ctx,prompts){if(ctx!==undefined)ASKCTX=ctx;ASKPROMPTS=prompts||null;if(q){ask(q)}else nav({v:"ask"})}

document.addEventListener("submit",e=>{if(e.target.id==="askForm"){e.preventDefault();const v=document.getElementById("askq").value;ASKCTX=null;startAsk(v);return}
 if(e.target.id==="askForm2"){e.preventDefault();const i=document.getElementById("askq2");const v=i.value;i.value="";const img=PENDINGIMG;PENDINGIMG=null;ask(v,img)}});
document.addEventListener("change",async e=>{if(e.target.id!=="askphoto"||!e.target.files||!e.target.files[0])return;
 try{PENDINGIMG=await aiPrepImage(e.target.files[0]);render();const i=document.getElementById("askq2");if(i)i.focus()}catch(err){}});
document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.askmode){S.askMode=d.askmode;save();if(d.askq){if(d.askctxid)ASKCTX=d.askctxid;ASKPROMPTS=null;ask(d.askq);return}if(b.hasAttribute("data-askgo")){ASKCTX=null;nav({v:"ask"});return}if(cur().v==="ask")render();return}
 if(d.asklen){S.askLen=d.asklen;save();render();return}
 if(d.asksug){ASKPROMPTS=null;ask(d.asksug);return}
 if(b.hasAttribute("data-askstop")){if(ASKCTL)ASKCTL.abort();return}
 if(b.hasAttribute("data-asknew")){ASKS=[];ASKCTX=null;ASKPROMPTS=null;render();return}
 if(b.hasAttribute("data-askctxclear")){ASKCTX=null;ASKPROMPTS=null;render();return}
 if(b.hasAttribute("data-imgclear")){PENDINGIMG=null;render();return}
 if(b.hasAttribute("data-aiopen")){const dd=document.getElementById("aidetails");if(dd){dd.open=true;dd.scrollIntoView({block:"center"})}return}
 if(d.askabout){ASKCTX=d.askabout;ASKPROMPTS=null;nav({v:"ask"});return}});

/* "How do we know?" for one answer: what it rests on and where it's thin */
function howKnowAnswer(a){const used=[...a.used].map(i=>a.notes[i]).filter(Boolean);const sp=splitAnswer(a.text);
 const cls={};used.forEach(p=>{const k=p.tag==="comm"?"comm":(p.tag==="est"&&p.src.length&&!evidenceStrong(p.src))?"rep":(p.tag||"est");cls[k]=(cls[k]||0)+1});
 const srcs=[...new Set(used.flatMap(p=>p.src))];const tiers={};srcs.forEach(i=>{const t=tierOf(i).short;tiers[t]=(tiers[t]||0)+1});
 const dates=srcs.map(srcDate).filter(Boolean).map(d=>d.y);const lim=[];
 if(!used.length)lim.push("The answer cites none of the guide's notes, so treat all of it as unverified.");
 if(sp.beyond)lim.push("Part of the answer is general knowledge from outside the guide (marked Beyond the guide) and isn't sourced here.");
 if(cls.comm)lim.push(`${cls.comm} point${cls.comm>1?"s come":" comes"} from community reports: individual, self-reported experiences.`);
 if(cls.deb||cls.unk)lim.push("Some of what it draws on is debated or uncertain among sources.");
 if(cls.rep)lim.push("Some claims rest on journalism only.");
 if(dates.length&&Math.min(...dates)<new Date().getFullYear()-1)lim.push(`The oldest source used dates from ${Math.min(...dates)}; practical details may have changed.`);
 return `<div class="hkbox"><p><b>Written by AI</b> from ${used.length} of the guide's notes. AI answers aren't added to the guide.</p>
  <p>${Object.entries(cls).map(([k,n])=>`<span class="tag ${k}">${esc(TAGS[k]?TAGS[k][0]:k)}</span> ${n}`).join(" ")}</p>
  ${srcs.length?`<p class="hint">Sources behind it: ${Object.entries(tiers).map(([t,n])=>`${n} ${esc(t)}`).join(", ")}${dates.length?`; dated ${Math.min(...dates)}–${Math.max(...dates)}`:""}.</p>`:""}
  ${lim.length?`<ul class="flags">${lim.map(l=>`<li>${esc(l)}</li>`).join("")}</ul>`:`<p class="hint">No limitations detected beyond the usual: sources can be wrong, and hours change.</p>`}</div>`}
