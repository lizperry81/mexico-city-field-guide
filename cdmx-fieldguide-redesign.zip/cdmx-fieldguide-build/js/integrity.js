/* Information integrity.
   Keeps five kinds of information apart and says where each came from:
     1. historical and cultural knowledge  (claims with sources and an evidence class)
     2. editorial interpretation and picks (the guide's ratings, "why" lines, stories)
     3. community contributions            (S.community, moderated, always attributed and dated)
     4. current practical information      (hours, prices, closures, with freshness from real source dates
                                            and a verification log of actual checks)
     5. AI explanations                    (never stored into the knowledge base; "How do we know?")
   Nothing here manufactures a date, a verification or a review. */

/* ---------- 1. Source hierarchy ---------- */
const TIERS={
 Primary:{n:1,short:"Tier 1 · Primary",d:"Documents, codices, inscriptions, archaeological evidence, original maps and photographs."},
 Scholarly:{n:2,short:"Tier 2 · Academic",d:"Peer-reviewed scholarship, university publications, scholarly books and journals."},
 Institutional:{n:3,short:"Tier 3 · Institutional",d:"INAH, UNAM, museums, archives, government and cultural institutions."},
 "Official site":{n:3,short:"Official site (practical)",d:"A venue's or operator's own site: used for hours and prices, not for history."},
 Journalism:{n:4,short:"Tier 4 · Journalism",d:"Reporting, interviews, cultural criticism."},
 "Food critic":{n:4,short:"Tier 4 · Critic",d:"Restaurant critics and guides, for food picks only."},
 Forum:{n:9,short:"Community · not evidence",d:"Forums and review sites: used to find leads and for attributed visitor voices, never to support a fact."},
 "Travel blog":{n:9,short:"Blog · not evidence",d:"Travel blogs: leads only, never evidence."}};
const tierOf=id=>TIERS[(SRC[id]||{}).t]||{n:9,short:"Unclassified",d:""};
const evidenceStrong=src=>(src||[]).some(i=>SRC[i]&&[1,2,3].includes(tierOf(i).n)&&SRC[i].t!=="Official site");
/* a source's own date, read from its citation, e.g. "(Nov 2026)", "(2015)" */
function srcDate(id){const n=(SRC[id]||{}).n||"";const ps=n.match(/\(([^()]*)\)/g)||[];for(let k=ps.length-1;k>=0;k--){const m=ps[k].match(/\b(19[5-9]\d|20[0-3]\d)\b/);if(m){const mm=ps[k].match(/([A-Z][a-z]{2,8})\.?\s(19|20)\d{2}/);return {y:+m[1],label:mm?mm[0]:m[1]}}}return null}

/* ---------- Claims registry ---------- */
function hashId(t){let h=5381;for(let i=0;i<t.length;i++)h=((h<<5)+h+t.charCodeAt(i))|0;return "c"+(h>>>0).toString(36)}
const EVCLASS={est:"Well established",rep:"Reported",deb:"Scholarly debate",unk:"Uncertain",trad:"Traditional account"};
function classOf(c){const k=c.tag||"est";return k==="est"&&c.src.length&&!evidenceStrong(c.src)?"rep":k}
let CLAIMREG=null;
function claimRegistry(){if(CLAIMREG)return CLAIMREG;const r=runChecks();const all=r.claims||[];
 const out=all.map(c=>({id:hashId(c.text),where:c.where,text:c.text,src:c.src,tag:c.tag,cls:classOf(c)}));
 (STORIES||[]).forEach(s=>(s.chapters||[]).forEach(ch=>(ch.p||[]).forEach(p=>out.push({id:hashId(p[0]),where:"Story: "+s.title,text:p[0],src:p[1]||[],tag:p[2]||"est",cls:classOf({src:p[1]||[],tag:p[2]})}))));
 CLAIMREG=out;return out}

/* ---------- 4. Freshness of practical information ---------- */
let VERIFY=[];/* data/verify.json: actual checks, each {ref, what, date, method, source, result} */
function freshness(srcIds,ref){const v=VERIFY.filter(x=>x.ref===ref).sort((a,b)=>b.date.localeCompare(a.date))[0];
 if(v)return {cls:"ok",t:`Checked ${fmtDay(v.date)} (${v.method})`,v};
 const ds=(srcIds||[]).map(srcDate).filter(Boolean).sort((a,b)=>b.y-a.y);
 if(!(srcIds||[]).length)return {cls:"no",t:"Verification needed: no source for this practical information"};
 if(!ds.length)return {cls:"warn",t:"Source undated: verification needed"};
 const yNow=new Date().getFullYear(),age=yNow-ds[0].y;
 return age<=0?{cls:"ok",t:`From a source dated ${ds[0].label}; not re-checked since`}:age===1?{cls:"warn",t:`From a source dated ${ds[0].label}: may have changed`}:{cls:"no",t:`From a ${ds[0].label} source: likely out of date, verify before relying on it`}}
const fmtDay=iso=>{const d=new Date(iso+"T12:00:00");return isNaN(d)?iso:d.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})};
function freshHTML(srcIds,ref){const f=freshness(srcIds,ref);return `<span class="fresh ${f.cls}" title="Information freshness">${esc(f.t)}</span>`}

/* ---------- 2. Editorial status (workflow), never claimed beyond what happened ---------- */
const EDSTATES=["Research needed","Draft","Sources verified","Editorial review","Published","Needs updating"];
function edStatus(kind,id){const o=((S.editorial||{})[kind+":"+id]);if(o)return o;
 if(kind==="story"){const s=storyById(id);return {state:s&&(s.gaps||[]).length>2?"Research needed":"Draft",by:"automatic",note:"Assembled from the guide's sourced content by an AI researcher; not yet reviewed by a person."}}
 const pts=placeStoryPts(id).length;return {state:pts?"Draft":"Research needed",by:"automatic",note:pts?"Sources cited; not yet reviewed by a person.":"No dated history for this place yet."}}
function edStatusHTML(kind,id){const e=edStatus(kind,id);return `<span class="edstat" title="${esc(e.note||"")}">Editorial status: <b>${esc(e.state)}</b>${e.by==="automatic"?" (automatic)":e.at?` · set ${fmtDay(e.at)}`:""}</span>`}

/* ---------- 3. Community contributions ---------- */
const CTYPES={
 restaurant:{n:"Restaurant or food",q:[["order","What did you order?"],["good","What was especially good?"],["know","What should visitors know?"],["price","Approximate price per person"],["vibe","What was the atmosphere like?"],["return","Would you return?"]],rating:true},
 museum:{n:"Museum or site",q:[["time","How much time should someone allow?"],["worth","Which parts are worthwhile?"],["before","What should visitors know beforehand?"],["surprise","What surprised you?"],["tour","Is a guided tour worthwhile?"]],rating:true},
 neighborhood:{n:"Neighborhood",q:[["interest","What makes the area interesting?"],["notice","What should visitors notice?"],["changing","What is changing?"],["respect","What should visitors respect?"]],rating:false},
 logistics:{n:"Practical update",q:[["accurate","Was the guide's information accurate?"],["access","Any accessibility limitations?"],["changes","Closures or unexpected changes?"]],rating:false},
 closed:{n:"Report closed or moved",q:[["what","What did you find? (closed, moved, new hours)"]],rating:false},
 correction:{n:"Correction request",q:[["what","What is wrong, and what is the correct information?"],["source","How do you know? (sign, official site, phone call)"]],rating:false}};
function pseudoId(){let id="";try{id=localStorage.getItem("fg-pid")||""}catch(e){}if(!id){id="v"+Math.random().toString(36).slice(2,8);try{localStorage.setItem("fg-pid",id)}catch(e){}}return id}
function community(){if(!Array.isArray(S.community))S.community=[];return S.community}
const normTxt=t=>norm(String(t)).replace(/[^a-z0-9ñ ]+/g," ").replace(/\s+/g," ").trim();
const SPAM=[/https?:\/\/|www\.|\.com\b/i,/(\+?\d[\d\s-]{8,}\d)/,/(.)\1{5,}/,/!!!+/];
const PROMO=/\b(discount|promo|promotion|coupon|use code|follow us|dm (me|us)|whatsapp|book now|best price|our (restaurant|menu|team))\b/i;
const ALLEGE=/\b(stole|stolen|steal|thief|thieves|scam|scammed|fraud|robbed|poison(ed)?|assault(ed)?|drugged|ripped off|cheat(ed)?)\b/i;
const ABUSE=/\b(idiot|stupid|moron|filthy|vermin|go back to|those people)\b/i;
function moderate(c,list){const flags=[];const txt=Object.values(c.f||{}).join(" ");
 if(SPAM.some(r=>r.test(txt)))flags.push("Possible spam (links, phone numbers or repeated characters)");
 if(PROMO.test(txt)&&!c.commercial)flags.push("Promotional language without a commercial disclosure");
 if(ALLEGE.test(txt))flags.push("Contains an unverified allegation; can't be shown as fact");
 if(ABUSE.test(txt))flags.push("Possibly abusive or discriminatory language");
 const nt=normTxt(txt);if(nt&&list.some(o=>o.id!==c.id&&o.status!=="removed"&&normTxt(Object.values(o.f||{}).join(" "))===nt))flags.push("Duplicate of an existing contribution");
 const day=864e5,recent=list.filter(o=>o.id!==c.id&&o.place===c.place&&o.rating===5&&Math.abs(o.at-c.at)<day);
 if(c.rating===5&&recent.length>=2)flags.push(`Suspicious pattern: ${recent.length+1} five-star reviews of this place within 24 hours`);
 const burst=list.filter(o=>o.id!==c.id&&o.pid===c.pid&&Math.abs(o.at-c.at)<10*60e3);
 if(burst.length>=3)flags.push("Suspicious pattern: many contributions from one contributor in minutes");
 if(txt.trim().length<12)flags.push("Too short to be useful");
 return flags}
function submitContribution(c){const list=community();c.id="u"+Date.now().toString(36)+Math.random().toString(36).slice(2,5);c.pid=pseudoId();c.at=Date.now();c.reports=[];
 c.flags=moderate(c,list);c.status=c.flags.length?"flagged":"pending";c.modAt=null;list.push(c);save();return c}
function visibleContribs(place){return community().filter(c=>c.place===place&&c.status==="approved")}
const monthsAgo=ms=>Math.floor((Date.now()-ms)/(30.4*864e5));
function contribAge(c){const ref=c.visit?new Date(c.visit+"-15T12:00:00").getTime():c.at,m=monthsAgo(ref);return m<1?"this month":m<12?`${m} month${m>1?"s":""} ago`:`${Math.floor(m/12)} year${m>=24?"s":""} ago, may be out of date`}
function contribHTML(c,editorialHours){const T=CTYPES[c.type]||{n:c.type,q:[]};
 const conflict=(c.type==="closed"||(c.type==="logistics"&&/clos|hour|chang/i.test((c.f||{}).changes||"")))&&editorialHours;
 return `<div class="contrib"><div class="cmeta"><b>${esc(T.n)}</b> · community report from ${esc(c.pid)} · visit reported ${esc(c.visit||"date not given")} (self-reported, not verified) · ${esc(contribAge(c))}${c.commercial?` · <span class="pill warn">Has a commercial relationship</span>`:""}</div>
  ${c.rating?`<p class="crating">${"★".repeat(c.rating)}${"☆".repeat(5-c.rating)} <span class="hint">one person's rating</span></p>`:""}
  ${T.q.filter(([k])=>(c.f||{})[k]).map(([k,l])=>`<p><span class="cq">${esc(l)}</span> ${esc(c.f[k])}</p>`).join("")}
  ${conflict?`<p class="conflict">This report differs from the guide's editorial information, which hasn't been re-verified yet. Treat both with care.</p>`:""}
  <div class="mc-btns"><button class="linkbtn" data-creport="${c.id}">Report this</button>${c.pid===pseudoId()?`<button class="linkbtn" data-cdel="${c.id}">Delete mine</button>`:""}</div></div>`}
function communityBlockHTML(place,name,kind){const vis=visibleContribs(place),mine=community().filter(c=>c.place===place&&c.pid===pseudoId()&&c.status!=="approved"&&c.status!=="removed");
 const st=getStop(place)||siteById(place)||{};const T=kind||((st.types||[]).some(t=>/Museum/i.test(t))?"museum":"museum");
 return `<section class="community"><h2 class="sech">Community reports</h2><p class="hint">Individual experiences from travelers, kept separate from the guide's sourced history and editorial picks. Visits are self-reported. Reports are reviewed before they appear.</p>
 ${vis.length?vis.map(c=>contribHTML(c,!!st.hours)).join(""):`<p class="empty">No community reports for ${esc(name)} yet.</p>`}
 ${mine.length?`<p class="hint">You have ${mine.length} report${mine.length>1?"s":""} awaiting review${mine.some(c=>c.status==="flagged")?" (flagged by the automatic checks)":""}.</p>`:""}
 <details class="cform"><summary>Share your experience</summary>${contribForm(place,T)}</details></section>`}
function contribForm(place,type){const T=CTYPES[type];
 return `<form class="contribform" data-cplace="${esc(place)}"><label>What kind<select name="type" data-ctype>${Object.entries(CTYPES).map(([k,v])=>`<option value="${k}"${k===type?" selected":""}>${esc(v.n)}</option>`).join("")}</select></label>
  ${T.q.map(([k,l],i)=>`<label>${esc(l)}<textarea name="f_${k}" rows="${i?1:2}"></textarea></label>`).join("")}
  ${T.rating?`<label>Your rating (optional)<select name="rating"><option value="">No rating</option>${[5,4,3,2,1].map(n=>`<option>${n}</option>`).join("")}</select></label>`:""}
  <label>When did you visit?<input type="month" name="visit"></label>
  <label class="chk"><input type="checkbox" name="commercial"> I work for, own or was paid by this place</label>
  <label class="chk"><input type="checkbox" name="consent" required> I wrote this from my own experience and agree to it being shown with a pseudonym</label>
  <div class="mc-btns"><button type="submit" class="btn small primary">Submit for review</button></div></form>`}

/* ---------- Recommendation reasons: significance and fit, not popularity ---------- */
function recReasons(x){const r=[];const ns=STORIES.filter(s=>(s.places||[]).includes(x.id)||(x.link&&(s.places||[]).includes(x.link))).length;
 if(ns)r.push(`in ${ns} ${ns>1?"stories":"story"}`);
 const ints=(S.prefs&&S.prefs.ints)||[];if(ints.length&&(x.types||[]).some(t=>ints.some(i=>norm(t).includes(norm(i)))))r.push("matches your interests");
 if(S.here&&S.here.ll&&x.ll){const d=hav(S.here.ll,x.ll);if(d<1500)r.push(`${distText(d)} from you`)}
 const cv=visibleContribs(x.id).length;if(cv)r.push(`${cv} community report${cv>1?"s":""}`);
 if(x.rec)r.push(`guide rating: ${x.rec.l.toLowerCase()}`);return r}
function recScore(x){const ns=STORIES.filter(s=>(s.places||[]).includes(x.id)||(x.link&&(s.places||[]).includes(x.link))).length;
 let s=ns*2+((x.rec&&x.rec.s)||0);const ints=(S.prefs&&S.prefs.ints)||[];if(ints.length&&(x.types||[]).some(t=>ints.some(i=>norm(t).includes(norm(i)))))s+=2;
 if(S.here&&S.here.ll&&x.ll){const d=hav(S.here.ll,x.ll);s+=d<800?3:d<2000?1:0}return s}

/* ---------- How do we know? ---------- */
function vHowKnow(){const reg=claimRegistry(),n=reg.length,by={};reg.forEach(c=>by[c.cls]=(by[c.cls]||0)+1);
 const tiers={};Object.keys(SRC).forEach(i=>{const t=tierOf(i).short;tiers[t]=(tiers[t]||0)+1});
 return `<section class="storyhead"><span class="eyebrow">How do we know?</span><h1>How the guide knows what it says</h1><p class="lede">Every historical sentence carries its sources and an evidence class. Editorial opinions, community reports, practical details and AI answers are each labeled as what they are.</p></section>
 <section class="aside"><h3>Evidence classes</h3>${Object.entries(EVCLASS).map(([k,v])=>`<p><span class="tag ${k}">${v}</span> ${esc(TAGS[k][1])}. <span class="hint">${by[k]||0} of ${n} claims.</span></p>`).join("")}</section>
 <section class="aside"><h3>Source hierarchy</h3>${Object.entries(TIERS).filter(([k])=>k!=="Primary").map(([k,v])=>`<p><b>${esc(v.short)}</b>: ${esc(v.d)} <span class="hint">${tiers[v.short]||0} sources.</span></p>`).join("")}<p class="hint">Tier 1 primary sources (codices, archival documents) aren't cited directly yet: the guide relies on scholars and institutions who work from them.</p></section>
 <section class="aside"><h3>The five kinds of information</h3>
  <p><b>History and culture.</b> Footnoted claims with an evidence class.</p>
  <p><b>Editorial picks.</b> The guide's ratings and "why" lines are judgments, labeled as the guide's.</p>
  <p><b>Community reports.</b> One traveler's experience, dated, pseudonymous, reviewed before display, never merged into the history.</p>
  <p><b>Practical information.</b> Hours, prices and closures show the date of their source and any actual re-check; nothing is shown as current without one.</p>
  <p><b>AI answers.</b> Built only from the guide's notes, with a "How do we know?" panel listing every note used. Answers are never added to the guide's knowledge.</p></section>
 <div class="mc-btns"><button class="btn" data-go="editorial:">Open the editorial dashboard</button><button class="btn" data-go="sources:">All sources</button></div>`}

/* ---------- Editorial dashboard ---------- */
const COVER=[["Pre-Columbian civilizations","teotihuacan|olmec|preclassic|cuicuilco|toltec|maya"],["Mexica society and politics","mexica|tenochtitlan|tribute|tlatoani|moctezuma|axayácatl|itzcóatl"],["Other Indigenous communities","xochimilca|tlaxcal|tepanec|nahua|otom|mixtec|zapotec|coatlinchan"],["The conquest","cortés|conquest|noche triste|toxcatl|1521"],["Indigenous alliances and resistance","tlaxcal|ally|allies|revolt|resist|riot"],["Colonial institutions","viceroy|new spain|inquisition|audiencia|colonial"],["Religion and cultural change","church|friar|franciscan|jesuit|cathedral|convent|virgin"],["Independence","independence|hidalgo|morelos|iturbide|1810|1821"],["Nineteenth century","1847|maximilian|juárez|reform laws|intervention|santa anna"],["The Mexican Revolution","revolution|zapata|villa|madero|carranza|1910"],["Land and labor struggles","\\bland\\b|\\blabou?r|\\bworkers?\\b|\\bstrikes?\\b|peasant|ejido|\\bwages?\\b"],["Women's history","\\bwom[ae]n\\b|kahlo|malinche|feminis"],["Indigenous survival and identity today","indigenous (people|communit|groups)|dancers|coatlinchan"],["Mexican muralism","mural|rivera|orozco|siqueiros"],["The 1968 student movement","1968|student|tlatelolco massacre|october 2"],["Urbanization and migration","migra|population|suburb|sprawl"],["Earthquakes and urban development","earthquake|1985|2017|quake|collapsed"],["Water and environment","lake|water|spring|aqueduct|flood|drain|sinking|canal"],["Class and inequality","\\brich\\b|\\bpoor\\b|\\bclass\\b|inequalit|\\belite|wealth"],["Food and traditions","maize|taco|food|market|cacao|tortilla|pozole|nixtamal"],["Contemporary politics and social change","\\b20(1[89]|2\\d)\\b|protest"],["Gentrification and housing","\\brents?\\b|gentrif|housing|tenants?|airbnb"],["Informal economy and everyday life","vendor|street food|informal|commute|market stall"]];
function coverage(){const reg=claimRegistry();return COVER.map(([t,re])=>{const r=new RegExp(re,"i");const n=reg.filter(c=>r.test(c.text)).length;return [t,n]})}
function geoCoverage(){return Object.values(AD).map(a=>{const ids=Object.keys(a.stops).concat(a.sites.filter(s=>!s.link).map(s=>s.id));const n=claimRegistry().filter(c=>ids.some(id=>c.where&&(c.where===placeName(id)||c.where.startsWith(placeName(id))))).length;return [a.name,ids.length,n]})}
function practicalRecords(){const out=[];for(const aid in AD){const a=AD[aid];
 a.sites.forEach(s=>{if(s.link)return;if(s.hours||s.cost)out.push({ref:s.id,name:s.name,kind:"Hours/cost",src:s.hsrc?[s.hsrc]:[]})});
 for(const k in a.stops){const st=a.stops[k];if(st.hours&&!st.siteRef)out.push({ref:k,name:st.name,kind:"Hours",src:st.hsrc?[st.hsrc]:[]})}
 a.food.forEach(f=>out.push({ref:"food:"+aid+":"+f.name,name:f.name,kind:"Restaurant",src:f.hsrc?[f.hsrc]:(f.crit||[])}))}
 return out.map(r=>Object.assign(r,{f:freshness(r.src,r.ref)}))}
function qualityMetrics(){const r=runChecks(),reg=claimRegistry();const sourced=reg.filter(c=>c.src.length).length;
 const stories=STORIES.length,storiesFull=STORIES.filter(s=>(s.chapters||[]).every(ch=>!ch.p||ch.p.every(p=>(p[1]||[]).length))).length;
 const pr=practicalRecords(),cur=pr.filter(x=>x.f.cls==="ok").length;const C=community();
 const gaps=STORIES.reduce((n,s)=>n+(s.gaps||[]).length,0);
 return [["Claims with at least one source",`${sourced} of ${reg.length} (${Math.round(sourced/reg.length*100)}%)`],
  ["Claims resting on institutional or scholarly sources",`${reg.filter(c=>evidenceStrong(c.src)).length} of ${reg.length}`],
  ["Unsourced claims (not tagged Uncertain)",String(r.unsourced.length)],["Claims resting only on forums or blogs",String(r.opinionOnly.length)],
  ["Stories whose own new text is fully cited",`${storiesFull} of ${stories}`],["Open research gaps listed in stories",String(gaps)],
  ["Articles reviewed by a person","0 so far"],
  ["Practical records with a current-year source or a logged re-check",`${cur} of ${pr.length} (${Math.round(cur/Math.max(1,pr.length)*100)}%)`],
  ["Community contributions awaiting moderation",String(C.filter(c=>c.status==="pending").length)],["Flagged contributions",String(C.filter(c=>c.status==="flagged").length)],
  ["Reported contributions awaiting resolution",String(C.filter(c=>c.status==="approved"&&c.reports.length).length)],["Closed or moved reports",String(C.filter(c=>c.type==="closed"&&c.status!=="removed").length)]]}
function vEditorial(){const reg=claimRegistry(),q=(S.claimQ||"").trim(),C=community();
 const queue=C.filter(c=>c.status==="pending"||c.status==="flagged"||(c.status==="approved"&&c.reports.length));
 const cov=coverage(),geo=geoCoverage(),pr=practicalRecords().filter(x=>x.f.cls!=="ok");
 const deb=reg.filter(c=>c.cls==="deb"),weak=reg.filter(c=>c.cls==="rep"),unk=reg.filter(c=>c.cls==="unk");
 const found=q.length>=3?reg.filter(c=>norm(c.text).includes(norm(q))||c.id===q).slice(0,30):[];
 const arts=STORIES.map(s=>["story",s.id,s.title]).concat(Object.values(AD).flatMap(a=>Object.keys(a.stops).map(k=>["place",k,placeName(k)])));
 return `<section class="storyhead"><span class="eyebrow">Editorial dashboard</span><h1>Content quality</h1><p class="lede">Measured from the guide's own data each time this page opens. Nothing here is estimated.</p></section>
 <section class="aside"><h3>Quality measures</h3><dl class="metrics">${qualityMetrics().map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join("")}</dl></section>
 <section class="aside"><h3>Moderation queue (${queue.length})</h3>${queue.length?queue.map(c=>`<div class="modrow"><div class="cmeta"><b>${esc(placeName(c.place))}</b> · ${esc((CTYPES[c.type]||{}).n||c.type)} · ${esc(c.status)} · from ${esc(c.pid)} · ${fmtDay(new Date(c.at).toISOString().slice(0,10))}</div>${c.flags.length?`<ul class="flags">${c.flags.map(f=>`<li>${esc(f)}</li>`).join("")}</ul>`:""}${c.reports.length?`<p class="hint">Reported ${c.reports.length}×: ${esc(c.reports.map(r=>r.why).join("; "))}</p>`:""}<p>${esc(Object.values(c.f||{}).join(" · "))}</p><div class="mc-btns"><button class="btn small" data-cmod="${c.id}:approved">Approve</button><button class="btn small" data-cmod="${c.id}:flagged">Flag</button><button class="btn small" data-cmod="${c.id}:removed">Remove</button></div></div>`).join(""):`<p class="empty">Nothing waiting.</p>`}</section>
 <section class="aside"><h3>Inspect a claim</h3><form id="claimForm" class="askrow"><input id="claimQ" placeholder="Search claims, or paste a claim ID" value="${esc(q)}"><button type="submit">Find</button></form>
  ${found.map(c=>`<div class="claimrow"><span class="hint">${esc(c.id)} · ${esc(c.where)}</span><p>${esc(c.text)} <span class="tag ${c.cls}">${esc(EVCLASS[c.cls])}</span></p><ul class="srcl">${c.src.map(i=>SRC[i]?`<li><a href="${SRC[i].u}" target="_blank" rel="noopener">${esc(SRC[i].n)}</a> · ${esc(tierOf(i).short)}${srcDate(i)?` · dated ${esc(srcDate(i).label)}`:" · undated"}</li>`:`<li>Missing source id ${esc(i)}</li>`).join("")||"<li>No source</li>"}</ul></div>`).join("")}
  ${q.length>=3&&!found.length?`<p class="empty">No claim matches.</p>`:""}</section>
 <section class="aside"><h3>Historical coverage</h3><p class="hint">Claims per topic, by keyword. A crude keyword count: a high count isn\x27t comprehensive coverage, and under 20 is marked thin.</p><table class="cov"><tbody>${cov.map(([t,n])=>`<tr class="${n<20?"thin":""}"><th>${esc(t)}</th><td>${n}</td><td>${n<20?"Thin":""}</td></tr>`).join("")}</tbody></table></section>
 <section class="aside"><h3>Geographic coverage</h3><table class="cov"><thead><tr><th>Area</th><td>Places</td><td>Claims</td></tr></thead><tbody>${geo.map(([a,p,n])=>`<tr><th>${esc(a)}</th><td>${p}</td><td>${n}</td></tr>`).join("")}</tbody></table><p class="hint">Not covered at all: Iztapalapa (beyond the Cablebús), Tepito, La Merced, Doctores, Santa María la Ribera, Azcapotzalco, Ciudad Universitaria and most of the city's working-class east.</p></section>
 <section class="aside"><h3>Research backlog</h3><ul class="prompts">${STORIES.flatMap(s=>(s.gaps||[]).map(g=>`<li><b>${esc(s.title)}:</b> ${esc(g)}</li>`)).join("")}${Object.values(AD).flatMap(a=>Object.keys(a.stops).filter(k=>!placeStoryPts(k).length).map(k=>`<li><b>${esc(placeName(k))}:</b> no dated history yet.</li>`)).join("")}</ul></section>
 <section class="aside"><h3>Disputed (${deb.length}) and uncertain (${unk.length}) claims</h3><details><summary class="linkbtn">Show them</summary>${deb.concat(unk).slice(0,80).map(c=>`<p class="claimmini"><span class="tag ${c.cls}">${esc(EVCLASS[c.cls])}</span> ${esc(c.text)} <span class="hint">${esc(c.where)}</span></p>`).join("")}</details></section>
 <section class="aside"><h3>Established claims resting on journalism only (${weak.length})</h3><p class="hint">Shown to readers as "Reported" until corroborated by an institutional or scholarly source.</p><details><summary class="linkbtn">Show them</summary>${weak.slice(0,80).map(c=>`<p class="claimmini">${esc(c.text)} <span class="hint">${esc(c.where)}</span></p>`).join("")}</details></section>
 <section class="aside"><h3>Practical information needing verification (${pr.length})</h3><details><summary class="linkbtn">Show them</summary>${pr.map(x=>`<p class="claimmini"><b>${esc(x.name)}</b> · ${esc(x.kind)} · <span class="fresh ${x.f.cls}">${esc(x.f.t)}</span></p>`).join("")}</details></section>
 <section class="aside"><h3>Editorial status</h3><p class="hint">Every article starts as an automatic status. Only you can move one to Editorial review or Published, and the date is recorded.</p>
  <form id="edForm" class="edform"><select name="a">${arts.map(([k,id,t])=>`<option value="${k}:${id}">${esc(t)}</option>`).join("")}</select><select name="s">${EDSTATES.map(x=>`<option>${x}</option>`).join("")}</select><button class="btn small" type="submit">Set status</button></form>
  ${Object.entries(S.editorial||{}).map(([k,v])=>`<p class="claimmini"><b>${esc(k.startsWith("story:")?(storyById(k.slice(6))||{}).title:placeName(k.slice(6)))}</b>: ${esc(v.state)} · ${fmtDay(v.at)}</p>`).join("")}</section>`}

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.cmod){const [id,st]=d.cmod.split(":");const c=community().find(x=>x.id===id);if(c){c.status=st;c.modAt=Date.now();if(st==="approved")c.reports=[];PASSAGES=null;save();render()}return}
 if(d.creport){const c=community().find(x=>x.id===d.creport);if(c){c.reports.push({at:Date.now(),why:"Reported by a reader"});c.status="flagged";save();render()}return}
 if(d.cdel){S.community=community().filter(x=>x.id!==d.cdel);save();render();return}});
document.addEventListener("submit",e=>{const f=e.target;
 if(f.classList&&f.classList.contains("contribform")){e.preventDefault();const T=f.elements.type.value,fl={};Object.keys(CTYPES[T].q.reduce((o,[k])=>(o[k]=1,o),{})).forEach(k=>{const el=f.elements["f_"+k];if(el&&el.value.trim())fl[k]=el.value.trim()});
  const c=submitContribution({place:f.dataset.cplace,type:T,f:fl,rating:f.elements.rating&&f.elements.rating.value?+f.elements.rating.value:null,visit:f.elements.visit.value||"",commercial:f.elements.commercial.checked});
  const p=document.createElement("p");p.className="hint";p.textContent=c.status==="flagged"?"Thanks. The automatic checks flagged this for a closer look before it can appear: "+c.flags.join("; ")+".":"Thanks. Your report is waiting for review and will appear once approved.";f.replaceWith(p);return}
 if(f.id==="claimForm"){e.preventDefault();S.claimQ=document.getElementById("claimQ").value;render();return}
 if(f.id==="edForm"){e.preventDefault();S.editorial=S.editorial||{};S.editorial[f.elements.a.value]={state:f.elements.s.value,at:new Date().toISOString().slice(0,10),by:"you"};save();render();return}});
document.addEventListener("change",e=>{const t=e.target;if(t.dataset&&t.dataset.ctype!==undefined){const f=t.closest("form");const nf=document.createElement("div");nf.innerHTML=contribForm(f.dataset.cplace,t.value);f.replaceWith(nf.firstElementChild)}});
