/* My Journal: a travel notebook, not a scoreboard.
   Everything lives in S.journal (saved with the rest of the guide's state, so it syncs inside
   Claude and stays on the device in the phone app). Photos are kept in IndexedDB on this device
   only (PDB in app.js), keyed "j:<id>". */
function journal(){const J=S.journal&&typeof S.journal==="object"?S.journal:(S.journal={});
 J.saved=J.saved||{};J.notes=J.notes||[];J.qs=J.qs||[];J.read=J.read||{};J.obs=J.obs||{};return J}
function markRead(id){const J=journal();if(!J.read[id]){J.read[id]=Date.now();save()}}
const jKey=(kind,id)=>kind+":"+id;
function saveBtn(kind,id,label){const on=!!journal().saved[jKey(kind,id)];return `<button class="savebtn" aria-pressed="${on}" data-jsave="${kind}" data-jid="${esc(id)}"${label?` data-jlabel="${esc(label)}"`:""}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h12v18l-6-4-6 4z"/></svg>${on?"Saved":"Save"}</button>`}
function jLabel(k,v){const [kind,id]=[k.slice(0,k.indexOf(":")),k.slice(k.indexOf(":")+1)];
 if(kind==="story"){const s=storyById(id);return {t:s?s.title:id,sub:"Story",attr:`data-story="${id}"`}}
 if(kind==="question"){const q=questionById(id);return {t:q?q.q:id,sub:"Exploration",attr:`data-question="${id}"`}}
 if(kind==="place")return {t:placeName(id),sub:"Place",attr:placeAttr(id)};
 if(kind==="object"){const m=MUSEUMS.find(x=>x.id===id.split(":")[0]);return {t:v.label||"Object",sub:"Object · "+(m?m.museum:""),attr:m?`data-museum="${m.id}"`:""}}
 return {t:v.label||id,sub:kind,attr:""}}
function noteForm(ref,ph){return `<form class="jnote" data-jnote="${esc(ref||"")}"><label class="vh" for="jn-${esc(ref||"x")}">Note</label><textarea id="jn-${esc(ref||"x")}" name="t" rows="3" placeholder="${esc(ph||"What did you notice? What surprised you?")}"></textarea><div class="mc-btns"><button type="submit" class="btn small primary">Save note</button></div></form>`}
function notesFor(ref){return journal().notes.filter(n=>n.ref===ref)}
function noteList(list){return list.length?`<ul class="jnotes">${list.slice().reverse().map(n=>`<li><p>${esc(n.t)}</p><span class="hint">${new Date(n.at).toLocaleDateString("en-US",{month:"short",day:"numeric"})}${n.ref?` · ${esc(refName(n.ref))}`:""}</span><button class="linkbtn" data-jdel="${n.id}">Delete</button></li>`).join("")}</ul>`:""}
function refName(ref){if(!ref)return "";const [k,id]=[ref.slice(0,ref.indexOf(":")),ref.slice(ref.indexOf(":")+1)];if(k==="place")return placeName(id);if(k==="story")return (storyById(id)||{}).title||id;if(k==="mission"){const [m,i]=id.split(".");const M=MISSIONS.find(x=>x.id===m);return M?M.title:id}return id}

function vJournal(){const J=journal(),saved=Object.entries(J.saved).sort((a,b)=>b[1].at-a[1].at);
 const visited=S.visited.filter(placeExists);const read=Object.keys(J.read).map(storyById).filter(Boolean);
 const empty=!saved.length&&!J.notes.length&&!visited.length&&!read.length&&!J.qs.length;
 return `<section class="storyhead"><span class="eyebrow">My journal</span><h1>Field notes</h1><p class="lede">What you've read, seen, saved and wondered about. Kept for you, nothing to score.</p></section>
 ${empty?`<section class="gaps"><p>Your journal fills in as you go: save a story or a place, mark what you've seen on a walk, jot a note at a site, or keep a question to investigate later.</p></section>`:""}
 <section class="jsec"><h2 class="sech">A note</h2>${noteForm("","Anything: a detail you noticed, a conversation, a taste.")}${noteList(J.notes.filter(n=>!n.ref))}</section>
 <section class="jsec"><h2 class="sech">Questions to investigate</h2><form class="jnote" id="jqForm"><label class="vh" for="jq">Question</label><div class="askrow"><input id="jq" placeholder="Why are there so many churches on old temples?"><button type="submit">Keep</button></div></form>
  ${J.qs.length?`<ul class="jqs">${J.qs.map((q,i)=>`<li><span>${esc(q.t)}</span><span class="mc-btns"><button class="btn small" data-jqask="${i}">Ask the guide</button><button class="linkbtn" data-jqdel="${i}">Remove</button></span></li>`).join("")}</ul>`:""}</section>
 ${saved.length?`<section class="jsec"><h2 class="sech">Saved</h2><div class="placelist">${saved.map(([k,v])=>{const L=jLabel(k,v);return `<button class="placerow" ${L.attr}><span class="dotl"></span><b>${esc(L.t)}</b><span>${esc(L.sub)}</span></button>`}).join("")}</div></section>`:""}
 ${read.length?`<section class="jsec"><h2 class="sech">Stories you've read</h2><div class="hscroll">${read.map(storyTile).join("")}</div></section>`:""}
 ${visited.length?`<section class="jsec"><h2 class="sech">Places you've been</h2><div class="placelist">${visited.map(id=>{const a=STOPIDX[id]||SITEIDX[id],ns=notesFor("place:"+id).length;return `<button class="placerow" style="--line:${LINECOL[a]}" ${placeAttr(id)}><span class="dotl"></span><b>${esc(placeName(id))}</b><span>${esc(AD[a].name)}${ns?` · ${ns} note${ns>1?"s":""}`:""}</span></button>`}).join("")}</div></section>`:""}
 ${J.notes.some(n=>n.ref)?`<section class="jsec"><h2 class="sech">Notes from the field</h2>${noteList(J.notes.filter(n=>n.ref))}</section>`:""}
 <section class="jsec"><h2 class="sech">Field missions</h2>${missionList()}</section>
 <section class="jsec"><h2 class="sech">Photos</h2><div id="jphotos" class="jphotos"><p class="hint">Photos you add to observations and places appear here. They stay in this browser on this device.</p></div></section>`}

/* ---------- Field missions ---------- */
function missionDone(m){const o=journal().obs[m.id]||{};return m.items.filter((_,i)=>o[i]&&o[i].done).length}
function missionList(){return `<div class="qlist">${MISSIONS.map(m=>{const d=missionDone(m);return `<button class="qcard" data-mission="${m.id}"><span class="qq">${esc(m.title)}</span><span class="qp">${esc(m.intro)}${d?` · ${d} of ${m.items.length} observed`:""}</span></button>`}).join("")}</div>`}
function vMission(){
 const m=MISSIONS.find(x=>x.id===cur().id);if(!m)return "";
 const o=journal().obs[m.id]||{},done=missionDone(m),pct=Math.round(done/Math.max(1,m.items.length)*100);
 const reflection=o.reflection||"";
 return `<section class="storyhead mission-head"><span class="eyebrow">The Field · guided observation</span><h1>${esc(m.title)}</h1><p class="lede">${esc(m.intro)}</p>
 ${m.outcome?`<div class="mission-instructions"><span class="eyebrow">What you are learning</span><p>${esc(m.outcome)}</p></div>`:""}<div class="mission-progress"><div class="mission-progress-label"><b>${done} of ${m.items.length} observations</b><span>${pct}% complete</span></div><div class="mission-progress-track"><i style="width:${pct}%"></i></div></div></section>
 <section class="mission-instructions"><span class="eyebrow">How to use this mission</span><p>Take your time. Look closely before reading the hint. Record what you actually notice, then use the guide to connect your observation to the larger story. You can complete this in any order.</p></section>
 <ol class="mission">${m.items.map((it,i)=>{const r=o[i]||{};return `<li class="${r.done?"done":""}"><div class="mhead"><button class="mcheck" aria-pressed="${!!r.done}" data-mdone="${m.id}.${i}" aria-label="${r.done?"Mark not yet observed":"Mark observed"}">${r.done?"✓":""}</button><div><span class="mission-step">OBSERVATION ${String(i+1).padStart(2,"0")}</span><p class="mt">${esc(it.t)}</p><details class="mission-hint"><summary>What should I look for?</summary><p class="hint">${esc(it.hint)}</p></details>${it.places.filter(placeExists).length?`<div class="chips">${it.places.filter(placeExists).map(id=>`<button class="chip" ${placeAttr(id)}>${esc(placeName(id))}</button>`).join("")}</div>`:""}</div></div>
  <form class="jnote" data-jobs="${m.id}.${i}"><label class="vh" for="ob-${m.id}-${i}">Your observation</label><textarea id="ob-${m.id}-${i}" name="t" rows="2" placeholder="What did you find? What details stood out?">${esc(r.t||"")}</textarea><div class="mc-btns"><button type="submit" class="btn small">Save observation</button>${typeof indexedDB!=="undefined"?`<label class="btn small">Add photo<input type="file" accept="image/*" capture="environment" class="vh" data-jphoto="m:${m.id}.${i}"></label>`:""}</div><div class="jph" data-jphslot="m:${m.id}.${i}"></div></form></li>`}).join("")}</ol>
 <section class="mission-reflection"><span class="eyebrow">Bring it together</span><h2>What did the city teach you?</h2><p>${esc(m.reflection||"Look back at what you noticed. What changed in your understanding? What question do you want to carry to the next place?")}</p>
 <form data-jreflection="${m.id}"><label class="vh" for="mission-reflection-${m.id}">Your reflection</label><textarea id="mission-reflection-${m.id}" name="reflection" rows="4" placeholder="I hadn't noticed that…">${esc(reflection)}</textarea><button type="submit" class="btn primary small">Save reflection</button></form>
 ${done===m.items.length?`<p class="mission-complete">All observations recorded. Your field study is ready to revisit in My Journal.</p>`:`<p class="hint">Your progress and reflection are saved in My Journal on this device.</p>`}</section>`;
}
/* photos (IndexedDB) */
function jPhotoFill(){if(typeof PDB==="undefined")return;
 document.querySelectorAll("[data-jphslot]").forEach(el=>{const k="j:"+el.dataset.jphslot;PDB.get(k).then(b=>{if(b){const u=URL.createObjectURL(b);el.innerHTML=`<img class="myph" src="${u}" alt="Your photo">`}}).catch(()=>{})});
 const g=document.getElementById("jphotos");if(g){const keys=[];Object.entries(journal().obs).forEach(([m,o])=>Object.entries(o).forEach(([i,r])=>{if(r.photo)keys.push(["j:m:"+m+"."+i,refName("mission:"+m+"."+i)])}));
  (S.visited||[]).forEach(id=>keys.push([id,placeName(id)]));
  Promise.all(keys.map(([k,l])=>PDB.get(k).then(b=>b?[b,l]:null).catch(()=>null))).then(r=>{r=r.filter(Boolean);if(r.length)g.innerHTML=r.map(([b,l])=>`<figure><img class="myph" src="${URL.createObjectURL(b)}" alt="${esc(l)}"><figcaption>${esc(l)}</figcaption></figure>`).join("")})}}

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.jsave){const J=journal(),k=jKey(d.jsave,d.jid);if(J.saved[k])delete J.saved[k];else J.saved[k]={at:Date.now(),label:d.jlabel||""};save();const on=!!J.saved[k];b.setAttribute("aria-pressed",on);b.lastChild.textContent=on?"Saved":"Save";return}
 if(d.jdel){const J=journal();J.notes=J.notes.filter(n=>n.id!==d.jdel);save();render();return}
 if(d.jqdel!==undefined){journal().qs.splice(+d.jqdel,1);save();render();return}
 if(d.jqask!==undefined){const q=journal().qs[+d.jqask];if(q){ASKCTX=null;ask(q.t)}return}
 if(d.mission){nav({v:"mission",id:d.mission});return}
 if(d.mdone){const [m,i]=d.mdone.split(".");const J=journal();J.obs[m]=J.obs[m]||{};const r=J.obs[m][i]=J.obs[m][i]||{};r.done=!r.done;r.at=Date.now();save();render();return}});
document.addEventListener("submit",e=>{const f=e.target;
 if(f.dataset&&f.dataset.jnote!==undefined){e.preventDefault();const t=(f.elements.t.value||"").trim();if(!t)return;journal().notes.push({id:"n"+Date.now(),ref:f.dataset.jnote,t,at:Date.now()});save();render();return}
 if(f.dataset&&f.dataset.jobs){e.preventDefault();const [m,i]=f.dataset.jobs.split(".");const J=journal();J.obs[m]=J.obs[m]||{};const r=J.obs[m][i]=J.obs[m][i]||{};r.t=(f.elements.t.value||"").trim();if(r.t)r.done=true;r.at=Date.now();save();render();return}
 if(f.dataset&&f.dataset.jreflection){e.preventDefault();const id=f.dataset.jreflection,J=journal();J.obs[id]=J.obs[id]||{};J.obs[id].reflection=(f.elements.reflection.value||"").trim();J.obs[id].reflectionAt=Date.now();save();render();return}
 if(f.id==="jqForm"){e.preventDefault();const t=(document.getElementById("jq").value||"").trim();if(t){journal().qs.push({t,at:Date.now()});save();render()}}});
document.addEventListener("change",e=>{const t=e.target;if(!t.dataset||!t.dataset.jphoto||!t.files||!t.files[0]||typeof PDB==="undefined")return;const key="j:"+t.dataset.jphoto;
 shrinkPhoto(t.files[0]).then(b=>PDB.put(key,b)).then(()=>{const [,mi]=t.dataset.jphoto.split(":");const [m,i]=mi.split(".");const J=journal();J.obs[m]=J.obs[m]||{};const r=J.obs[m][i]=J.obs[m][i]||{};r.photo=true;save();jPhotoFill()}).catch(()=>{})});
