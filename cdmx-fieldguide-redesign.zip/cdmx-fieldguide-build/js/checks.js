/* Content checks across every area: every claim sourced, no broken references, no fact resting only on
   forums or blogs, journalism-only and single-source flags, staleness.
   Used by the Sources page and by scripts/check.mjs. Reads SRC, CHECKED, AD (areas) and THREADS. */
function runChecks(){
 const claims=[];const add=(where,text,src,tag)=>claims.push({where,text,src:src||[],tag:tag||"est"});
 const used=new Set(),missingIds=[];
 const ref=ids=>(ids||[]).forEach(i=>{used.add(i);if(!SRC[i])missingIds.push(i)});
 const blocks=(where,list)=>(list||[]).forEach(b=>{
  if(b.deep)blocks(where,b.deep.blocks);
  if(b.steps)b.steps.items.forEach(it=>{if(it[1]&&it[1].length)add(where,it[0],it[1],it[2]);else ref([])});
  if(b.pt){blocks(where,b.pt.blocks);(b.pt.more||[]).forEach(m=>blocks(where,m.blocks))}
  if(b.p)add(where,b.p[0],b.p[1],b.p[2]);
  if(b.prac)add(where,b.prac[0],b.prac[1],b.prac[2]||(b.prac[1].length?"est":"unk"));
  if(b.obj){add(where+": "+b.obj.name,b.obj.p[0],b.obj.p[1],b.obj.p[2]);(b.obj.look||[]).forEach(l=>add(where+": "+b.obj.name,l[0],l[1],l[2]))}
  if(b.detour)add(where,b.detour.p[0],b.detour.p[1],b.detour.p[2]);
  if(b.voices)ref(b.voices.s)});
 const pick=p=>{if(p){ref(p.forum);ref(p.blog);ref(p.vetted)}};
 const food=[];
 for(const id in AD){const a=AD[id];
  a.overview.forEach(o=>add(a.name+" overview",o[0],o[1],o[2]));
  a.walks.forEach(w=>{(w.logistics||[]).forEach(l=>add(w.name+" logistics",l[1],l[2],l[3]));(w.recap||[]).forEach(r=>add(w.name+" recap",r[0],r[1],r[2]));(w.breaks||[]).forEach(b=>{(b.notes||[]).forEach(x=>add(w.name+" break",x[0],x[1],x[2]||(x[1]&&x[1].length?"est":"unk")));if(b.voices)ref(b.voices.s)})});
  (a.tours||[]).forEach(t=>{blocks(t.name,t.blocks);blocks(t.name,t.background)});
  for(const sid in a.stops){const st=a.stops[sid];const nm=st.name||(a.sites.find(x=>x.id===st.siteRef)||{}).name||sid;
   blocks(nm,st.read);blocks(nm,st.lead);blocks(nm,st.more);(st.notice||[]).forEach(x=>add(nm+" (on the way)",x[0],x[1],x[2]));if(st.hsrc)ref([st.hsrc]);if(st.voices)ref(st.voices.s);pick(st.pick)}
  a.sites.forEach(m=>{blocks(m.name,m.read);if(m.hsrc)ref([m.hsrc]);if(m.voices)ref(m.voices.s);pick(m.pick)});
  a.food.forEach(f=>{ref(f.crit);if(f.hsrc)ref([f.hsrc]);if(f.voices)ref(f.voices.s);pick(f.pick);food.push(f)});
  (a.bookAhead||[]).forEach(b=>ref(b.s));
  (a.closures||[]).forEach(c=>ref(c.s))}
 if(typeof BASICS!=="undefined"&&BASICS){BASICS.sections.forEach(s=>s.items.forEach(i=>add("City basics: "+s.h,i[1],i[2],i[3])));if(BASICS.voices)ref(BASICS.voices.s)}
 if(typeof SEASON!=="undefined"&&SEASON){SEASON.intro.forEach(p=>add("Season",p[0],p[1],p[2]));SEASON.events.forEach(e=>{e.p.forEach(p=>add("Season: "+e.name,p[0],p[1],p[2]));if(e.eat)add("Season: "+e.name,e.eat[0],e.eat[1])});(SEASON.unknown||[]).forEach(p=>add("Season",p[0],p[1],p[2]))}
 if(typeof CTX!=="undefined")(CTX||[]).forEach(c=>c.blocks.concat(c.more||[]).forEach(b=>{if(b.p)add("Big picture: "+c.title,b.p[0],b.p[1],b.p[2]);if(b.steps)b.steps.items.forEach(i=>add("Big picture: "+c.title,i[0],i[1],i[2]))}));
 if(typeof NIGHT!=="undefined")(NIGHT||[]).forEach(x=>{x.p.forEach(p=>add("Evening: "+x.name,p[0],p[1],p[2]));if(x.ssrc)ref([x.ssrc]);if(x.hsrc)ref([x.hsrc]);if(x.voices)ref(x.voices.s);pick(x.pick)});
 if(typeof GLOSSARY!=="undefined")(GLOSSARY||[]).forEach(g=>add("Glossary: "+g.term,g.def[0],g.def[1],g.def[2]));
 if(typeof TRIPBOOK!=="undefined")(TRIPBOOK||[]).forEach(b=>ref(b.s));
 (THREADS||[]).forEach(t=>{(t.intro||[]).forEach(p=>{if(p[1]&&p[1].length)add("Thread: "+t.name,p[0],p[1],p[2])});(t.cast||[]).forEach(c=>add("Thread: "+t.name,c[0]+": "+c[1],c[2]));t.steps.forEach(s=>s.p.forEach(p=>add("Thread: "+t.name,p[0],p[1],p[2])))});
 claims.forEach(c=>ref(c.src));
 const OPINION=["Forum","Travel blog"];
 const unsourced=claims.filter(c=>!c.src.length&&c.tag!=="unk");
 const opinionOnly=claims.filter(c=>c.src.length&&c.src.every(i=>SRC[i]&&OPINION.includes(SRC[i].t)));
 const journalismOnly=claims.filter(c=>c.src.length&&c.tag==="est"&&c.src.every(i=>SRC[i]&&SRC[i].t==="Journalism"));
 const unusedSrc=Object.keys(SRC).filter(k=>!used.has(k));
 const oneSourceFood=food.filter(f=>f.crit.length<2);
 const checked=new Date(CHECKED+" 12:00");const age=Math.floor((Date.now()-checked.getTime())/864e5);
 const stdFail=[],stdThin=[];
 for(const id in AD){const a=AD[id];
  a.walks.forEach(w=>{if(!w.q)stdFail.push(w.name+": no guiding question");if(!w.effort)stdFail.push(w.name+": no effort note")});
  for(const sid in a.stops){const st=a.stops[sid];const nm=st.name||(a.sites.find(x=>x.id===st.siteRef)||{}).name||sid,L=st.lead||[];
   const pts=L.filter(b=>b.pt),look=pts.filter(b=>b.pt.look),story=pts.filter(b=>!b.pt.look);
   if(!st.what)stdFail.push(nm+": no one-line description");
   if(!st.rec)stdFail.push(nm+": no rating");
   if(!st.find||st.find.length<2)stdFail.push(nm+": fewer than two look-and-find prompts");
   if(!pts.length)stdFail.push(nm+": no points at all");if(!story.length)stdThin.push(nm+": no dated history points");
   if(!st.spot)stdThin.push(nm+": no how-to-spot-it line");
   if(pts.length<3)stdThin.push(nm+": only "+pts.length+" points");
   if(st.hours&&!L.some(b=>b.steps))stdThin.push(nm+": has opening hours but no Before you go in");}
  a.sites.forEach(m=>{if(m.link)return;if(!m.what)stdFail.push(m.name+": no one-line description");if(!m.rec)stdFail.push(m.name+": no rating")})}
 return {claims,stdFail,stdThin,total:claims.length,unsourced,opinionOnly,journalismOnly,missingIds,unusedSrc,oneSourceFood,deb:claims.filter(c=>c.tag==="deb").length,unk:claims.filter(c=>c.tag==="unk").length,age,stale:age>30};
}
