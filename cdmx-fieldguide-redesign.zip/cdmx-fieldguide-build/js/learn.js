/* Broad-to-narrow learning: big-picture context modules (core.ctx) shown at the top of each stop,
   and "Tell me more", which asks Claude to go one level deeper on any section, grounded in the guide. */
let CTX=[];
const ctxById=id=>CTX.find(c=>c.id===id);
const TM={};let TMN=0;
function tmBtn(title,blocks){const text=(blocks||[]).map(b=>b.p?b.p[0]:b.obj?b.obj.p[0]:b.take||"").filter(Boolean).join(" ");
 const k="t"+(++TMN);TM[k]={title,text,parts:[]};
 return `<div class="tm" id="tm-${k}"><div class="tmout"></div><button class="tmbtn" data-tm="${k}"><span aria-hidden="true">✦</span> Tell me more</button></div>`}
function ctxBlockHTML(id,fn){const c=ctxById(id);if(!c)return "";const open=S.mode==="read"||(S.prefs&&S.prefs.depth==="deep");
 return `<details class="ctx"${open?" open":""}><summary><span class="ctxk">Big picture · ${esc(c.era)}</span><span class="ctxh">${esc(c.title)}</span><span class="ctxone">${esc(c.one)}</span></summary>
  <div class="ptb">${c.blocks.map(b=>blockHTML(b,fn)).join("")}
  ${c.more&&c.more.length?`<details class="ptmore"${open?" open":""}><summary>More</summary>${c.more.map(b=>blockHTML(b,fn)).join("")}</details>`:""}
  ${tmBtn(c.title,c.blocks.concat(c.more||[]))}
  <button class="linkbtn ctxlink" data-ctxpage="${c.id}">Every stop connected to this →</button></div></details>`}
function ctxStops(id){const out=[];for(const aid in AD){const a=AD[aid];for(const k in a.stops){const s=a.stops[k];if((s.lead||[]).some(b=>b.ctx===id))out.push({k,s:getStop(k),a})}}return out}
function vCtx(){const c=ctxById(cur().id),fn=new Footnotes();const st=ctxStops(c.id);
 return `<section style="display:grid;gap:6px"><span class="kicker">Big picture · ${esc(c.era)}</span><h1>${esc(c.title)}</h1><p class="lede">${esc(c.one)}</p></section>
 <article class="article">${LEGEND}<span class="kicker">The short version · about ${Math.max(1,Math.round(c.blocks.reduce((n,b)=>n+((b.p&&b.p[0])||"").split(/\s+/).length,0)/200))} min</span>${c.blocks.map(b=>blockHTML(b,fn)).join("")}</article>
 ${c.more&&c.more.length?`<details class="deeper"${S.mode==="read"||(S.prefs&&S.prefs.depth==="deep")?" open":""}><summary><span class="dh">In depth</span><span class="hint">${c.more.length} more sections: the detail, the people and the turning points</span></summary><div class="article">${c.more.map(b=>blockHTML(b,fn)).join("")}</div></details>`:""}
 <div class="article">${tmBtn(c.title,c.blocks.concat(c.more||[]))}</div>${fn.html()}
 ${st.length?`<section class="filters"><span class="kicker">Where you'll see it</span>${st.map(x=>`<button class="nowitem" data-stop="${x.k}"><span class="nowname">${esc(x.s.name)}</span><span class="hint">${esc(x.a.name)}</span></button>`).join("")}</section>`:""}
 <section class="filters"><span class="kicker">The rest of the story, in order</span>${CTX.map(x=>`<button class="nowitem" data-ctxpage="${x.id}" ${x.id===c.id?'aria-current="true"':""}><span class="nowname">${esc(x.title)}</span><span class="hint">${esc(x.era)}</span></button>`).join("")}</section>`}
function tmRender(text,notes,done){const sp=splitAnswer(text);
 return `${sp.main?`<p>${citeHTML(sp.main,notes).replace(/\n\n+/g,"</p><p>")}</p>`:`<p class="hint">Thinking…</p>`}
 ${sp.beyond?`<div class="beyond"><span class="lbl">Beyond the guide · general knowledge, not from its sources</span><p>${esc(sp.beyond)}</p></div>`:""}
 ${done&&sp.follow.length?`<div class="chips">${sp.follow.map(f=>`<button class="chip followup" data-asksug="${esc(f)}">${esc(f)}</button>`).join("")}</div>`:""}`}
async function tellMore(k){const t=TM[k],box=document.getElementById("tm-"+k);if(!t||!box)return;const out=box.querySelector(".tmout"),btn=box.querySelector(".tmbtn");
 const mode=await aiMode();
 if(mode==="none"){out.insertAdjacentHTML("beforeend",`<p class="hint">${window.__ARTIFACT__?"Deeper answers from Claude aren't available in this view.":"Deeper answers need AI, which isn't set up on this phone yet: add your Anthropic API key in Ask → AI settings."} <button class="linkbtn" data-tmask="${k}">Search the guide instead</button></p>`);btn.hidden=true;return}
 btn.disabled=true;btn.innerHTML="Thinking…";
 const notes=retrieve(t.title+" "+t.text.slice(0,400)+" "+t.parts.join(" ").slice(-300),ASKCTX||null);
 const prior=t.parts.join("\n\n");
 const sys=systemFor(notes,false)+`\n\nTASK: The reader is on a walking tour of Mexico City and has just read this section, titled "${t.title}":\n"""${t.text}"""\n${prior?`They have also read these earlier expansions of it:\n"""${prior}"""\n`:""}Go one level deeper. Start with the broader background the section takes for granted, then narrow to specifics: names, dates, numbers, causes. Give only NEW information; never repeat what they've read. Explain every name and term the first time it appears. Keep the people's-history angle: who did the work, who paid, who resisted, whose account survives. Write two short paragraphs, conversational and plain, no filler. Cite notes as [n]; anything not in the notes goes in a "Beyond the guide:" paragraph per the rules above. End with FOLLOW-UPS as usual.`;
 const div=document.createElement("div");div.className="tmpart";out.appendChild(div);
 try{const text=await aiAsk([{role:"user",content:`Tell me more about "${t.title}".`}],{system:sys,onText:x=>{div.innerHTML=tmRender(x,notes,false)}});
  div.innerHTML=tmRender(text,notes,true);const sp=splitAnswer(text);t.parts.push(sp.main+(sp.beyond?"\n"+sp.beyond:""))}
 catch(e){div.innerHTML=`<p class="hint">${esc(aiErrText(e))}</p>`}
 btn.disabled=false;btn.innerHTML=`<span aria-hidden="true">✦</span> Go deeper`}
document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.tm){tellMore(d.tm);return}
 if(d.tmask){const t=TM[d.tmask];if(t)startAsk(`Tell me more about ${t.title}`,ASKCTX||null);return}
 if(d.ctxpage){nav({v:"ctx",id:d.ctxpage});return}});
