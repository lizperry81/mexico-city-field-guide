/* Saving, behind one small interface so the app never cares where state lives.

   Store.loadLocal()            -> saved state from this device, or null
   Store.save(state, onStatus)  -> saves on this device; also to the remote adapter if one connected
   Store.connectRemote(onStatus)-> tries remote adapters in order; resolves with remote state or null

   Built in:
   - Device (localStorage): always on. This is all the standalone app needs.
   - Claude account: only when the page runs inside Claude (window.claude exists).
   To add your own sync later (Supabase, Firebase, your own server), add an object to REMOTES
   with available(), connect(), save(state). */
const Store = (() => {
  const KEY = "cdmx-companion-v3";
  const clone = o => JSON.parse(JSON.stringify(o));

  const device = {
    load() { try { const r = localStorage.getItem(KEY); return r ? JSON.parse(r) : null; } catch (e) { return null; } },
    save(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {} }
  };

  const claudeAccount = {
    label: "Saved to your account",
    ref: null,
    available: () => !!(window.claude && window.claude.use),
    async connect(initial) {
      const [db, user] = await Promise.all([claude.use("db"), claude.use("user")]);
      if (!db || !user) return null;
      const id = await user.id(); if (!id) return null;
      const ref = db.collection("data/users/" + id).doc("companion-v3");
      const snap = await Promise.race([ref.get(), new Promise((_, x) => setTimeout(() => x(new Error("timeout")), 10000))]);
      this.ref = ref;
      if (snap.exists) return snap.data();
      ref.set(clone(initial || {})).catch(() => {});
      return null;
    },
    save(s) { return this.ref ? this.ref.set(clone(s)) : Promise.resolve(); }
  };

  const REMOTES = [claudeAccount];
  let remote = null, timer = null;

  return {
    loadLocal: () => device.load(),
    save(state, onStatus) {
      device.save(state);
      if (!remote) return;
      clearTimeout(timer);
      timer = setTimeout(() => remote.save(state)
        .then(() => onStatus && onStatus(remote.label))
        .catch(() => onStatus && onStatus("Saved on this device")), 600);
    },
    async connectRemote(onStatus) {
      for (const r of REMOTES) {
        try {
          if (!r.available()) continue;
          const data = await r.connect(device.load());
          remote = r;
          onStatus && onStatus(r.label);
          return data;
        } catch (e) { /* stay on device storage */ }
      }
      return null;
    }
  };
})();
