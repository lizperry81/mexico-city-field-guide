/* Phase 3: food by mood, night out, rainy-day plan, interests.
   Data: core.night (shows, music, late venues), core.ui.moods, core.ui.interests.
   Saved state: S.mood (food filter), S.rain ({on,t} manual override), S.prefs ({ints,pace,depth,done}),
   S.sig (type -> times opened) and S.sigIds (what has been counted). */
let NIGHT=[],MOODS=[],INTS=[],WX=null,EATMOOD=null;
const nightById=id=>NIGHT.find(x=>x.id===id);
const DOWN=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const ampm=h=>{const hh=Math.floor(h)%24,m=Math.round((h-Math.floor(h))*60);return `${hh%12||12}${m?":"+String(m).padStart(2,"0"):""} ${hh<12?"am":"pm"}`};

/* ----- food by mood ----- */
function moodsOf(f){const t=f.types,m=[];const barOnly=t.every(x=>x==="Bars and mezcal");
 if(f.price===1)m.push("cheap");
 if(f.price===4||t.includes("Fine dining"))m.push("special");
 if(t.some(x=>["Street food","Tacos","Markets","Cafés and sweets"].includes(x)))m.push("quick");else if(!barOnly)m.push("sit");
 return m}
function moodChips(sel,attr){return `<div class="chips">${MOODS.map(([k,l])=>`<button class="chip" aria-pressed="${sel===k}" ${attr}="${k}">${esc(l)}</button>`).join("")}</div>`}

/* ----- night out ----- */
const isEvening=n=>n.h>=18||n.h<4;
function inSeason(x,k){if(!x.seasonal)return true;const [a,b]=x.seasonal;return a<=b?(k>=a&&k<=b):(k>=a||k<=b)}
function nextShow(x,n){if(!x.sched)return null;
 for(let d=0;d<7;d++){const dow=(n.dow+d)%7;for(const s of x.sched.filter(s=>s.days.includes(dow)).sort((a,b)=>a.at-b.at)){
  if(d===0&&n.h>=s.at+s.dur)continue;
  if(d===0&&n.h>=s.at)return {s:"open",t:"On now",today:true};
  if(d===0)return {s:"open",t:`Tonight ${ampm(s.at)}`,today:true,soon:s.at-n.h<1};
  return {s:"later",t:`${d===1?"Tomorrow":DOWN[dow]} ${ampm(s.at)}`}}}
 return null}
function nightStatus(x,n){if(x.outdoor)return {s:"open",t:"Open-air"};
 if(x.hours){const late=x.hours.late&&x.hours.late.days.includes(n.dow);return placeStatus({hours:{days:x.hours.days,h:late?x.hours.late.h:x.hours.h}},n)}
 return nextShow(x,n)||{s:"unk",t:x.seasonal?"Dates not announced":"Schedule not confirmed"}}
function schedText(x){return x.sched.map(s=>`${s.days.map(d=>DOWN[d]).join(" and ")} at ${ampm(s.at)}`).join("; ")}
function hoursTextN(x){const h=x.hours;const f=r=>r.map(([a,b])=>`${fmtH(a)}–${fmtH(b)}`).join(", ");return h.late?`${f(h.h)}; ${h.late.days.map(d=>DOWN[d]).join(", ")} ${f(h.late.h)}`:f(h.h)}
function lateFood(f){return f.hours&&f.hours.some(([a,b])=>b>=23)}
function nightOut(c){const n=c.n,k=mxDateKey().slice(5),sub=t=>`<span class="kicker" style="margin-top:6px">${t}</span>`;
 const shows=NIGHT.filter(x=>x.kind==="Show"&&inSeason(x,k)).map(x=>({x,st:nightStatus(x,n)})).sort((a,b)=>(b.st.today?1:0)-(a.st.today?1:0));
 const venues=NIGHT.filter(x=>x.kind!=="Show").map(x=>({x,st:nightStatus(x,n)}));
 const bars=foodAll(c).filter(x=>x.f.types.includes("Bars and mezcal")).sort(foodSort(c));
 const late=foodAll(c).filter(x=>!x.f.types.every(t=>t==="Bars and mezcal")&&lateFood(x.f)&&x.st.s!=="closed");
 const nrow=({x,st})=>row(`data-night="${x.id}"`,esc(x.name),`${statusPill(st)}<span class="hint">${esc(x.where)}</span>`,esc(x.summary));
 const frow=x=>row(`data-eatarea="${x.area}"`,esc(x.f.name),`${statusPill(x.st)}<span class="price">${PRICES[x.f.price-1]}</span>${c.areaId&&x.area===c.areaId?"":`<span class="hint">${esc(AD[x.area].name)}</span>`}`,esc(x.f.order.split(";")[0].split(". ")[0]));
 const late10=n.h>=21.5||n.h<5;
 return `<p class="hint">${late10?"It's late. ":""}The tourism office advises against walking after 10 p.m. and through quiet streets you don't know: go by taxi or app ride. ${srcTag(["cdmxsafety"])}</p>`
  +sub("Shows")+shows.map(nrow).join("")
  +sub("Music and mezcal")+venues.map(nrow).join("")
  +sub("Bars and cantinas")+bars.map(frow).join("")
  +(late.length?sub("Food late")+late.map(frow).join(""):"")}
function vNight(){const x=nightById(cur().id),n=mxNow(),st=nightStatus(x,n),fn=new Footnotes();
 const map=`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(x.name+" "+x.addr+" Ciudad de México")}`;
 return `<section style="display:grid;gap:6px"><span class="kicker">${esc(x.kind)} · ${esc(x.where)}</span><h1>${esc(x.name)}</h1><p class="lede">${esc(x.summary)}</p>${starsHTML(x.ta)}</section>
 <div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn small primary" href="${dirURL(x)}" target="_blank" rel="noopener">Directions ↗</a><button class="btn small" data-askabout="${x.id}">Ask about this</button></div>
 <section class="filters"><div class="meta">${statusPill(st)}</div>
  ${x.sched?`<p><strong>When:</strong> ${esc(schedText(x))} ${srcTag([x.ssrc])}</p>`:""}
  ${x.hours?`<p><strong>Hours:</strong> ${esc(hoursTextN(x))} ${srcTag([x.hsrc])}</p>`:""}
  <p><strong>Cost:</strong> ${esc(x.cost)}</p>${x.book?`<p><strong>Tickets:</strong> ${esc(x.book)}</p>`:""}
  <p><strong>Address:</strong> ${esc(x.addr)}${x.approx?" (map pin approximate)":""} · <a href="${map}" target="_blank" rel="noopener">Map ↗</a></p>
  <p class="hint">Holiday dates, especially Dec 24–25 and Dec 31–Jan 1, may differ. Check before you go.</p></section>
 <article class="article">${LEGEND}${x.p.map(p=>blockHTML({p},fn)).join("")}${x.voices?voicesHTML(x.voices):""}${x.pick?pickHTML(x.pick):""}</article>${fn.html()}`}

/* ----- rain ----- */
function rainy(){if(S.rain&&Date.now()-(S.rain.t||0)<6*3600e3)return !!S.rain.on;return !!(WX&&WX.wet&&Date.now()-WX.t<2*3600e3)}
const WETCODES=[51,53,55,56,57,61,63,65,66,67,80,81,82,95,96,99];
let WXBUSY=false;
async function fetchWx(){if(window.__ARTIFACT__||WXBUSY||(WX&&Date.now()-WX.t<30*60e3))return;WXBUSY=true;
 try{const r=await fetch("https://api.open-meteo.com/v1/forecast?latitude=19.43&longitude=-99.13&current=precipitation,weather_code&timezone=America%2FMexico_City");
  const j=await r.json(),cu=j.current||{};const was=rainy();WX={wet:(cu.precipitation||0)>0.1||WETCODES.includes(cu.weather_code),p:cu.precipitation,t:Date.now()};if(rainy()!==was)refreshNow()}catch(e){}
 WXBUSY=false}
function rainPlan(c){const pl=placesNow(c).filter(p=>p.st.s==="open"&&!p.outdoor).sort((a,b)=>byNear(c)(a,b)-0.6*(intScore(a.types)-intScore(b.types))).slice(0,5);
 return `<div class="raincard"><b>☔ Rainy-day plan</b><span class="hint">The walks are mostly outdoors. Indoors and open now${c.here?", nearest first":""}:</span>${pl.length?pl.map(p=>row(p.open,esc(p.name),`${statusPill(p.st)}<span class="hint">${where(p,c)}</span>`)).join(""):`<p class="hint">Nothing indoors is open right now. Try Eat.</p>`}</div>`}
const _placesNow=placesNow;
placesNow=function(c){const r=_placesNow(c);return rainy()?r.filter(p=>!p.outdoor):r};

/* ----- interests ----- */
function intScore(types){const P=S.prefs||{},sig=S.sig||{};let s=0;
 (types||[]).forEach(t=>{if(INTS.some(([k,,ts])=>(P.ints||[]).includes(k)&&ts.includes(t)))s+=2;s+=Math.min(1.5,(sig[t]||0)*0.3)});return s}
function learn(types,id){if(!id||!types||!types.length||(S.sigIds||[]).includes(id))return;S.sigIds=(S.sigIds||[]).concat(id).slice(-200);S.sig=S.sig||{};types.forEach(t=>S.sig[t]=(S.sig[t]||0)+1);save()}
function learnCur(){const c=cur();let types=null,id=null;
 if(c.v==="more"){const x=siteById(c.id);if(x){types=x.types;id=x.id}}
 else if(c.v==="stop"){const st=getStop(c.id);if(st){types=st.types||(siteById(st.siteRef)||{}).types;id=c.id}}
 if(types)learn(types,id)}
const PACES=[["easy","Easy"],["normal","Normal"],["full","Pack it in"]],DEPTHS=[["short","Short"],["medium","Medium"],["deep","Deep dives"]];
function prefsHTML(inline){const P=S.prefs||{ints:[],pace:"normal",depth:"medium"};
 const ch=(list,key,sel)=>list.map(([k,l])=>`<button class="chip" aria-pressed="${sel(k)}" data-pref="${key}:${k}">${esc(l)}</button>`).join("");
 const learned=Object.entries(S.sig||{}).sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>x[0]);
 return `<section class="filters prefcard">${inline?`<span class="kicker">Make it yours</span><h2 style="font-size:19px">What are you into?</h2><p class="hint">Pick any. Places you'd like come first, and the guide also learns from what you open.</p>`:`<span class="kicker">Your interests</span><p class="hint">Places you'd like come first, and Ask the guide tailors its answers.${learned.length?` Learned from what you open: ${esc(learned.join(", "))}.`:""}</p>`}
  <div class="chips">${ch(INTS,"ints",k=>(P.ints||[]).includes(k))}</div>
  <div class="frow"><span class="kicker">Pace</span><div class="chips">${ch(PACES,"pace",k=>P.pace===k)}</div></div>
  <div class="frow"><span class="kicker">Answers</span><div class="chips">${ch(DEPTHS,"depth",k=>P.depth===k)}</div></div>
  ${inline?`<div style="display:flex;gap:8px"><button class="btn small primary" data-pdone>Done</button><button class="btn small" data-pdone>Not now</button></div>`:""}</section>`}
function prefLine(){const P=S.prefs;if(!P)return "";const ints=INTS.filter(([k])=>(P.ints||[]).includes(k)).map(x=>x[1]);
 const learned=Object.entries(S.sig||{}).sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>x[0]);
 const len={short:"Keep the answer to 1 or 2 sentences.",deep:"They like depth: up to 6 sentences, with names, dates and what to look for. This overrides the length above."}[P.depth]||"";
 return `\n\nTRAVELER: ${ints.length?`Interested in ${ints.join(", ")}.`:""}${learned.length?` Has been opening ${learned.join(", ")}.`:""} Pace: ${P.pace||"normal"}. ${len} Where it fits, connect the answer to these interests and suggest follow-ups that match them.`}
const _visitMins=visitMins;
visitMins=function(p){return Math.round(_visitMins(p)*({easy:1.3,full:0.8}[(S.prefs||{}).pace]||1))};
const _systemFor=systemFor;
systemFor=function(notes,img){return _systemFor(notes,img)+prefLine()};
const _vTrip=vTrip;
vTrip=function(){return _vTrip()+prefsHTML(false)};
function afterRender(){const v=cur().v;if(v==="areas")fetchWx();learnCur()}

document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.night){nav({v:"night",id:d.night});return}
 if(d.eatmood){EATMOOD=EATMOOD===d.eatmood?null:d.eatmood;refreshNow();return}
 if(b.hasAttribute("data-rain")){S.rain={on:!rainy(),t:Date.now()};save();refreshNow();return}
 if(d.pref){const [k,v]=d.pref.split(":");S.prefs=S.prefs||{ints:[],pace:"normal",depth:"medium"};
  if(k==="ints"){const a=S.prefs.ints,i=a.indexOf(v);i>=0?a.splice(i,1):a.push(v)}else S.prefs[k]=v;save();
  if(cur().v==="areas")refreshNow();else render();return}
 if(b.hasAttribute("data-pdone")){S.prefs=S.prefs||{ints:[],pace:"normal",depth:"medium"};S.prefs.done=true;save();refreshNow();return}});
