/* AI connection.
   Inside Claude: uses Claude through the page's "sample" capability (no key needed).
   Phone app / website: uses the traveler's own Anthropic API key, stored only on this device
   (localStorage, never in the site files, never in the progress backup or sync), and calls the
   Anthropic Messages API directly from the browser. */
const AIKEY="cdmx-ai-key",AIMODEL="cdmx-ai-model";
const AI_MODELS=[["claude-sonnet-5-5","Best answers (Sonnet)"],["claude-haiku-5-5","Faster and cheaper (Haiku)"]];
function aiGet(k){try{return localStorage.getItem(k)||""}catch(e){return ""}}
function aiSet(k,v){try{v?localStorage.setItem(k,v):localStorage.removeItem(k);return true}catch(e){return false}}
const aiKey=()=>aiGet(AIKEY),aiModel=()=>aiGet(AIMODEL)||AI_MODELS[0][0];
let AISAMPLER;
async function aiSampler(){if(AISAMPLER!==undefined)return AISAMPLER;try{AISAMPLER=window.claude&&window.claude.use?await window.claude.use("sample"):null}catch(e){AISAMPLER=null}return AISAMPLER}
async function aiMode(){if(window.__ARTIFACT__){return (await aiSampler())?"claude":"none"}return aiKey()?"key":"none"}

/* Shrink a photo to a JPEG under ~1280 px so it uploads fast. Returns {blob, b64}. */
function aiPrepImage(file){return new Promise((res,rej)=>{const img=new Image(),url=URL.createObjectURL(file);
 img.onload=()=>{const m=1280,sc=Math.min(1,m/Math.max(img.width,img.height)),c=document.createElement("canvas");c.width=Math.round(img.width*sc);c.height=Math.round(img.height*sc);
  c.getContext("2d").drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(url);
  c.toBlob(b=>{if(!b)return rej(new Error("image"));const r=new FileReader();r.onload=()=>res({blob:b,b64:String(r.result).split(",")[1],url:String(r.result)});r.readAsDataURL(b)},"image/jpeg",.82)};
 img.onerror=()=>rej(new Error("image"));img.src=url})}

/* messages: [{role:"user"|"assistant", content:string}], last one is the user's.
   opts: {system, image:{blob,b64}, onText(text), signal}. Resolves to the full text. */
async function aiAsk(messages,opts){opts=opts||{};
 if(window.__ARTIFACT__){const s=await aiSampler();if(!s)throw {code:"no_ai"};
  const input=[{role:"user",content:(opts.system?opts.system+"\n\n---\n\n":"")+messages[0].content}].concat(messages.slice(1));
  const o={signal:opts.signal,onText:({text})=>opts.onText&&opts.onText(text)};
  if(opts.image){let ok=false;try{const l=await s.limits();ok=!!(l&&l.images)}catch(e){}if(!ok)throw {code:"no_images"};o.images=[opts.image.blob]}
  const r=await s(input,o);return r.text}
 const key=aiKey();if(!key)throw {code:"no_key"};
 const msgs=messages.map((m,i)=>i===messages.length-1&&opts.image?{role:"user",content:[{type:"image",source:{type:"base64",media_type:"image/jpeg",data:opts.image.b64}},{type:"text",text:m.content}]}:m);
 let res;
 try{res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",signal:opts.signal,headers:{"content-type":"application/json","x-api-key":key,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},
  body:JSON.stringify({model:aiModel(),max_tokens:900,system:opts.system||undefined,messages:msgs,stream:true})})}
 catch(e){if(e&&e.name==="AbortError")throw {code:"cancelled"};throw {code:"network"}}
 if(!res.ok){let msg="";try{const j=await res.json();msg=j.error&&j.error.message||""}catch(e){}throw {code:res.status===401?"bad_key":res.status===429?"rate_limited":res.status===400&&/credit/i.test(msg)?"no_credit":"api",message:msg}}
 const reader=res.body.getReader(),dec=new TextDecoder();let buf="",text="";
 try{while(true){const {done,value}=await reader.read();if(done)break;buf+=dec.decode(value,{stream:true});
  let i;while((i=buf.indexOf("\n"))>=0){const line=buf.slice(0,i).trim();buf=buf.slice(i+1);if(!line.startsWith("data:"))continue;
   try{const ev=JSON.parse(line.slice(5));if(ev.type==="content_block_delta"&&ev.delta&&ev.delta.text){text+=ev.delta.text;opts.onText&&opts.onText(text)}if(ev.type==="error")throw {code:"api",message:ev.error&&ev.error.message}}catch(e){if(e&&e.code)throw e}}}}
 catch(e){if(e&&e.name==="AbortError")throw {code:"cancelled",text};throw e}
 return text}
const AIERR={no_key:"AI answers aren't set up on this device yet. Add your Anthropic API key in AI settings.",bad_key:"The API key was rejected. Check it in AI settings.",no_credit:"Your Anthropic account is out of credit. Add credit in the Anthropic Console.",rate_limited:"Too many questions at once. Wait a minute and try again.",network:"No connection right now. Here are the best matches in the guide instead.",cancelled:"Stopped.",no_images:"Photo questions aren't available here.",not_granted:"Claude answers aren't allowed for this page, so here are the best matches in the guide.",no_ai:"AI answers aren't available here."};
const aiErrText=e=>AIERR[e&&e.code]||"The answer couldn't be completed. Here are the best matches in the guide.";

/* ----- settings panel (phone app only) ----- */
function aiSettingsHTML(){
 if(window.__ARTIFACT__)return `<section class="filters"><span class="kicker">AI answers</span><p class="hint">Inside Claude, answers come from Claude; nothing to set up. The first question asks you to allow it, and answers use your Claude usage.</p></section>`;
 const has=!!aiKey();
 return `<section class="filters" id="aiset"><span class="kicker">AI answers on this device</span>
  <p class="hint">${has?"On. Answers use your Anthropic API key.":"Off. Add your Anthropic API key to get written answers, follow-up questions and photo questions."} The key is stored only on this phone: it isn't in the website, the backup code or anything you share. Anyone using this phone could use it.</p>
  ${has?`<p class="hint">Key ending in <strong>${esc(aiKey().slice(-4))}</strong>.</p>`:`<details class="legend"><summary>How to get a key (about 10 minutes)</summary><p class="hint" style="line-height:1.7">1. Sign up at console.anthropic.com.<br>2. Add a small amount of credit under Billing (a few dollars covers a trip of questions; photos cost more).<br>3. Under API keys, create a key and copy it.<br>4. Paste it below and tap Save.</p></details>`}
  <input id="aikey" type="password" autocomplete="off" placeholder="${has?"Paste a new key to replace it":"sk-ant-…"}" style="font:inherit;color:var(--ink);background:var(--tint);border:0;border-radius:12px;padding:12px 14px">
  <label class="hint" for="aimodel">Model</label><select id="aimodel" style="font:inherit;color:var(--ink);background:var(--tint);border:0;border-radius:12px;padding:10px 12px">${AI_MODELS.map(([v,l])=>`<option value="${v}" ${aiModel()===v?"selected":""}>${esc(l)}</option>`).join("")}</select>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn small primary" data-aisave>Save</button><button class="btn small" data-aitest ${has?"":"disabled"}>Test</button>${has?`<button class="btn small" data-airemove>Remove key</button>`:""}</div>
  <p class="hint" id="aimsg" aria-live="polite"></p></section>`}
document.addEventListener("click",async e=>{const b=e.target.closest("button");if(!b)return;const m=document.getElementById("aimsg");
 if(b.hasAttribute("data-aisave")){const k=(document.getElementById("aikey").value||"").trim(),mo=document.getElementById("aimodel").value;aiSet(AIMODEL,mo);
  if(k){if(!/^sk-ant-/.test(k)){m.textContent="That doesn't look like an Anthropic key (they start with sk-ant-).";return}aiSet(AIKEY,k)}
  render();setTimeout(()=>{const x=document.getElementById("aimsg");if(x)x.textContent="Saved."},0);return}
 if(b.hasAttribute("data-airemove")){aiSet(AIKEY,"");render();return}
 if(b.hasAttribute("data-aitest")){m.textContent="Testing…";try{const t=await aiAsk([{role:"user",content:"Reply with the single word: ready"}],{});m.textContent=/ready/i.test(t)?"Working. AI answers are on.":"Connected, but the reply was unexpected: "+t.slice(0,60)}catch(err){m.textContent=aiErrText(err)}return}});
