/* Mexico City Field Guide: app logic (rendering, routing, filters, events).
   Content lives in data/*.json (core.json plus one file per area); drawings in js/art.js;
   saving in js/storage.js; content checks in js/checks.js. */
let SRC,CHECKED,AREAS,AD={},THREADS=[],STYPES,TYPES,PRICES,MEALS;
let STOPIDX={},SITEIDX={},WALKIDX={},TOURIDX={},AR=null;
const tourById=id=>{const a=AD[TOURIDX[id]];return a?(a.tours||[]).find(t=>t.id===id):null};

/* ===================== STATE ===================== */
const DEF={community:[],editorial:{},claimQ:"",tsort:"sig",journal:{},askMode:"story",askLen:"walk",pmode:"story",timeI:0,walkMap:false,walkOn:null,mood:[],rain:null,prefs:null,sig:{},sigIds:[],mode:"read",forks:{},route:{},price:[],types:[],meals:[],open:false,stypes:[],sopen:false,start:"2026-12-31",end:"2027-01-07",itin:{},book:[],visited:[],last:"",here:null,wstart:{},hotel:"",found:{},plan:{},build:{}};
let S=JSON.parse(JSON.stringify(DEF)),stack=[{v:"home"}],areaTab="see",syncText="Saved on this device";
function merge(d){const s=JSON.parse(JSON.stringify(DEF));if(d)for(const k in s)if(d[k]!==undefined&&d[k]!==null)s[k]=JSON.parse(JSON.stringify(d[k]));return s}
function save(){Store.save(S,setSync)}
function setSync(x){syncText=x;const el=document.getElementById("syncl");if(el){el.textContent=x;el.classList.add("flash");clearTimeout(window.__syncT);window.__syncT=setTimeout(()=>el.classList.remove("flash"),2500)}}
document.documentElement.lang="en";
async function connect(){const d=await Store.connectRemote(setSync);if(!d)return;S=merge(d);migrateTrip();const here=(location.hash||"").replace(/^#/,"")||"home";if(here==="home"&&S.last&&S.last!=="home"){try{location.hash=S.last}catch(e){}}else render()}

/* ===================== HELPERS ===================== */
const $=s=>document.querySelector(s);
const esc=x=>String(x).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const norm=x=>x.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"");
const cur=()=>stack[stack.length-1];
const areaMeta=id=>AREAS.find(a=>a.id===id)||{};
const walkById=id=>{const a=AD[WALKIDX[id]];return a?a.walks.find(w=>w.id===id):null};
const siteById=id=>{const a=AD[SITEIDX[id]];return a?a.sites.find(s=>s.id===id):null};
function getStop(id){const a=AD[STOPIDX[id]];if(!a)return null;const st=a.stops[id];if(!st.siteRef)return st;
 const s=a.sites.find(x=>x.id===st.siteRef)||{};
 return Object.assign({},s,st,{name:st.name||s.name,summary:st.summary||s.summary,read:st.read||s.read||[],cat:st.cat||s.cat,photos:st.photos||s.photos,voices:st.voices||s.voices,pick:st.pick||s.pick})}
const stopArt=(id,st)=>ILL[id]||ILLCAT[st.cat]||ILLCAT.museum;
function useArea(id){if(AD[id])AR=AD[id]}

function hashFor(v){if(!v)return "home";
 if(v.v==="home")return "home";
 if(v.v==="areas")return "around";
 if(v.v==="story")return "story-"+v.id;
 if(v.v==="question")return "q-"+v.id;
 if(v.v==="museum")return "museum-"+v.id;
 if(v.v==="mission")return "mission-"+v.id;
 if(v.v==="explore")return "explore";
 if(v.v==="learn")return "learn";
 if(v.v==="area")return v.a+(areaTab==="more"?"-more":areaTab==="eat"?"-eat":"");
 if(v.v==="walk")return "walk-"+v.w+"-"+((v.i||0)+1);
 if(v.v==="stop")return "stop-"+v.id;
 if(v.v==="more")return "site-"+v.id;
 if(v.v==="thread")return "thread-"+v.id;
 if(v.v==="day")return "day-"+v.id;
 if(v.v==="itin")return "itinerary";
 if(v.v==="itday")return "itday-"+v.iso;
 if(v.v==="tour")return "tour-"+v.id;
 if(v.v==="night")return "night-"+v.id;
 if(v.v==="walkstart")return "start-"+v.w;
 if(v.v==="ctx")return "ctx-"+v.id;
 return v.v}
function routeTo(h){h=(h||"").replace(/^#/,"");
 const A={v:"areas"},E={v:"explore"},LN={v:"learn"},H={v:"home"},F={v:"field"},J={v:"journal"};let m;
 if(!h||h==="home")return [H];
 if(h==="around")return [A];
 if(h==="field")return [F];
 if(h==="journal")return [J];
 if(h==="near")return [F,{v:"near"}];
 if(h==="museums")return [F,{v:"museums"}];
 if(h==="time")return [H,{v:"time"}];
 if(h==="eras")return [H,LN];
 if((m=h.match(/^story-([a-z0-9]+)$/))&&storyById(m[1]))return [H,{v:"story",id:m[1]}];
 if((m=h.match(/^q-([a-z0-9]+)$/))&&questionById(m[1]))return [H,{v:"question",id:m[1]}];
 if((m=h.match(/^museum-([a-z0-9]+)$/))&&MUSEUMS.find(x=>x.id===m[1]))return [F,{v:"museums"},{v:"museum",id:m[1]}];
 if((m=h.match(/^mission-([a-z0-9]+)$/))&&MISSIONS.find(x=>x.id===m[1]))return [F,{v:"mission",id:m[1]}];
 if(h==="explore")return [E];
 if(h==="learn")return [H,LN];
 if(h==="sources")return [{v:"trip"},{v:"sources"}];
 if(h==="howknow")return [{v:"trip"},{v:"sources"},{v:"howknow"}];
 if(h==="editorial")return [{v:"trip"},{v:"sources"},{v:"editorial"}];
 if(h==="search")return [A,{v:"search"}];
 if(h==="threads")return [LN,{v:"threads"}];
 if(h==="trip")return [{v:"trip"}];
 if(h==="itinerary")return [{v:"trip"},{v:"itin"}];
 if(m=h.match(/^itday-(\d{4}-\d{2}-\d{2})$/))return [{v:"trip"},{v:"itin"},{v:"itday",iso:m[1]}];
 if(h==="build")return [{v:"trip"},{v:"build"}];
 if(h==="ask")return [H,{v:"ask"}];
 if(h==="glossary")return [H,LN,{v:"glossary"}];
 if(h==="season"||h==="basics")return [{v:"trip"},{v:h}];
 if((m=h.match(/^day-([a-z-]+)$/))&&DAYS.find(d=>d.id===m[1]))return [{v:"trip"},{v:"day",id:m[1]}];
 if((m=h.match(/^ctx-([a-z0-9]+)$/))&&ctxById(m[1]))return [H,LN,{v:"ctx",id:m[1]}];
 if((m=h.match(/^start-([a-z]+)$/))&&WALKIDX[m[1]]){const a=WALKIDX[m[1]];useArea(a);areaTab="see";return [E,{v:"area",a},{v:"walkstart",w:m[1]}]}
 if((m=h.match(/^night-([a-z]+)$/))&&nightById(m[1]))return [A,{v:"night",id:m[1]}];
 if((m=h.match(/^thread-([a-z-]+)$/))&&THREADS.find(t=>t.id===m[1]))return [H,{v:"thread",id:m[1]}];
 if((m=h.match(/^([a-z]+)(?:-(more|eat))?$/))&&AD[m[1]]){useArea(m[1]);areaTab=m[2]||"see";return [E,{v:"area",a:m[1]}]}
 if(m=h.match(/^walk-(\d+)$/)){const w=AD.centro.walks[0];return routeTo("walk-"+w.id+"-"+m[1])}
 if((m=h.match(/^walk-([a-z]+)-(\d+)$/))&&WALKIDX[m[1]]){const a=WALKIDX[m[1]],w=walkById(m[1]);useArea(a);areaTab="see";return [E,{v:"area",a},{v:"walk",w:m[1],i:Math.max(0,Math.min(+m[2]-1,walkStops(w).length-1))}]}
 if((m=h.match(/^stop-([a-z-]+)$/))&&STOPIDX[m[1]]){const a=STOPIDX[m[1]];useArea(a);areaTab="see";return [E,{v:"area",a},{v:"stop",id:m[1]}]}
 if((m=h.match(/^tour-([a-z-]+)$/))&&TOURIDX[m[1]]){const a=TOURIDX[m[1]],t=tourById(m[1]);useArea(a);areaTab="see";return [E,{v:"area",a},{v:"stop",id:t.stop},{v:"tour",id:m[1]}]}
 if((m=h.match(/^site-([a-z-]+)$/))&&SITEIDX[m[1]]){const a=SITEIDX[m[1]];useArea(a);areaTab="more";return [E,{v:"area",a},{v:"more",id:m[1]}]}
 return [H]}
let lastHash=null;
function applyHash(){const h=(location.hash||"").replace(/^#/,"")||"home";if(h===lastHash)return;lastHash=h;stack=routeTo(h);if(S.last!==h){S.last=h;save()}render();window.scrollTo(0,0)}
function nav(v){const h=hashFor(v);if((location.hash||"").replace(/^#/,"")===h){lastHash=null;applyHash()}else{try{location.hash=h}catch(e){stack=routeTo(h);render()}}}
function back(){if(stack.length>1)nav(stack[stack.length-2])}
const walkStops=w=>{const b=w.stops.filter(s=>!(w.optional||[]).includes(s)||S.route[s]===true);const j=(S.wstart&&S.wstart[w.id])||0;return j>0&&j<b.length?b.slice(j).concat(b.slice(0,j)):b};

function Footnotes(){this.list=[]}
Footnotes.prototype.mark=function(ids){return (ids||[]).map(i=>{if(!SRC[i])return "";let n=this.list.indexOf(i);if(n<0){this.list.push(i);n=this.list.length-1}return `<sup class="fn"><a href="${SRC[i].u}" target="_blank" rel="noopener" title="${esc(SRC[i].n)}">${n+1}</a></sup>`}).join("")};
Footnotes.prototype.html=function(){if(!this.list.length)return"";return `<div class="notes"><span class="kicker">Sources</span><ol>${this.list.map(i=>`<li><a href="${SRC[i].u}" target="_blank" rel="noopener">${esc(SRC[i].n)}</a> <span class="tier">${typeof tierOf==="function"?esc(tierOf(i).short):""}</span></li>`).join("")}</ol><p class="hint"><button class="linkbtn" data-go="howknow:">How the guide grades its sources and claims</button></p></div>`};
const TAGS={est:["Well established","Our cited sources agree, and at least one is institutional or scholarly"],rep:["Reported","Rests on journalism or critics only; not yet corroborated by an institutional or scholarly source"],deb:["Scholarly debate","Credible sources disagree or offer competing interpretations"],unk:["Uncertain","The available evidence doesn't settle it"],trad:["Traditional account","Preserved through tradition, legend or community memory; not established as historical fact"],comm:["Community report","One traveler's experience, not verified"]};
const tagHTML=(g,src)=>{let k=g||"est";if(k==="est"&&src&&src.length&&typeof evidenceStrong==="function"&&!evidenceStrong(src))k="rep";if(!TAGS[k])k="est";return `<span class="tag ${k}" title="${TAGS[k][1]}">${TAGS[k][0]}</span>`};
const LEGEND=`<details class="legend"><summary>How claims are tagged</summary><p class="hint"><span class="tag est">Well established</span> cited sources agree and at least one is institutional or scholarly. <span class="tag rep">Reported</span> journalism or critics only. <span class="tag deb">Scholarly debate</span> credible sources disagree. <span class="tag unk">Uncertain</span> the evidence doesn't settle it. <span class="tag trad">Traditional account</span> tradition or legend, not established fact. "What visitors say" and community reports are individual experiences and aren't tagged. <button class="linkbtn" data-go="howknow:">More on how the guide knows</button></p></details>`;
const srcTag=ids=>(ids||[]).filter(i=>SRC[i]).map(i=>`<a class="src" href="${SRC[i].u}" target="_blank" rel="noopener" title="${esc(SRC[i].n)}">${esc(SRC[i].n.split(",")[0])}</a>`).join("");
function starsHTML(ta,full){if(!ta)return full?`<span class="stars none">No Tripadvisor rating</span>`:"";const [r,n,of]=ta;
 return `<span class="stars" title="Tripadvisor, ${r} of 5 from ${n.toLocaleString("en-US")} reviews${of?" ("+of+")":""}, checked Nov 2026"><span class="st" style="--r:${r}" aria-hidden="true">★★★★★</span><b>${r.toFixed(1)}</b><span class="hint">on Tripadvisor · ${n.toLocaleString("en-US")} reviews${of&&full?" · "+esc(of):""}</span></span>`}
function pickHTML(p,compact){if(!p)return "";const row=[["forum","Forums"],["blog","Travel blogs"],["vetted","Critics or official"]];
 if(compact)return `<span class="meta">${row.map(([k,l])=>`<span class="pill ${p[k]&&p[k].length?"ok":""}" title="${esc(l)}">${p[k]&&p[k].length?"✓":"–"} ${l}</span>`).join("")}</span>`;
 return `<div class="callout prac"><span class="lbl">Why it's in the guide</span><span class="meta">${row.map(([k,l])=>`<span class="pill ${p[k]&&p[k].length?"ok":""}">${p[k]&&p[k].length?"✓":"–"} ${l}</span>`).join("")}</span><span class="hint">${row.filter(([k])=>p[k]&&p[k].length).map(([k])=>srcTag(p[k])).join(" ")}</span></div>`}
function voicesHTML(v){if(!v)return "";return `<div class="callout voices"><span class="lbl">What visitors say</span><ul>${v.pts.map(t=>`<li>${esc(t)}</li>`).join("")}</ul><span class="hint">Opinions from forums and travel blogs, not checked facts. ${srcTag(v.s)}</span></div>`}
function threadChips(id){const ts=THREADS.filter(t=>t.steps.some(s=>s.ref===id));if(!ts.length)return "";return `<div class="chips"><span class="hint" style="align-self:center">Part of:</span>${ts.map(t=>`<button class="chip" data-thread="${t.id}">${esc(t.name)} →</button>`).join("")}</div>`}

function mapSVG(w,hl,small){
 const M=w.map,stops=walkStops(w),pts=stops.map(s=>M.pos[s]);
 const label=(x,y,t,a)=>`<text x="${x}" y="${y}" font-size="11" font-family="Figtree,sans-serif" fill="var(--muted)" text-anchor="${a||"start"}">${esc(t)}</text>`;
 return `<svg viewBox="0 0 560 250" role="img" aria-label="Schematic map of the walk ${esc(w.name)}"><rect width="560" height="250" fill="var(--soft)"/>
 ${M.shapes.map(r=>r[0]==="c"?`<circle cx="${r[1]}" cy="${r[2]}" r="${r[3]}" fill="var(--${r[4]})" opacity="${r[5]||1}"/>`:r[0]==="p"?`<path d="${r[1]}" fill="${r[2]?`var(--${r[2]})`:"none"}" stroke="var(--${r[3]||"paper"})" stroke-width="${r[4]||10}" opacity="${r[5]||1}"/>`:`<rect x="${r[0]}" y="${r[1]}" width="${r[2]}" height="${r[3]}" fill="var(--${r[4]||"paper"})" opacity="${r[5]||1}" ${r[6]?`stroke="var(--rule)"`:""}/>`).join("")}
 ${M.labels.map(l=>label(...l)).join("")}
 ${small?"":label(6,14,"Schematic, not to scale")}
 <path d="M${pts.map(p=>p.join(" ")).join(" L")}" fill="none" stroke="var(--accent)" stroke-width="3" stroke-dasharray="7 5" stroke-linecap="round"/>
 ${stops.map((s,i)=>{const [x,y]=M.pos[s],on=s===hl;return `<circle cx="${x}" cy="${y}" r="${on?14:11}" fill="${on?"var(--accent)":"var(--paper)"}" stroke="var(--accent)" stroke-width="2"/><text x="${x}" y="${y+4.5}" text-anchor="middle" font-size="12" font-weight="700" font-family="Figtree,sans-serif" fill="${on?"var(--paper)":"var(--accent)"}">${i+1}</text>`}).join("")}</svg>`}

/* hours */
function mxNow(){try{const p=new Intl.DateTimeFormat("en-US",{timeZone:"America/Mexico_City",hour:"numeric",minute:"numeric",weekday:"short",hourCycle:"h23"}).formatToParts(new Date());const h=+p.find(x=>x.type==="hour").value,m=+p.find(x=>x.type==="minute").value,wd=p.find(x=>x.type==="weekday").value;return {h:h+m/60,dow:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].indexOf(wd),label:`${wd} ${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`}}catch(e){const d=new Date();return {h:d.getHours()+d.getMinutes()/60,dow:d.getDay(),label:"local time"}}}
const siteOpen=(x,n)=>{if(!x.hours)return null;if(!x.hours.days.includes(n.dow))return false;const r=(n.dow===0&&x.hours.sun)||(n.dow===6&&x.hours.sat)||x.hours.h;return r.some(([a,b])=>n.h>=a&&n.h<b)};
const DAYN=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const fmtH=x=>{const h=Math.floor(x),m=Math.round((x-h)*60);return `${String(h%24).padStart(2,"0")}:${String(m).padStart(2,"0")}`};
const fr=r=>r.map(([a,b])=>`${fmtH(a)}–${fmtH(b)}`).join(", ");
function dayRange(days){if(days.length===7)return "Daily";const s=[...days].sort((a,b)=>((a+6)%7)-((b+6)%7));if(days.length===6&&!days.includes(1))return "Tue–Sun";if(days.length===6&&!days.includes(0))return "Mon–Sat";if(days.length===5&&!days.includes(0)&&!days.includes(6))return "Mon–Fri";return s.map(i=>DAYN[i]).join(", ")}
const siteHours=x=>{if(!x.hours)return "Hours not published";if(x.hoursLabel)return x.hoursLabel;const missing=[0,1,2,3,4,5,6].filter(d=>!x.hours.days.includes(d)).map(d=>DAYN[d]);return `${dayRange(x.hours.days)} ${fr(x.hours.h)}${x.hours.sat?` · Sat ${fr(x.hours.sat)}`:""}${x.hours.sun?` · Sun ${fr(x.hours.sun)}`:""}${missing.length?` · closed ${missing.join(", ")}`:""}`};
const isOpen=(f,n)=>{if(!f.hours)return null;if(f.days&&!f.days.includes(n.dow))return false;return f.hours.some(([a,b])=>n.h>=a&&n.h<b)};
const servesMeal=(f,m)=>f.hours?f.hours.some(([a,b])=>a<MEALS[m][1]&&b>MEALS[m][0]):null;
const hoursText=f=>f.hours?(f.hours[0][0]===0&&f.hours[0][1]===24?"Open 24 hours":`${f.days?dayRange(f.days)+" ":""}${fr(f.hours)}`):"Hours not published";
const openPill=o=>`<span class="pill ${o===null?"warn":o?"ok":"no"}">${o===null?"Hours not published":o?"Open now":"Closed now"}</span>`;

/* ===================== VIEWS ===================== */
function tabOf(v){if(["home","story","question","time","learn","ctx","thread","threads","ask","glossary"].includes(v))return "stories";if(["field","near","museums","museum","mission","walk","walkstart","stop","more","tour"].includes(v))return "field";if(v==="journal")return "journal";return "around"}
function topbar(){const c=cur();let name="";
 if(["home","explore","learn","field","journal"].includes(c.v))name="Mexico City Field Guide";else if(c.v==="areas")name="Getting around";else if(c.v==="story")name=(storyById(c.id)||{}).title;else if(c.v==="question")name="An exploration";else if(c.v==="museum")name=(MUSEUMS.find(x=>x.id===c.id)||{}).museum;else if(c.v==="mission")name="Field mission";else if(["time","museums","near","howknow","editorial"].includes(c.v))name={time:"Time machine",museums:"Museum decoder",near:"Around me",howknow:"How do we know?",editorial:"Editorial dashboard"}[c.v];else if(c.v==="area")name=AR.name;else if(c.v==="stop")name=(getStop(c.id)||{}).name;else if(c.v==="more")name=(siteById(c.id)||{}).name;else if(c.v==="walk"||c.v==="walkstart")name=(walkById(c.w)||{}).name;else if(c.v==="thread")name=(THREADS.find(t=>t.id===c.id)||{}).name;else if(c.v==="tour")name=(tourById(c.id)||{}).name;else if(c.v==="day")name=(DAYS.find(d=>d.id===c.id)||{}).name;else if(c.v==="night")name=(nightById(c.id)||{}).name;else if(c.v==="ctx")name=(ctxById(c.id)||{}).title;else name={search:"Search",sources:"Sources",threads:"Threads",trip:"Your trip",itin:"Itinerary",itday:(()=>{const c=cur();if(c.v!=="itday")return "";const d=new Date(c.iso+"T12:00:00");return d.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})})(),build:"Build your days",season:"Holiday season",basics:"City basics",ask:"Ask the guide",glossary:"Glossary"}[c.v]||"";
 $("#topbar").innerHTML=`${stack.length>1?`<button class="back" data-back aria-label="Back">←</button>`:""}<span class="crumb">${esc(name||"")}</span>${!["areas","search"].includes(c.v)?`<button class="back" data-search aria-label="Search the guide"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="10.5" cy="10.5" r="6.5"/><path d="M20 20l-4.6-4.6"/></svg></button>`:""}<span class="sync" id="syncl">${esc(syncText)}</span>`;
 document.querySelectorAll(".bar button").forEach(b=>b.setAttribute("aria-current",b.dataset.nav===tabOf(c.v)))}
function vAreas(){
 return `<section class="storyhead"><span class="eyebrow">Getting around</span><h1>The practical side</h1><p class="lede">Your plan for today, what's open, food, the map and the areas, and the trip planner. Everything here links back to the history.</p></section>
 <div class="search homesearch" role="search"><label for="q" style="position:absolute;left:-9999px">Search the guide</label><input id="q" type="search" placeholder="Search: Templo Mayor, tacos, Metro" autocomplete="off" value="${esc(searchQ)}"></div><div id="results">${searchResults(searchQ,true)}</div>
 ${nowHTML()}
 <section class="duo"><button class="duob" data-nav="explore"><span class="eyebrow">Map and areas</span><b>Nine neighborhoods</b><span>Walks, places and food by area</span></button><button class="duob" data-nav="trip"><span class="eyebrow">Your trip</span><b>Itinerary and bookings</b><span>Dates, reservations, closures, city basics</span></button></section>`}
function vExplore(){
 return `<section class="pagehead"><h1>Explore</h1><p class="lede muted">Nine areas, each with its own line colour. Pick one for its walks, places and food, or tap a pin.</p></section>
 ${homeMapHTML()}
 <div class="area-grid">${AREAS.filter(a=>AD[a.id]).map(a=>`<button class="area-card" data-area="${a.id}" style="--line:${LINECOL[a.id]||"var(--accent)"}"><span class="linebadge" aria-hidden="true">${LINECODE[a.id]||""}</span><b>${esc(a.name)}</b><span>${esc(a.hook)}</span>${vibeHTML(a)}</button>`).join("")}</div>
 ${vTopPlaces()}`}
/* Learn hub: organized by era (default) or by theme, not by neighborhood. */
const LEARN_ERA={threads:{sunstone:"mexica",conquest:"conquest",water:"mexica",murals:"revolution"},tours:{templomuseo:"mexica",castillo:"independence",mna:"meso"}};
const LEARN_THEMES=[
 {id:"arch",name:"Archaeology",one:"Pyramids, temples and the objects dug out of them.",ctx:["meso","mexica"],threads:["sunstone"],tours:["templomuseo","mna"],
  lenses:[["built","What they built","pyramid|temple|cit(y|ies)|built|planned|platform|stone|causeway|island|palace|plaza|ballcourt|shrine"],
   ["found","What was found","found|excavat|discover|uncover|dug|buried|unearth|ruins?|remains|offering|skull"],
   ["know","How we know","codex|codices|account|wrote|written|record|source|archaeolog|chronicle|survives|told"]]},
 {id:"hist",name:"History",one:"How the city was conquered, rebuilt and lived in.",ctx:["mexica","conquest","newspain","independence"],threads:["conquest","water"],tours:["castillo"],
  lenses:[["turn","Turning points","\\b1[0-9]{3}\\b|fell|fall|founded|landed|independence|took|captured|invaded"],
   ["lives","Ordinary lives","people|population|workers|disease|smallpox|epidemic|labor|lived|market|daily|students|slaves?|miners|peasants?"],
   ["city","The city itself","city|lake|causeway|island|plaza|street|canal|water|built|rebuilt|capital|square|cathedral|palace"]]},
 {id:"pol",name:"Politics and power",one:"Who ruled, how they kept power, and who pushed back.",ctx:["conquest","independence","porfiriato","revolution","mexico68"],threads:["conquest","murals"],tours:["castillo"],
  lenses:[["rule","Who ruled","rul(ed|er|ing)|empire|emperor|president|presidency|governor|king|dominated|government|minister|took the presidency|made himself|cient[ií]ficos|state"],
   ["hold","How they kept power","tribute|troops|police|rurales|army|hostage|kill|massacre|shot|tanks|opened fire|deported|broke strikes|wages|foreign (money|capital)|order|stick|hired|muralists|inquisition|displayed|reelected|overthrew|murdered"],
   ["push","Who pushed back","revolt|rose|rises|rebel|uprising|movement|peasant|students?|citizens|strikes?|called for|fought|zapata|villa|madero|hidalgo|morelos|organized|refused|resist"]]},
 {id:"art",name:"Art",one:"The murals and the state that paid for them.",ctx:["revolution"],threads:["murals"],tours:[],
  lenses:[["paid","Who paid","state|minister|government|hired|commission|paid|public"],
   ["told","What story it told","story|tell|told|paint|murals?|walls?|artists?|history"],
   ["see","Where to see it","San Ildefonso|Palacio|museum|Bellas Artes|castle|walls?"]]}];
/* Theme explorer: every sentence in an era's sourced background is scored against the theme's
   three lenses (keyword patterns). The grid counts matches; each era card shows the matching
   sentences with their sources, so the detail comes from the guide's own cited text. */
function thxSentences(c){const out=[];(c.blocks||[]).concat(c.more||[]).forEach(b=>{
  if(b.p)out.push({t:b.p[0],s:b.p[1]||[],g:b.p[2]});
  else if(b.steps&&b.steps.items)b.steps.items.forEach(it=>out.push({t:it[0],s:it[1]||[],g:it[2]}));
  else if(b.obj&&b.obj.p)out.push({t:b.obj.p[0],s:b.obj.p[1]||[],g:b.obj.p[2]});
  else if(b.pt&&b.pt.blocks)b.pt.blocks.forEach(x=>{if(x.p)out.push({t:x.p[0],s:x.p[1]||[],g:x.p[2]})});});
 return out}
const THXRE={};function thxRe(p){return THXRE[p]||(THXRE[p]=new RegExp(p,"gi"))}
function thxScore(t,lens){const m=t.match(thxRe(lens[2]));return m?m.length:0}
function thxAnalyze(th,c){const ss=thxSentences(c).map((x,i)=>{const sc={};let tot=0;th.lenses.forEach(l=>{sc[l[0]]=thxScore(x.t,l);tot+=sc[l[0]]});return Object.assign({i,sc,tot,best:th.lenses.reduce((a,l)=>sc[l[0]]>(sc[a]||0)?l[0]:a,"")},x)});
 const counts={};th.lenses.forEach(l=>counts[l[0]]=ss.filter(x=>x.sc[l[0]]>0).length);return {ss,counts}}
function thxHTML(){const th=LEARN_THEMES.find(t=>t.id===S.learnTheme)||LEARN_THEMES.find(t=>t.id==="pol")||LEARN_THEMES[0];
 const lens=th.lenses.find(l=>l[0]===S.learnLens)?S.learnLens:"all";const eras=th.ctx.map(ctxById).filter(Boolean);
 const an={};eras.forEach(c=>an[c.id]=thxAnalyze(th,c));const fn=new Footnotes();
 const max=Math.max(1,...eras.flatMap(c=>th.lenses.map(l=>an[c.id].counts[l[0]])));
 const lv=n=>n===0?0:n>=max*0.67?3:n>=max*0.34?2:1;
 const lensName=k=>(th.lenses.find(l=>l[0]===k)||[,"All"])[1];
 const openId=S.learnOpen&&eras.some(c=>c.id===S.learnOpen)?S.learnOpen:(eras[0]||{}).id;
 const grid=`<div class="thx-grid"><table><thead><tr><th></th>${th.lenses.map(l=>`<th scope="col">${esc(l[1])}</th>`).join("")}</tr></thead><tbody>
  ${eras.map(c=>`<tr><th class="row" scope="row">${esc(c.title.replace(/^The (.)/,(m,a)=>a.toUpperCase()))}<span>${esc(c.era)}</span></th>${th.lenses.map(l=>{const n=an[c.id].counts[l[0]];return `<td><button class="thx-cell" data-lv="${lv(n)}" data-lcell="${c.id}:${l[0]}" aria-pressed="${lens===l[0]&&openId===c.id}" aria-label="${esc(c.title)}, ${esc(l[1])}: ${n} sourced point${n===1?"":"s"}">${n}</button></td>`}).join("")}</tr>`).join("")}</tbody></table>
  <p class="hint" style="font-size:12.5px">Each number counts the sourced sentences in that period's background that speak to the question. Darker means more. Tap one to read them.</p></div>`;
 const card=(c,idx)=>{const a=an[c.id];let pick=lens==="all"?a.ss.filter(x=>x.tot>0).sort((x,y)=>y.tot-x.tot||x.i-y.i):a.ss.filter(x=>x.sc[lens]>0).sort((x,y)=>x.i-y.i);
  if(lens==="all")pick=pick.sort((x,y)=>x.i-y.i);
  const places=ctxStops(c.id),prev=eras[idx-1],next=eras[idx+1];
  const asks=th.lenses.map(l=>[`${l[1]}, in ${c.title.replace(/^The /,"the ")} (${c.era}): tell me more.`,l[1]]);
  return `<details class="thx-era" id="thx-${c.id}"${c.id===openId?" open":""} data-thxera="${c.id}"><summary><span class="tlwhen">${esc(c.era)} · ${a.ss.filter(x=>x.tot>0).length} of ${a.ss.length} points on this theme${places.length?` · ${places.length} place${places.length===1?"":"s"}`:""}</span><span class="thx-t">${esc(c.title)}</span><span class="thx-one">${esc(c.one)}</span></summary>
   <div class="thx-body">
   ${c.key&&c.key.length?`<div><div class="tlkeyh">Key moments</div><ul class="tlkey">${c.key.map(k=>`<li>${esc(k)}</li>`).join("")}</ul></div>`:""}
   ${pick.length?`<span class="kicker">${lens==="all"?"Every sourced point on this theme":esc(lensName(lens))+": the sourced points"}</span>`:""}
   ${pick.length?`<ol class="thx-find">${pick.map(x=>`<li><span class="lk">${esc(lensName(lens==="all"?x.best:lens))}</span><p>${termify(esc(x.t))}${fn.mark(x.s)} ${tagHTML(x.g)}</p></li>`).join("")}</ol>`:`<p class="hint">This period's sourced background doesn't speak to "${esc(lensName(lens))}" directly. Try another question above, or ask the guide below.</p>`}
   ${places.length?`<div style="display:grid;gap:6px"><span class="kicker">Where you can see it</span><div class="thx-places">${places.map(x=>`<button class="chip" data-stop="${x.k}">${esc(x.s.name.split(":")[0])}</button>`).join("")}</div></div>`:""}
   <div class="thx-links"><button class="btn small" data-ctxpage="${c.id}">Full background →</button>${asks.map(q=>`<button class="btn small" data-askq="${esc(q[0])}">Ask: ${esc(q[1].toLowerCase())}</button>`).join("")}</div>
   ${tmBtn(`${th.name}: ${c.title}`,c.blocks.concat(c.more||[]))}
   <div class="thx-nav">${prev?`<button class="linkbtn" data-lcell="${prev.id}:${lens}">← ${esc(prev.title)}</button>`:"<span></span>"}${next?`<button class="linkbtn" data-lcell="${next.id}:${lens}">${esc(next.title)} →</button>`:""}</div>
   </div></details>`};
 return `<section class="thx"><div class="thx-head"><div class="chips" role="group" aria-label="Theme">${LEARN_THEMES.map(t=>`<button class="chip" aria-pressed="${t.id===th.id}" data-ltheme="${t.id}">${esc(t.name)}</button>`).join("")}</div>
  <h2 class="lsec">${esc(th.name)}</h2><p class="hint">${esc(th.one)} ${eras.length} period${eras.length===1?"":"s"}, oldest first.</p></div>
  <div class="thx-lenses"><span class="kicker">Read it through one question</span><div class="seg" role="group" aria-label="Question" style="grid-auto-flow:row;grid-template-columns:repeat(2,1fr);border-radius:18px"><button aria-pressed="${lens==="all"}" data-llens="all">All points</button>${th.lenses.map(l=>`<button aria-pressed="${lens===l[0]}" data-llens="${l[0]}">${esc(l[1])}</button>`).join("")}</div></div>
  ${grid}
  ${eras.map(card).join("")}
  ${fn.html()}
  ${learnLinks(th.threads,th.tours)}</section>`}
function learnTour(id){for(const aid in AD){const t=(AD[aid].tours||[]).find(x=>x.id===id);if(t)return t}return null}
function learnLinks(thIds,tourIds){const th=thIds.map(id=>THREADS.find(t=>t.id===id)).filter(Boolean),to=tourIds.map(learnTour).filter(Boolean);
 if(!th.length&&!to.length)return "";
 return `<div class="chips" style="margin-top:6px">${th.map(t=>`<button class="chip" data-thread="${t.id}">Story: ${esc(t.name)}</button>`).join("")}${to.map(t=>`<button class="chip" data-tour="${t.id}">Tour: ${esc(t.name)}</button>`).join("")}</div>`}
function eraItem(c,when,extra){const paras=c.blocks.filter(b=>b.p).slice(0,2);
 return `<li><span class="tlwhen">${esc(when)}</span><button class="linkbtn" style="text-align:left;font-size:17px" data-ctxpage="${c.id}">${esc(c.title)}</button><p><b>${esc(c.one)}</b></p>${c.key&&c.key.length?`<div class="tlkeyh">Key moments</div><ul class="tlkey">${c.key.map(k=>`<li>${esc(k)}</li>`).join("")}</ul>`:""}${paras.length?`<details class="tlmore"><summary>Read the short overview</summary>${paras.map(b=>`<p>${esc(b.p[0])}</p>`).join("")}</details>`:""}<div><button class="btn small" data-ctxpage="${c.id}">Full background, with sources →</button></div>${extra||""}</li>`}
function vLearnHub(){const la=S.learnArea&&AD[S.learnArea]?S.learnArea:"";const by=S.learnBy==="theme"?"theme":"era";
 let areaBlock="";if(la){const A2=AD[la],fn=new Footnotes();areaBlock=`<section class="filters"><div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><span class="kicker">Background for one area</span><button class="btn small" data-learnarea="">Close</button></div><article class="article"><h2>${esc(A2.name)}</h2>${LEGEND}${A2.overview.map(([t,s2,g])=>`<p>${esc(t)}${fn.mark(s2)} ${tagHTML(g)}</p>`).join("")}</article>${fn.html()}</section>`}
 const byEra=()=>`<section style="display:grid;gap:10px"><h2 class="lsec">Mexico City, era by era</h2><p class="hint">Eight periods, oldest first. Each shows its key moments; tap for a short overview, or open the full background for the detail, the sources and every place tied to it.</p><ol class="tline">${CTX.map(c=>{const ths=Object.keys(LEARN_ERA.threads).filter(k=>LEARN_ERA.threads[k]===c.id),tos=Object.keys(LEARN_ERA.tours).filter(k=>LEARN_ERA.tours[k]===c.id),pl=ctxStops(c.id),n=pl.length;
   const seeIt=n?`<div class="tlkeyh">Where you can see it · ${n} place${n===1?"":"s"} in this guide</div><div class="chips">${pl.map(x=>`<button class="chip" data-stop="${x.k}">${esc(x.s.name)}<span class="hint"> · ${esc(x.a.name)}</span></button>`).join("")}</div>`:"";
   return eraItem(c,c.era+(n?` · ${n} place${n===1?"":"s"} to see it`:""),seeIt+learnLinks(ths,tos))}).join("")}</ol></section>`;
 const byTheme=()=>thxHTML();
 return `<section style="display:grid;gap:6px"><h1>Learn</h1><p class="lede muted" style="font-size:16px">The history behind the city, by period or by subject.</p></section>
 <form class="search" id="learnAsk"><label for="lq" style="position:absolute;left:-9999px">Ask the guide</label><input id="lq" placeholder="Ask the guide: why was Tenochtitlan on a lake?" autocomplete="off"><button type="submit">Ask</button></form>
 <div class="seg" role="group" aria-label="Browse by"><button aria-pressed="${by==="era"}" data-learnby="era">By era</button><button aria-pressed="${by==="theme"}" data-learnby="theme">By theme</button></div>
 ${areaBlock}
 ${by==="era"?byEra():byTheme()}
 <section style="display:grid;gap:10px"><h2 class="lsec">Words and names</h2><div><button class="btn" data-go="glossary:">Open the glossary</button></div></section>`}
function vArea(){
 const tabs=`<div class="seg" role="group" aria-label="Area sections"><button aria-pressed="${areaTab==="see"}" data-tab="see">Walks</button><button aria-pressed="${areaTab==="more"}" data-tab="more">All places</button><button aria-pressed="${areaTab==="eat"}" data-tab="eat">Eat</button></div>`;
 return `<section class="hero">${ILL[AR.hero]||""}<div class="hero-body"><span class="kicker">Area guide</span><h1>${esc(AR.name)}</h1><p class="lede">${esc(AR.tagline)}</p>${vibeHTML(AREAS.find(x=>x.id===AR.id)||{})}</div></section>${tabs}${areaTab==="see"?vSee():areaTab==="more"?vMoreList():vEat()}`}
function walkCard(w,n){const ws=walkStops(w),done=ws.filter(x=>S.visited.includes(x)).length,nx=ws.findIndex(x=>!S.visited.includes(x));
 return `<section style="display:grid;gap:10px"><span class="kicker">Walk ${n}</span><h2>${esc(w.name)}</h2>
  <div class="article">${w.intro.map(([t])=>`<p>${esc(t)}</p>`).join("")}</div>
  <div class="map">${mapSVG(w)}<div class="map-foot"><span>${esc(w.time)} · ${ws.length} stops · ${done} visited</span><a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(w.mapsQuery)}" target="_blank" rel="noopener">Open in Google Maps ↗</a></div></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary" data-walkfrom="${w.id}:0">Start this walk</button>${(()=>{if(typeof hereFresh!=="function"||!hereFresh())return "";const base=w.stops.filter(s=>!(w.optional||[]).includes(s)||S.route[s]===true);let best=null;base.forEach((s,j)=>{const l=llOfStop(getStop(s));if(!l)return;const d=hav(S.here.ll,l);if(!best||d<best.d)best={j,d}});return best&&best.j>0?`<button class="btn" data-walkfrom="${w.id}:${best.j}">Start from where I am (stop ${best.j+1})</button>`:""})()}${nx>0?`<button class="btn" data-walk="${w.id}" data-step="${nx}">Continue at stop ${nx+1}</button>`:""}</div>
  ${logisticsHTML(w)}
  <div class="site-grid">${w.stops.map((s,i)=>{const st=getStop(s);return `<button class="site-card" data-stop="${s}">${stopArt(s,st)}<span class="b"><span class="n">STOP ${i+1}${(w.optional||[]).includes(s)?" · OPTIONAL":""}${S.visited.includes(s)?" · VISITED ✓":""}</span><b>${esc(st.name)}</b><span class="what">${esc(st.what||st.summary)}</span>${starsHTML(st.ta)}</span></button>`}).join("")}</div></section>`}
function walkRow(w,n){const ws=walkStops(w),done=ws.filter(x=>S.visited.includes(x)).length,nx=ws.findIndex(x=>!S.visited.includes(x)),on=S.walkOn&&S.walkOn.w===w.id;
 return `<section class="filters walkrow"><span class="kicker">Walk ${n} · ${esc(w.time.replace(/^About /,""))} · ${ws.length} stops${(()=>{const o=(w.optional||[]).filter(x=>!ws.includes(x)).length;return o?` + ${o} optional`:""})()}${done?` · ${done} visited`:""}</span><h2>${esc(w.name)}</h2>
  <p style="font-size:16px;line-height:1.55">${esc((w.intro[0]||[""])[0])}</p>
  <ol class="chain">${ws.map(x=>`<li${S.visited.includes(x)?' class="done"':""}>${esc(getStop(x).name.split(":")[0])}</li>`).join("")}</ol>
  <div class="mc-btns">${on&&nx>=0?`<button class="btn primary" data-walk="${w.id}" data-step="${nx}">Continue at stop ${nx+1}</button>`:`<button class="btn primary" data-walkfrom="${w.id}:0">Open this walk</button>`}</div></section>`}
function vSee(){
 return `<p class="lede muted" style="font-size:16px">${esc(AR.walks.length>1?`${AR.walks.length} walks. Open one for its route, map and background, then start it.`:"Open the walk for its route, map and background, then start it.")}</p>
 ${AR.walks.map((w,i)=>walkRow(w,i+1)).join("")}
 <p class="hint">Want the history first? <button class="linkbtn" data-learnarea="${AR.id}">Read the background for ${esc(AR.name)}</button> in Learn. Every place, on a walk or not, is under <button class="linkbtn" data-tab="more">All places</button>.</p>
 ${plannerHTML()}${bookHTML()}`}
function vLearn(){const fn=new Footnotes();
 const ths=THREADS.filter(t=>t.steps.some(st=>AR.stops[st.ref]||AR.sites.some(x=>x.id===st.ref)));
 return `<article class="article"><h2>The area</h2>${LEGEND}${AR.overview.map(([t,s,g])=>`<p>${esc(t)}${fn.mark(s)} ${tagHTML(g)}</p>`).join("")}</article>${fn.html()}
 ${ctxSection(ctxFor(Object.keys(AR.stops)),"The big history behind this area, in order. Each stop then sticks to its own story.")}
 ${ths.length?`<section style="display:grid;gap:10px"><h2 class="lsec">Stories that run through here</h2><div class="food-grid">${ths.map(t=>`<button class="food" style="text-align:left" data-thread="${t.id}"><b style="font-size:17px">${esc(t.name)}</b><p class="hint">${esc(t.summary)}</p></button>`).join("")}</div></section>`:""}`}
function vEat(){
 const now=mxNow();let hidden=0;
 const list=AR.food.filter(f=>{
  if(S.price.length&&!S.price.includes(f.price))return false;
  if(S.types.length&&!f.types.some(t=>S.types.includes(t)))return false;
  if(S.mood.length&&!S.mood.some(m=>moodsOf(f).includes(m)))return false;
  if(S.open||S.meals.length){if(!f.hours){hidden++;return false}
   if(S.open&&!isOpen(f,now))return false;
   if(S.meals.length&&!S.meals.some(m=>servesMeal(f,m)))return false;}
  return true});
 const chips=(vals,key,labels)=>vals.map((v,i)=>`<button class="chip" aria-pressed="${S[key].includes(v)}" data-f="${key}" data-v="${esc(String(v))}">${esc(labels?labels[i]:v)}</button>`).join("");
const any=S.mood.length||S.price.length||S.types.length||S.meals.length||S.open;
 return `<section class="filters">
  <div class="frow"><span class="kicker">When</span><div class="chips"><button class="chip open" aria-pressed="${S.open}" data-open>Open now · ${esc(now.label)} CDMX</button>${chips(["breakfast","lunch","dinner"],"meals",["Breakfast","Lunch","Dinner"])}</div></div>
  <div class="frow"><span class="kicker">Mood</span><div class="chips">${chips(MOODS.map(m=>m[0]),"mood",MOODS.map(m=>m[1]))}</div></div>
  <div class="frow"><span class="kicker">Price</span><div class="chips">${chips([1,2,3,4],"price",PRICES)}</div></div>
  <div class="frow"><span class="kicker">Type</span><div class="chips">${chips(TYPES,"types")}</div></div>
  ${any?`<div><button class="btn small" data-clear>Clear filters</button></div>`:""}
  <p class="hint">"Open now" and meals use hours from each restaurant's own website. Holiday hours, especially Dec 24–25 and Dec 31–Jan 1, may differ; call ahead.</p></section>
 ${hidden?`<p class="hint">${hidden} place${hidden>1?"s are":" is"} hidden because ${hidden>1?"they don't":"it doesn't"} publish hours on an official website.</p>`:""}
 ${list.length?"":`<p class="empty">Nothing in ${esc(AR.name)} matches these filters. Try removing a filter or a price level.</p>`}
 <div class="food-grid">${list.map(f=>`<article class="food">
  <div class="food-h"><b>${esc(f.name)}</b><span class="price">${PRICES[f.price-1]}</span></div>
  <div class="meta">${f.types.map(t=>`<span class="pill">${esc(t)}</span>`).join("")}${openPill(isOpen(f,now))}<span class="pill ${f.crit.length>=2?"ok":"warn"}">${f.crit.length>=2?"Two+ critic sources":"Verify: one critic source"}</span></div>
  <p><strong>Order:</strong> ${esc(f.order)}</p>
  <p class="hint">${esc(hoursText(f))}${f.hsrc&&f.hours?` · hours from ${srcTag([f.hsrc])}`:""}${f.note?` · ${esc(f.note)}`:""}</p><p>${freshHTML(f.hsrc?[f.hsrc]:f.crit,"food:"+AR.id+":"+f.name)}</p>
  <p class="why"><span class="kind">Editorial pick.</span> Why it's here: ${esc(f.why)} ${srcTag(f.crit)}</p>
  ${f.pick?pickHTML(f.pick,true):""}
  ${f.voices?`<p class="hint"><strong>What diners say:</strong> ${esc(f.voices.pts.join(" "))} ${srcTag(f.voices.s)}</p>`:""}
  <p class="hint">${esc(f.addr)} · <a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(f.name+" "+f.addr+" Ciudad de México")}" target="_blank" rel="noopener">Map ↗</a></p>${(()=>{const k="food:"+AR.id+":"+f.name,n=visibleContribs(k).length;return `<details class="foodcomm"><summary>Community reports${n?` (${n})`:""} · share yours</summary>${communityBlockHTML(k,f.name,"restaurant")}</details>`})()}</article>`).join("")}</div>
 ${(AR.foodNotes||[]).map(n=>`<p class="hint">${esc(n)}</p>`).join("")}<p class="hint">Price levels are relative until peso ranges are set. Checked ${CHECKED}.</p>`}

function orderSite(steps){
 const forks=steps.filter(x=>x.fork&&!x.fork.route);if(!forks.length)return steps;
 let out=steps.slice();
 forks.forEach(b=>{const f=b.fork,v=S.forks[f.id];if(!v)return;const keys=f.opts.map(o=>o[0]);
  const base=out.filter(x=>!(x.side&&keys.includes(x.side)));const fi=base.indexOf(b);
  const parts=[v].concat(keys.filter(k=>k!==v)).map(k=>out.filter(x=>x.side===k));
  base.splice(fi+1,0,...[].concat(...parts));out=base});
 return out}
let PTN=0;
function blockHTML(x,fn){
 if(x.where)return `<span class="where">${esc(x.where)}</span>`;
 if(x.sec)return `<h2 class="lsec" id="${secId(x.sec)}">${esc(x.sec)}</h2>`;
 if(x.ctx){const c=ctxById(x.ctx);return c?`<p class="hint" style="font-size:14.5px">Background: <button class="linkbtn" data-ctxpage="${c.id}">${esc(c.title)} (${esc(c.era)})</button></p>`:""}
 if(x.pt){PTN=(PTN||0)+1;const all=S.mode==="read"||(S.prefs&&S.prefs.depth==="deep");const open=all||x.pt.open||PTN===1;
  return `<details class="pt"${open?" open":""}><summary><span class="ptsum">${x.pt.when?`<span class="ptwhen">${esc(x.pt.when)}</span>`:""}<span class="pth">${esc(x.pt.h)}</span></span></summary><div class="ptb">${x.pt.blocks.map(b=>blockHTML(b,fn)).join("")}${(x.pt.more||[]).map(m=>`<details class="ptmore"${all?" open":""}><summary>${m.label==="More"?"More":"More: "+esc(m.label)}</summary>${m.blocks.map(b=>blockHTML(b,fn)).join("")}</details>`).join("")}${tmBtn(x.pt.h,x.pt.blocks.concat(...(x.pt.more||[]).map(m=>m.blocks)))}</div></details>`}
 if(x.next)return `<p class="lnext"><b class="lnextk">Next</b>${esc(x.next)}</p>`;
 if(x.deep){const open=S.mode==="read"||(S.prefs&&S.prefs.depth==="deep");return `<details class="ldeep"${open?" open":""}><summary>${esc(x.deep.label||"Go deeper")}</summary>${x.deep.blocks.map(b=>blockHTML(b,fn)).join("")}</details>`}
 if(x.h)return `<h3>${esc(x.h)}</h3>`;
 if(x.p)return `<p>${termify(esc(x.p[0]))}${fn.mark(x.p[1])} ${tagHTML(x.p[2],x.p[1])}</p>`;
 if(x.obj)return objHTML(x.obj,fn);
 if(x.fig)return `<figure class="figure" style="margin:0">${FIG[x.fig]()}<figcaption>${esc(x.cap)}</figcaption></figure>`;
 if(x.take)return `<div class="callout take"><span class="lbl">Honest take</span><span>${esc(x.take)}</span></div>`;
 if(x.prac)return `<div class="callout prac"><span class="lbl">Practical</span><span>${esc(x.prac[0])}${fn.mark(x.prac[1])} ${tagHTML(x.prac[2]||(x.prac[1].length?"est":"unk"))}</span></div>`;
 if(x.voices)return voicesHTML(x.voices);
 if(x.steps){const st=x.steps;return `<section class="stepsblk"><div class="stepsh"><b>${esc(st.title)}</b>${st.time?`<span class="hint">${esc(st.time)}</span>`:""}</div>${st.intro?`<p class="hint">${esc(st.intro)}</p>`:""}<ol class="routelist">${st.items.map(([t,src,tag])=>`<li><span>${esc(t)}${src&&src.length?fn.mark(src):""}${tag&&tag!=="est"?" "+tagHTML(tag):""}</span></li>`).join("")}</ol>${st.after?`<p class="hint">${esc(st.after)}</p>`:""}</section>`}
 if(x.gobtns)return `<div class="mc-btns">${x.gobtns.map(([l,attr])=>`<button class="btn small" ${attr}>${esc(l)}</button>`).join("")}</div>`;
 if(x.detour)return `<details class="detour"><summary>Detour: ${esc(x.detour.h)}</summary><p>${esc(x.detour.p[0])}${fn.mark(x.detour.p[1])} ${tagHTML(x.detour.p[2])}</p>${x.detour.site?`<p><button class="btn small" data-more="${x.detour.site}">Open the site page →</button></p>`:""}</details>`;
 if(x.fork){const f=x.fork;
  if(f.route){const v=S.route[f.id];return `<div class="fork"><p>${esc(f.q)}</p>${v==null?`<div class="fork-opts">${f.opts.map(([k,l])=>`<button data-route="${f.id}" data-val="${k}">${esc(l)}</button>`).join("")}</div>`:`<span class="hint">${v?"Added to today's walk.":"Skipped for today."} <button class="btn small" data-reroute="${f.id}">Change</button></span>`}</div>`}
  const v=S.forks[f.id];return `<div class="fork"><p>${esc(f.q)}</p>${v?`<span class="hint">Starting with ${esc(f.opts.find(o=>o[0]===v)[1])}. <button class="btn small" data-refork="${f.id}">Change</button></span>`:`<div class="fork-opts">${f.opts.map(([k,l])=>`<button data-fork="${f.id}" data-val="${k}">${esc(l)}</button>`).join("")}</div>`}</div>`}
 return ""}
function sectionsOf(blocks){const out=[];let curS=null;(blocks||[]).forEach(b=>{if(b.h){curS={h:b.h,blocks:[]};out.push(curS);return}if(!curS){curS={h:"The story",blocks:[]};out.push(curS)}curS.blocks.push(b)});return out}
function deeperHTML(title,blocks,fn,open){if(!blocks||!blocks.length)return "";return `<details class="deeper"${open?" open":""}><summary>${esc(title)}</summary><div class="article">${blocks.map(b=>blockHTML(b,fn)).join("")}</div></details>`}
function tourCard(st){if(!st.tour)return "";const t=tourById(st.tour);if(!t)return "";return `<button class="tourcard" data-tour="${t.id}"><span class="tourtile">${stopArt(t.stop,getStop(t.stop))}</span><span style="display:grid;gap:3px;min-width:0"><span class="kicker">Museum tour · about ${fmtDur(t.mins/60)}</span><b>${esc(t.name)}</b><span class="hint">${esc(t.summary)}</span></span></button>`}
function ctxFor(ids){const set=new Set();ids.forEach(id=>{const st=getStop(id);(st&&st.lead||[]).forEach(b=>{if(b.ctx)set.add(b.ctx)})});return CTX.filter(c=>set.has(c.id)).map(c=>c.id)}
function ctxSection(ids,intro){if(!ids.length)return "";const fn=new Footnotes();return `<section class="article" style="gap:10px"><h2 class="lsec">The background</h2><p class="hint" style="font-size:15px">${esc(intro)}</p>${ids.map(id=>ctxBlockHTML(id,fn)).join("")}</section>${fn.html()}`}
function ctxLinks(P){if(!P.ctx.length)return "";return `<p class="hint" style="font-size:14.5px">Background for this place: ${P.ctx.map(b=>{const c=ctxById(b.ctx);return c?`<button class="linkbtn" data-ctxpage="${c.id}">${esc(c.title)} (${esc(c.era)})</button>`:""}).join(", ")}</p>`}
function stopParts(st){const L=st.lead||st.read||[];const P={prac:[],route:[],after:[],where:null,ctx:[],look:[],story:[],other:[]};let sec=null;
 L.forEach(b=>{if(b.sec){sec=b.sec;return}if(b.where){P.where=b;return}if(b.ctx){P.ctx.push(b);return}
  if(sec==="Before you go in"){P.prac.push(b);return}if(sec==="Your route"){P.route.push(b);return}if(sec==="After"){P.after.push(b);return}
  if(b.pt){(b.pt.look?P.look:P.story).push(b);return}P.other.push(b)});
 P.story.sort((a,b)=>(a.pt.ord??99)-(b.pt.ord??99));return P}
function briefHTML(story,fn){return `<ol class="tline">${story.map(b=>{const p=(b.pt.blocks.find(x=>x.p)||{}).p;return `<li>${b.pt.when?`<span class="tlwhen">${esc(b.pt.when)}</span>`:""}<b>${esc(b.pt.h)}</b>${p?`<p>${termify(esc(p[0]))}${fn.mark(p[1])} ${tagHTML(p[2])}</p>`:""}</li>`}).join("")}</ol>`}
function pracOpen(sid){if(window.__pracNow===sid)return true;S.pracSeen=S.pracSeen||[];if(S.pracSeen.includes(sid))return false;S.pracSeen.push(sid);window.__pracNow=sid;setTimeout(save,0);return true}
function secId(t){return "sec-"+t.toLowerCase().replace(/[^a-z]+/g,"-").replace(/^-|-$/g,"")}
function jumpNav(titles){titles=titles.filter(Boolean);return titles.length>1?`<nav class="jumpnav" aria-label="On this page">${titles.map(t=>`<button class="chip" data-jump="${secId(t)}">${esc(t)}</button>`).join("")}</nav>`:""}
function stopBody(st,fn,sid){const P=stopParts(st),H=b=>blockHTML(b,fn),sec=t=>`<h2 class="lsec" id="${secId(t)}">${esc(t)}</h2>`;
 if(S.mode==="read"){
  return `${jumpNav([P.story.length&&"The history, in order",P.look.length&&(P.story.length?"What you'll see there":"The place")])}${P.story.length?sec("The history, in order")+P.story.map(H).join(""):""}${ctxLinks(P)}
  ${P.look.length?sec(P.story.length?"What you'll see there":"The place")+P.look.map(H).join(""):""}${P.other.map(H).join("")}${tourCard(st)}
  <div class="callout prac"><span class="lbl">When you go</span><span>${P.prac.length||P.route.length?"Hours, tickets and a step-by-step route are in the On site view.":"Where to stand and what to look at are in the On site view."} <button class="linkbtn" data-mode="site">Switch to On site</button></span></div>`}
 const look=P.look.map((b,j)=>({pt:Object.assign({},b.pt,{open:j===0&&!st.find})}));
 const rt=P.route.length?"Your route":"What's in front of you";
 const fd=(S.found||{})[sid]||[],when=P.story.map(b=>b.pt.when).filter(Boolean);
 const findH=st.find&&st.find.length?sec("Look for")+`<ul class="findlist">${st.find.map((t,j)=>`<li><button class="findbtn" data-found="${sid}" data-fi="${j}" aria-pressed="${fd.includes(j)}"><span class="fbox" aria-hidden="true">${fd.includes(j)?"✓":""}</span><span>${esc(t)}</span></button></li>`).join("")}</ul>`:"";
 return `${jumpNav([findH&&"Look for",P.prac.length&&"Before you go in",(P.route.length||look.length)&&rt,P.after.length&&"After"])}${P.where?H(P.where):""}${st.spot?`<p class="spot"><b>How to spot it:</b> ${esc(st.spot)}</p>`:""}
  ${findH}
  ${P.prac.length?`<details class="pracwrap"${pracOpen(sid)?" open":""}><summary>${sec("Before you go in")}</summary>${P.prac.map(H).join("")}</details>`:""}
  ${P.route.length||look.length?sec(rt)+P.route.map(H).join("")+look.map(H).join(""):""}
  ${P.story.length?`<div class="callout readnext"><span class="lbl">The history</span><span>${P.story.length} ${P.story.length===1?"part":"parts"}${when.length?`, ${esc(when[0])} to ${esc(when[when.length-1])}`:""}. Best read before you come or over a coffee after. <button class="linkbtn" data-mode="read">Read ahead</button></span></div>`:""}
  ${ctxLinks(P)}${P.other.map(H).join("")}${tourCard(st)}
  ${photoSlotHTML(sid)}
  ${P.after.length?sec("After")+P.after.map(H).join(""):""}`}
function stopContent(sid){
 const st=getStop(sid),fn=new Footnotes();
 const mode=`<div class="seg" role="group" aria-label="Reading mode"><button aria-pressed="${S.mode==="read"}" data-mode="read">Read ahead</button><button aria-pressed="${S.mode==="site"}" data-mode="site">On site</button></div>`;
 let body;
 if((st.lead||st.read||[]).some(b=>b.pt))body=stopBody(st,fn,sid);
 else if(S.mode==="read"){body=`${st.read.map(b=>blockHTML(b,fn)).join("")}${st.take&&st.siteRef?blockHTML({take:st.take},fn):""}${tourCard(st)}`}
 else{const lead=orderSite(st.lead||st.read);
  const more=orderSite(st.more||[]),secs=sectionsOf(st.lead&&!st.lead.some(b=>b.pt)?st.read:[]);
  body=`${lead.map(b=>blockHTML(b,fn)).join("")}${tourCard(st)}${more.length||secs.length?`<div class="deeperwrap"><span class="kicker">Go deeper</span>${deeperHTML("More to see here",more,fn)}${secs.map(x=>deeperHTML(x.h,x.blocks,fn)).join("")}</div>`:""}`}
 return `<section class="hero">${stopArt(sid,st)}<div class="hero-body"><span class="illus-note">${st.photos?`<a href="${st.photos}" target="_blank" rel="noopener">See real photos ↗</a>`:""}</span><span class="kicker">${esc(st.time||"")}</span><h1>${esc(st.name)}</h1><p class="lede">${esc(st.summary)}</p>${recHTML(st.rec,true)}${starsHTML(st.ta,true)}</div></section>
 <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn small" data-askabout="${sid}">Ask about this place</button>${st.siteRef?`<button class="btn small" data-more="${st.siteRef}">Hours, cost and address</button>`:""}</div>${threadChips(sid)}
 ${mode}<article class="article">${LEGEND}${body}${st.voices?voicesHTML(st.voices):""}${st.pick?pickHTML(st.pick):""}</article>${fn.html()}`}
function vTour(){const t=tourById(cur().id),st=getStop(t.stop),fn=new Footnotes();
 return `<section class="hero">${stopArt(t.stop,st)}<div class="hero-body"><span class="kicker">Museum tour · about ${fmtDur(t.mins/60)}</span><h1>${esc(t.name)}</h1><p class="lede">${esc(t.summary)}</p></div></section>
 <article class="article">${LEGEND}${tourBody(t,fn)}
 ${sectionsOf(t.background).length?`<div class="deeperwrap"><span class="kicker">Background</span>${sectionsOf(t.background).map(x=>deeperHTML(x.h,x.blocks,fn)).join("")}</div>`:""}</article>${fn.html()}
 <div><button class="btn" data-back>Back to ${esc(st.name)}</button></div>`}
function markVisited(id){if(!S.visited.includes(id)){S.visited.push(id);save()}}
function vStop(){markVisited(cur().id);return placePage("stop",cur().id)}
const llOfStop=st=>st&&(st.ll||(siteById(st.siteRef)||{}).ll);
function dirURL(st){const ll=llOfStop(st);return `https://www.google.com/maps/dir/?api=1&destination=${ll?ll.join(","):encodeURIComponent(st.name+", Ciudad de México")}&travelmode=walking`}
function breakHTML(w,sid){const br=(w.breaks||[]).filter(b=>b.after===sid);if(!br.length)return "";const a=AD[WALKIDX[w.id]],now=mxNow(),fn=new Footnotes();
 return br.map(b=>{const picks=(b.food||[]).map(nm=>a.food.find(f=>f.name===nm)).filter(Boolean);
  return `<section class="filters breakcard"><span class="kicker">☕ Break: ${esc(b.label)}</span>${picks.map(f=>{const st=foodStatus(f,now)||{s:"unk",t:"Hours not published"};return `<button class="nowitem" data-eatarea="${a.id}"><span class="nowname">${esc(f.name)} <span class="price">${PRICES[f.price-1]}</span></span><span class="nowmeta">${statusPill(st)}</span><span class="hint">${esc(f.order.split(";")[0].split(". ")[0])}</span></button>`}).join("")}
  ${(b.notes||[]).map(([t,s2,g])=>`<p class="hint">${esc(t)}${fn.mark(s2)} ${tagHTML(g||(s2&&s2.length?"est":"unk"))}</p>`).join("")}${b.voices?voicesHTML(b.voices):""}${fn.html()}</section>`}).join("")}
function timingHTML(w,stops,i){
 const n=mxNow();let t=n.h+((getStop(stops[i]).mins||20)/60);const out=[];
 for(let j=i+1;j<stops.length;j++){const prev=getStop(stops[j-1]),st=getStop(stops[j]);const wk=prev.walkon&&prev.walkon.to===stops[j]&&prev.walkon.min?prev.walkon.min:6;t+=wk/60;
  if(st.hours){const ps=placeStatus({hours:st.hours},{h:t,dow:n.dow});
   if(ps.s==="closed"){const nowSt=placeStatus({hours:st.hours},n);
    if(nowSt.s==="open"&&j>i+1)out.push(`At this pace you'd reach <strong>${esc(st.name)}</strong> around ${fmtH(t)}, after it closes (${esc(nowSt.t.split(" · ")[1])}). <button class="btn small primary" data-walk="${w.id}" data-step="${j}">Go there next</button> then come back for the rest.`);
    else if(nowSt.s==="closed")out.push(`<strong>${esc(st.name)}</strong> is ${esc(nowSt.t.toLowerCase())}. Skip it on this walk and come back another day.`);
    else out.push(`<strong>${esc(st.name)}</strong> may be closed by the time you get there (around ${fmtH(t)}).`);break}
   if(ps.s==="later"&&j===i+1)out.push(`<strong>${esc(st.name)}</strong> ${esc(ps.t.toLowerCase())}; you'd arrive around ${fmtH(t)}.`)}
  t+=(st.mins||20)/60}
 if(t>22&&!out.length)out.push(`Finishing the rest of this walk would take until about ${fmtH(Math.min(t,23.9))}. Consider stopping after the next stop and picking it up tomorrow.`);
 return out.length?`<section class="filters timecard"><span class="kicker">⏱ Timing · now ${esc(n.label)}</span>${out.map(x=>`<p style="font-size:15px">${x}</p>`).join("")}</section>`:""}
function recapHTML(w){const a=AD[WALKIDX[w.id]],fn=new Footnotes(),now=mxNow();
 const ths=THREADS.filter(t=>t.steps.some(s=>w.stops.includes(s.ref)||w.stops.some(x=>(a.stops[x]||{}).siteRef===s.ref)));
 const eat=a.food.map(f=>({f,st:foodStatus(f,now)})).filter(x=>x.st&&x.st.s==="open").slice(0,2);
 const nw=w.next?walkById(w.next):null;
 const det=(a.detours||[]).filter(d=>d.site&&!S.visited.includes(d.site)).slice(0,2);
 return `<section class="filters recap"><span class="kicker">🏁 You finished ${esc(w.name)}</span>${w.q?`<p class="gq small"><b>You set out asking:</b> ${esc(w.q)}</p>`:""}
  <div class="article">${(w.recap||[]).map(([t,s2,g])=>`<p style="font-size:16.5px">${esc(t)}${fn.mark(s2)} ${tagHTML(g)}</p>`).join("")}</div>
  ${ths.length?`<div class="chips"><span class="hint" style="align-self:center">Threads this walk touched:</span>${ths.map(t=>`<button class="chip" data-thread="${t.id}">${esc(t.name)}</button>`).join("")}</div>`:""}
  <span class="kicker">What's next</span><div class="nowlist">
  ${eat.map(x=>`<button class="nowitem" data-eatarea="${a.id}"><span class="nowname">Eat: ${esc(x.f.name)}</span><span class="nowmeta">${statusPill(x.st)}</span></button>`).join("")}
  ${det.map(d=>`<button class="nowitem" data-more="${d.site}"><span class="nowname">Nearby: ${esc(d.name)}</span><span class="hint">${esc(d.what)}</span></button>`).join("")}
  ${nw?`<button class="nowitem" data-walk="${nw.id}" data-step="0"><span class="nowname">Next walk: ${esc(nw.name)}</span><span class="hint">${esc(AD[WALKIDX[nw.id]].name)} · ${esc(nw.length||nw.time)}</span></button>`:""}
  </div>${fn.html()}</section>`}
function vWalk(){
 const c=cur(),w=walkById(c.w),stops=walkStops(w),i=Math.min(c.i||0,stops.length-1),sid=stops[i],st=getStop(sid),next=stops[i+1];
 markVisited(sid);
 {const ll=llOfStop(st);if(ll)setHere(ll,st.name,true)}
 let wo;const fnW=new Footnotes();window.__bw=w.id;window.__bi=i;
 if(next){const w2=st.walkon&&st.walkon.to===next?st.walkon:st.walkAlt&&st.walkAlt[next]?{min:0,p:st.walkAlt[next]}:{min:0,p:"Continue to the next stop."};const ns=getStop(next);
  wo=`<div class="walkon"><span class="kicker">Walk on · stop ${i+2} of ${stops.length}${w2.min?` · about ${w2.min} min`:""}</span><h3>${esc(ns.name)}</h3><p>${esc(w2.p)}</p>${w.q&&i===Math.floor((stops.length-1)/2)?`<p class="hint">Halfway. Still carrying: <i>${esc(w.q)}</i></p>`:""}${st.notice?st.notice.map(([t,s2])=>`<p class="notice">👀 On the way: ${esc(t)}${fnW.mark(s2)}</p>`).join(""):""}<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary" data-walk="${w.id}" data-step="${i+1}">I'm there</button><a class="btn" href="${dirURL(ns)}" target="_blank" rel="noopener">Directions in Google Maps ↗</a></div>${fnW.list.length?`<div class="walknotes">${fnW.html()}</div>`:""}</div>`}
 else wo=recapHTML(w);
 if(!S.walkOn||S.walkOn.w!==w.id){S.walkOn={w:w.id,t:Date.now()};save()}
 const intro=`<div class="walkbar slim" role="navigation" aria-label="Walk progress"><b class="wbcount">Stop ${i+1} of ${stops.length}</b><div class="wbprog" aria-hidden="true">${stops.map((x,j)=>`<span class="${j<i?"done":j===i?"now":""}"></span>`).join("")}</div><span class="wbbtns"><button class="wbbtn" data-walkmap aria-pressed="${!!S.walkMap}">${S.walkMap?"Hide map":"Map"}</button><button class="wbbtn" data-breakopen="${w.id}" data-breaki="${i}">Break</button><button class="wbbtn" data-walkend="${w.id}" aria-label="End walk">End</button></span></div>`;
 return `<div class="pinned">${intro}${S.walkMap?`<div class="map">${mapSVG(w,sid,true)}</div>`:""}</div>
 ${S.mode==="site"?timingHTML(w,stops,i):""}${stopContent(sid)}${breakHTML(w,sid)}${wo}${i>0?`<div><button class="btn" data-walk="${w.id}" data-step="${i-1}">← Previous stop</button></div>`:""}`}

function checksHTML(){const r=runChecks();const row=(ok,t)=>`<li><span class="pill ${ok===true?"ok":ok==="warn"?"warn":"no"}">${ok===true?"Pass":ok==="warn"?"Note":"Fail"}</span> ${t}</li>`;
 return `<section class="filters"><span class="kicker">Content checks</span><p class="hint">Run automatically every time this page loads, on all ${r.total} claims across ${Object.keys(AD).length} areas.</p>
 <ul style="margin:0;padding:0;list-style:none;display:grid;gap:8px;font-size:14px">
 ${row(!r.unsourced.length,r.unsourced.length?`${r.unsourced.length} claim(s) have no source: ${esc(r.unsourced.map(c=>c.where).join(", "))}`:"Every claim has a source or is tagged Unknown")}
 ${row(!r.missingIds.length,r.missingIds.length?`Broken source references: ${esc([...new Set(r.missingIds)].join(", "))}`:"Every source reference points to a listed source")}
 ${row(!r.opinionOnly.length,r.opinionOnly.length?`${r.opinionOnly.length} claim(s) rest only on forums or blogs: ${esc([...new Set(r.opinionOnly.map(c=>c.where))].join(", "))}`:"No fact rests only on forums or travel blogs")}
 ${row(r.journalismOnly.length?"warn":true,r.journalismOnly.length?`${r.journalismOnly.length} Established claim(s) rest only on journalism: ${esc([...new Set(r.journalismOnly.map(c=>c.where))].join(", "))}`:"No Established claim rests only on journalism")}
 ${row(r.oneSourceFood.length?"warn":true,r.oneSourceFood.length?`${r.oneSourceFood.length} food pick(s) have only one critic source: ${esc(r.oneSourceFood.map(f=>f.name).join(", "))}`:"Every food pick has two critic sources")}
 ${row(r.stale?"warn":true,r.stale?`Facts were last checked ${r.age} days ago; recheck before the trip`:`Facts checked ${r.age<=0?"today":r.age+" day(s) ago"} (${CHECKED})`)}
 ${row(true,`${r.deb} claim(s) tagged Debated, ${r.unk} tagged Unknown`)}
 ${row(r.unusedSrc.length?"warn":true,r.unusedSrc.length?`Listed but unused sources: ${esc(r.unusedSrc.join(", "))}`:"Every listed source is used")}
 </ul><p class="hint">Link reachability can't be tested from inside this page; links are checked when the guide is updated.</p></section>`}
function vSources(){const tiers=["Institutional","Scholarly","Journalism","Food critic","Official site","Forum","Travel blog"];
 return `<section style="display:grid;gap:10px"><span class="kicker">Sources</span><h1>Where every claim comes from</h1><p class="lede muted">History rests on institutional and scholarly sources; journalism covers recent finds and access; food picks rest on critics, with hours from restaurants' own sites. Forums and travel blogs help decide what to include and supply "What visitors say," but never support a fact. Checked ${CHECKED}.</p></section>
 ${checksHTML()}
 ${tiers.map(t=>{const ids=Object.keys(SRC).filter(i=>SRC[i].t===t);return ids.length?`<section style="display:grid;gap:2px"><h2>${t}</h2>${ids.map(i=>`<a class="srcrow" href="${SRC[i].u}" target="_blank" rel="noopener"><b>${esc(SRC[i].n)}</b><span>${esc(new URL(SRC[i].u).hostname)} ↗</span></a>`).join("")}</section>`:""}).join("")}`}

function dayInfo(i){const d=new Date(S.start+"T12:00:00");d.setDate(d.getDate()+i);const k=String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");return {d,dow:d.getDay(),k,label:d.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})}}
function closuresFor(di){const out=[];
 (AR.closures||[]).forEach(c=>{if((c.dows&&c.dows.includes(di.dow))||(c.dates&&c.dates.includes(di.k)))out.push(c)});
 seasonFor(di.k).forEach(e=>out.push({lvl:"warn",t:"Season: "+e.name+". See the Trip tab for what happens and what to eat."}));
 const closedMore=AR.sites.filter(m=>m.hours&&!m.hours.days.includes(di.dow)&&!m.link).map(m=>m.name);
 if(closedMore.length)out.push({lvl:"warn",t:"Closed this day: "+closedMore.join(", ")+"."});
 if(!out.length)out.push({lvl:"ok",t:"Good day here. All walk stops with published hours are open."});
 return out}
function plannerHTML(){const fn=new Footnotes();
 return `<section class="filters"><span class="kicker">Plan by date · ${esc(AR.name)}</span>
  <label class="hint" for="tripStart">First day of your trip</label><input id="tripStart" type="date" value="${esc(S.start)}" style="font:inherit;color:var(--ink);background:var(--paper);border:1px solid var(--rule);border-radius:10px;padding:8px 10px">
  <div style="display:grid;gap:10px">${tripIdx().map(i=>{const di=dayInfo(i);return `<div style="display:grid;gap:4px;border-top:1px solid var(--rule);padding-top:8px"><strong>Day ${i+1} · ${esc(di.label)}</strong>${closuresFor(di).map(c=>`<span class="hint"><span class="pill ${c.lvl}">${c.lvl==="ok"?"OK":c.lvl==="warn"?"Note":"Closed"}</span> ${esc(c.t)}${c.s?fn.mark(c.s):""}</span>`).join("")}</div>`}).join("")}</div>
 </section>${fn.html()}`}
function logisticsHTML(w){if(!w.logistics)return "";const fn=new Footnotes();
 return `<section class="filters"><span class="kicker">Walk logistics</span><dl style="display:grid;grid-template-columns:auto 1fr;gap:8px 14px;margin:0">${w.logistics.map(([k,v,s,g])=>`<dt style="font-weight:700">${esc(k)}</dt><dd style="margin:0;min-width:0">${esc(v)}${fn.mark(s)} ${tagHTML(g)}</dd>`).join("")}</dl>${fn.html()}</section>`}
function bookHTML(){const B=AR.bookAhead||[];if(!B.length)return "";const fn=new Footnotes();const done=B.filter(b=>S.book.includes(b.id)).length;
 return `<section class="filters"><div style="display:flex;justify-content:space-between;align-items:baseline;gap:10px"><span class="kicker">Before you go</span><span class="hint">${done} of ${B.length} done</span></div>
  <div style="display:grid;gap:8px">${B.map(b=>`<label style="display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:start;font-size:14.5px"><input type="checkbox" data-book="${b.id}" ${S.book.includes(b.id)?"checked":""} style="margin-top:3px;accent-color:var(--accent)"><span>${esc(b.t)}${fn.mark(b.s)}</span></label>`).join("")}</div></section>${fn.html()}`}
function walkFoodHTML(sid){const a=AD[STOPIDX[sid]],w=a.walkFood&&a.walkFood[sid];if(!w)return "";const now=mxNow();
 const picks=w.names.map(n=>a.food.find(f=>f.name===n)).filter(Boolean);
 return `<section class="filters"><span class="kicker">${esc(w.label)}</span>${picks.map(f=>`<div style="display:flex;justify-content:space-between;gap:10px;align-items:baseline;border-top:1px solid var(--rule);padding-top:8px"><span style="min-width:0"><strong>${esc(f.name)}</strong> <span class="price">${PRICES[f.price-1]}</span><br><span class="hint">${esc(f.order)}</span></span>${openPill(isOpen(f,now))}</div>`).join("")}<div><button class="btn small" data-eat>All food picks →</button></div></section>`}

/* threads */
function refInfo(ref){const st=STOPIDX[ref]?getStop(ref):null;if(st)return {name:st.name,area:AD[STOPIDX[ref]].name,v:{v:"stop",id:ref},art:stopArt(ref,st)};const s=siteById(ref);if(s)return {name:s.name,area:AD[SITEIDX[ref]].name,v:{v:"more",id:ref},art:ILLCAT[s.cat]||ILLCAT.museum};return null}
function vThreads(){return `<section style="display:grid;gap:10px"><span class="kicker">Threads</span><h1>One story, several places</h1><p class="lede muted">Threads follow a single story through the areas of the guide, in the order it happened.</p></section>
 <div class="food-grid">${THREADS.map(t=>`<button class="food" style="text-align:left" data-thread="${t.id}"><div class="food-h"><b style="font-size:19px">${esc(t.name)}</b><span class="price">${t.steps.length} places</span></div><p>${esc(t.summary)}</p><p class="hint">${t.steps.map(s=>esc((refInfo(s.ref)||{}).name||"")).join(" → ")}</p></button>`).join("")}</div>`}
function vThread(){const t=THREADS.find(x=>x.id===cur().id),fn=new Footnotes();
 return `<section style="display:grid;gap:10px"><span class="kicker">Thread</span><h1>${esc(t.name)}</h1><p class="lede">${esc(t.summary)}</p></section>
 <article class="article">${LEGEND}${t.ctx?`<h2 class="lsec">Start with the big picture</h2>${t.ctx.map(id=>ctxBlockHTML(id,fn)).join("")}`:""}
 ${t.cast?`<h2 class="lsec">Who's who</h2><dl class="cast">${t.cast.map(([n,d,s])=>`<div><dt>${esc(n)}</dt><dd>${esc(d)}${fn.mark(s)}</dd></div>`).join("")}</dl>`:""}
 ${t.intro?`${t.cast?'<h2 class="lsec">The places</h2>':""}${t.intro.map(([x,s,g])=>`<p>${esc(x)}${s&&s.length?fn.mark(s)+" "+tagHTML(g):""}</p>`).join("")}`:""}</article>
 <ol class="thread">${t.steps.map((s,i)=>{const r=refInfo(s.ref);return `<li><span class="n">${i+1}</span><div style="display:grid;gap:8px;min-width:0"><span class="kicker">${esc(s.when||"")} · ${esc(r.area)}</span><h3>${esc(r.name)}</h3>${s.p.map(([x,src,g])=>`<p class="tp">${esc(x)}${fn.mark(src)} ${tagHTML(g)}</p>`).join("")}<div><button class="btn small" data-go="${r.v.v}:${r.v.id}">Go to ${esc(r.name)} →</button></div></div></li>`}).join("")}</ol>${fn.html()}`}

/* search */
function blkText(bs){const o=[];const w=b=>{if(!b)return;if(Array.isArray(b)){b.forEach(w);return}if(b.p)o.push(b.p[0]);if(b.obj){o.push(b.obj.h||"");w(b.obj.p?{p:b.obj.p}:null)}if(b.pt){o.push(b.pt.h);w(b.pt.blocks);(b.pt.more||[]).forEach(m=>w(m.blocks))}if(b.deep)w(b.deep.blocks);if(b.steps){o.push(b.steps.title);b.steps.items.forEach(i=>o.push(i[0]))}if(b.voices)o.push(...b.voices.pts);if(b.take)o.push(b.take);if(b.where)o.push(b.where)};w(bs);return o.join(" ")}
function searchIndex(){const out=[];
 for(const aid in AD){const a=AD[aid];
  for(const id in a.stops){const st=getStop(id);out.push({k:"Walk stop",name:st.name,sub:`${a.name} · ${st.summary}`,text:[st.what||"",st.spot||"",(st.find||[]).join(" "),st.summary,blkText(st.lead),blkText(st.read)].join(" "),v:{v:"stop",id},visited:S.visited.includes(id)})}
  a.sites.filter(m=>!m.link).forEach(m=>out.push({k:"Site",name:m.name,sub:`${a.name} · ${m.summary}`,text:[m.what||"",m.summary,m.types.join(" "),blkText(m.read)].join(" "),v:{v:"more",id:m.id},visited:S.visited.includes(m.id)}));
  a.food.forEach(f=>out.push({k:"Food",name:f.name,sub:`${a.name} · ${f.order}`,text:[f.order,f.types.join(" "),f.addr].join(" "),v:{eat:aid}}))}
 THREADS.forEach(t=>out.push({k:"Thread",name:t.name,sub:t.summary,text:(t.cast||[]).map(c=>c[0]+" "+c[1]).concat(t.steps.map(s=>s.p.map(p=>p[0]).join(" "))).join(" "),v:{v:"thread",id:t.id}}));
 (typeof CTX!=="undefined"?CTX:[]).forEach(c=>out.push({k:"Background",name:c.title,sub:c.era+" · "+c.one,text:blkText(c.blocks.concat(c.more||[])),v:{v:"ctx",id:c.id}}));
 for(const aid in AD){const a=AD[aid];(a.walks||[]).forEach(w=>out.push({k:"Walk",name:w.name,sub:`${a.name} · ${w.time||""}`,text:(w.intro||[]).map(p=>p[0]).join(" "),v:{v:"walkstart",w:w.id}}));(a.tours||[]).forEach(t=>out.push({k:"Museum tour",name:t.name,sub:t.summary,text:blkText(t.blocks)+" "+blkText(t.background),v:{v:"tour",id:t.id}}))}
 (typeof NIGHT!=="undefined"?NIGHT:[]).forEach(n=>out.push({k:"Night out",name:n.name,sub:n.summary||n.where||"",text:[n.kind,n.where,n.summary].join(" "),v:{v:"night",id:n.id}}));
 (GLOSSARY||[]).forEach(g=>out.push({k:"Term",name:g.term,sub:g.def[0],text:g.def[0]+" "+(g.forms||[]).join(" "),v:{v:"glossary"}}));
 Object.keys(SRC).forEach(i=>out.push({k:"Source",name:SRC[i].n,sub:SRC[i].t,text:SRC[i].t,url:SRC[i].u}));
 return out}
function searchRun(q){q=norm(q.trim());const words=q.split(/\s+/);return searchIndex().map(r=>{const n=norm(r.name),t=norm(r.text||"");let sc=0;for(const w of words){if(n.includes(w))sc+=3;else if(t.includes(w))sc+=1;else return null}return [r.k==="Source"?sc/3:sc,r]}).filter(Boolean).sort((a,b)=>b[0]-a[0]).slice(0,30)}
function searchResults(q,quiet){if(norm(q.trim()).length>=2)return `<div><button class="btn small" data-askq="${esc(q.trim())}">✦ Ask the guide: “${esc(q.trim())}”</button></div>`+searchList(q);if(norm(q.trim()).length<2)return quiet?"":`<p class="hint">Type at least two letters: a place, a name like Rivera or Coatlicue, or a food like tacos.</p>`;
 return ""}
function searchList(q){const res=searchRun(q);if(!res.length)return `<p class="empty">No places or pages match. Try asking instead.</p>`;
 return `<div class="food-grid">${res.map(([,r],i)=>r.url?`<a class="food" href="${r.url}" target="_blank" rel="noopener" style="text-decoration:none;color:inherit"><span class="pill">${r.k}</span><b style="font-family:var(--f-display);font-size:17px">${esc(r.name)}</b><span class="hint">${esc(r.sub)} ↗</span></a>`:`<button class="food" style="text-align:left" data-sr="${i}"><span class="meta"><span class="pill">${r.k}</span>${r.visited?`<span class="pill ok">Visited</span>`:""}</span><b style="font-family:var(--f-display);font-size:17px">${esc(r.name)}</b><span class="hint">${esc(r.sub)}</span></button>`).join("")}</div>`}
let searchQ="";
function vSearch(){return `<section style="display:grid;gap:10px"><span class="kicker">Search</span><h1>Find anything</h1>
 <div class="search"><label for="q" style="position:absolute;left:-9999px">Search</label><input id="q" placeholder="Rivera, Sun Stone, tacos, Moctezuma…" autocomplete="off" value="${esc(searchQ)}"></div></section><div id="results">${searchResults(searchQ)}</div>`}

function placesOf(A2){const out=[];A2.walks.forEach(w=>w.stops.forEach(id=>{const st=A2.stops[id];if(st&&!st.siteRef&&!out.some(x=>x.id===id))out.push({id,isStop:true,name:getStop(id).name,what:st.what,summary:st.summary,types:st.types||[],hours:st.hours,outdoor:st.outdoor,ta:st.ta,rec:st.rec,ll:st.ll||getStop(id).ll,area:A2})}));
 A2.sites.forEach(x=>out.push(Object.assign({},x,{area:A2})));return out}
const placeOpen=(x,n)=>x.isStop&&x.outdoor&&!x.hours?true:siteOpen(x,n);
const recS=x=>(x.rec&&x.rec.s)||0,taR=x=>(x.ta||[0,0])[0],taN=x=>(x.ta||[0,0])[1];
function rankSort(list){return list.sort((a,b)=>recS(b)-recS(a)||taR(b)-taR(a)||taN(b)-taN(a))}
function showFilter(list){const f=S.sfilt||"all";return list.filter(x=>f==="must"?recS(x)>=5:f==="high"?recS(x)>=4:f==="ta45"?taR(x)>=4.5:true)}
function showChips(){const f=S.sfilt||"all";return `<div class="frow"><span class="kicker">Show</span><div class="chips">${[["all","Everything"],["must","Must-see"],["high","Highly recommended and up"],["ta45","4.5★ and up on Tripadvisor"]].map(([k,l])=>`<button class="chip" aria-pressed="${f===k}" data-sfilt="${k}">${l}</button>`).join("")}</div></div>`}
function recHTML(r,full){if(!r)return "";const st="★".repeat(r.s)+"☆".repeat(5-r.s);
 return full?`<div class="recbox rec-${r.s}"><span class="recstars" aria-label="Guide rating ${r.s} of 5">${st}</span><span><b>${esc(r.l)}</b> · our rating</span><span class="recwhy">${esc(r.why)}</span></div>`:`<span class="rec rec-${r.s}"><span class="recstars" aria-hidden="true">${st}</span>${esc(r.l)}</span>`}
function placeCard(x,now,showArea,dist){return `<button class="site-card" ${x.isStop?`data-stop="${x.id}"`:x.link?`data-stop="${x.link}"`:`data-more="${x.id}"`}>${x.isStop?stopArt(x.id,getStop(x.id)):ILLCAT[x.cat]||ILLCAT.museum}<span class="b"><span class="n">${showArea?(x.area.id==="teo"?"DAY TRIP · TEOTIHUACAN · ":esc(x.area.name.toUpperCase())+" · "):""}${esc(x.types.join(" · ").toUpperCase())}${x.isStop||onWalk(x.id)?" · ON A WALK":""}</span><b>${esc(x.name)}</b><span class="what">${esc(x.what||x.summary)}</span>${x._why&&x._why.length?`<span class="whyrec">Why: ${esc(x._why.join(" · "))}</span>`:""}${recHTML(x.rec)}${starsHTML(x.ta)}<span class="meta">${openPill(placeOpen(x,now))}${dist!=null?`<span class="pill">${fmtDist(dist)} away</span>`:""}</span></span></button>`}
const fmtDist=d=>d<950?`${Math.max(50,Math.round(d/50)*50)} m`:`${(d/1000).toFixed(d<9500?1:0)} km`;
function vMoreList(){
 const now=mxNow();let hidden=0;
 let list=showFilter(placesOf(AR)).filter(x=>{if(S.stypes.length&&!x.types.some(t=>S.stypes.includes(t)))return false;if(S.sopen){const o=placeOpen(x,now);if(o===null){hidden++;return false}if(!o)return false}return true});
 if(S.srate)rankSort(list);
 return `<section style="display:grid;gap:8px"><span class="kicker">Every place in this guide</span><h2>Places to see in ${esc(AR.name)}</h2><p class="lede muted" style="font-size:16px">${esc(AR.moreIntro||"")}</p></section>
 <section class="filters">${showChips()}
  <div class="frow"><span class="kicker">Order</span><div class="chips"><button class="chip" aria-pressed="${!S.srate}" data-srate="0">Walk order</button><button class="chip" aria-pressed="${!!S.srate}" data-srate="1">Top rated first</button></div></div>
  <div class="frow"><span class="kicker">When</span><div class="chips"><button class="chip open" aria-pressed="${S.sopen}" data-sopen>Open now · ${esc(now.label)} CDMX</button></div></div>
  <div class="frow"><span class="kicker">Type</span><div class="chips">${STYPES.map(t=>`<button class="chip" aria-pressed="${S.stypes.includes(t)}" data-f="stypes" data-v="${esc(t)}">${esc(t)}</button>`).join("")}</div></div>
  ${(S.stypes.length||S.sopen||(S.sfilt&&S.sfilt!=="all"))?`<div><button class="btn small" data-sclear>Clear filters</button></div>`:""}
  <p class="hint">Our rating weighs historical importance, what you actually see, and the visit itself. Visitor stars are Tripadvisor's, checked November 2026.</p></section>
 ${hidden?`<p class="hint">${hidden} place${hidden>1?"s are":" is"} hidden because ${hidden>1?"their hours aren't":"its hours aren't"} published.</p>`:""}
 ${list.length?"":`<p class="empty">Nothing matches. Try removing a filter.</p>`}
 <div class="site-grid">${list.map(x=>placeCard(x,now,false)).join("")}</div>
 <p class="hint">Checked ${CHECKED}.</p>`}
let TSORTMSG="";
function vTopPlaces(){const now=mxNow();let list=[];for(const aid in AD)list=list.concat(placesOf(AD[aid]));
 const seen=new Set();list=list.filter(x=>{const k=x.link||x.id;if(seen.has(k))return false;seen.add(k);return true});
 list=rankSort(showFilter(list.filter(x=>x.rec||x.ta)));
 const ts=S.tsort||"sig",here=S.here&&S.here.ll,dOf=x=>here&&x.ll?hav(here,x.ll):null;let note="Ranked by our rating, then by Tripadvisor visitors.";
 if(ts==="sig"){list.sort((a,b)=>recScore(b)-recScore(a));list.forEach(x=>x._why=recReasons(x));note="What matters most, not what's most popular: how many of the guide's stories a place belongs to, the guide's own judgment, your interests and, if you've set it, how close you are. Each card says why it's here."}
 else if(ts==="near"){if(here){list.forEach(x=>x._d=dOf(x));list.sort((a,b)=>(a._d??1e12)-(b._d??1e12));note=`Closest first, measured straight-line from ${esc(S.here.label||"your location")}. Walking distance runs longer.`}else note=TSORTMSG||"Getting your location…"}
 else if(ts==="reviews"){list.sort((a,b)=>taN(b)-taN(a)||recS(b)-recS(a));note="Most Tripadvisor reviews first: a rough measure of how busy a place gets."}
 else if(ts==="open"){const r=x=>{const o=placeOpen(x,now);return o===true?0:o===null?1:2};list.sort((a,b)=>r(a)-r(b));note=`Open right now first (${esc(now.label)} CDMX), then places with unpublished hours, then closed. Rating order within each group.`}
 else if(ts==="az"){list.sort((a,b)=>a.name.localeCompare(b.name,"es"));note="Alphabetical by name."}
 note+=" Places marked Day trip are at Teotihuacan, about an hour northeast of the city, and need their own day.";
 const n=S.topAll?list.length:Math.min(12,list.length);
 return `<section class="filters" id="topplaces"><h2>Places worth understanding</h2>
 <div class="frow"><span class="kicker">Sort by</span><div class="chips">${[["sig","Why it matters"],["rated","Guide and visitor ratings"],["near","Closest to me"],["open","Open now first"],["reviews","Most reviewed"],["az","A–Z"]].map(([k,l])=>`<button class="chip" aria-pressed="${ts===k}" data-tsort="${k}">${l}</button>`).join("")}</div></div>
 <p class="hint">${note}</p>${ts==="near"&&here?`<div><button class="btn small" data-tsort="near" data-refresh="1">Update my location</button></div>`:""}${showChips()}
 <div class="site-grid">${list.slice(0,n).map(x=>placeCard(x,now,true,ts==="near"&&here?dOf(x):null)).join("")}</div>
 ${list.length>n?`<div><button class="btn" data-topall>Show all ${list.length}</button></div>`:""}</section>`}
const onWalk=id=>Object.values(AD).some(a=>a.walks.some(w=>w.stops.some(s=>s===id||(a.stops[s]&&a.stops[s].siteRef===id))));
function vMore(){return placePage("site",cur().id)}
function ptArticle(b,fn){const t=b.pt;return `<h3>${t.when?`<span class="when">${esc(t.when)}</span>`:""}<span>${esc(t.h)}</span></h3>${t.blocks.map(x=>blockHTML(x,fn)).join("")}${(t.more||[]).map(m=>`<details class="ptmore"><summary>${m.label==="More"?"More":"More: "+esc(m.label)}</summary>${m.blocks.map(x=>blockHTML(x,fn)).join("")}</details>`).join("")}`}
function firstSentence(blocks){for(const b of blocks||[]){const p=b.p||(b.pt&&((b.pt.blocks.find(x=>x.p)||{}).p));if(p){const t=p[0];const m=t.match(/^.{20,}?[.!?](\s|$)/);return (m?m[0]:t).trim()}}return ""}
function artCard(cls,icon,title,teaser,body,open){if(!body)return "";return `<details class="art ${cls}"${open?" open":""}><summary><span class="ai" aria-hidden="true">${icon}</span><span class="at"><b>${esc(title)}</b>${teaser?`<span>${esc(teaser)}</span>`:""}</span></summary><div class="artb">${body}</div></details>`}
function placePageOld(kind,id){
 const fn=new Footnotes(),now=mxNow();
 const st=kind==="stop"?getStop(id):siteById(id);
 const site=kind==="stop"?(st.siteRef?siteById(st.siteRef):null):st;
 const area=AD[kind==="stop"?STOPIDX[id]:SITEIDX[id]];
 const L=(kind==="stop"?(st.lead||st.read):st.read)||[];
 const P={story:[],look:[],plain:[],ctx:[],prac:[],route:[],after:[],where:null};let sec=null;
 L.forEach(b=>{if(b.sec){sec=b.sec;return}if(b.where){P.where=b;return}if(b.ctx){P.ctx.push(b.ctx);return}
  if(sec==="Before you go in"){P.prac.push(b);return}if(sec==="Your route"){P.route.push(b);return}if(sec==="After"){P.after.push(b);return}
  if(b.pt){(b.pt.look?P.look:P.story).push(b);return}if(b.gobtns)return;P.plain.push(b)});
 if(kind==="stop"&&st.read&&st.read!==st.lead){(st.read||[]).forEach(b=>{if(b.pt&&!L.some(x=>x.pt&&x.pt.h===b.pt.h))(b.pt.look?P.look:P.story).push(b)})}
 P.story.sort((a,b)=>(a.pt.ord??99)-(b.pt.ord??99));
 const more=(kind==="stop"?st.more:[])||[];
 // where it is on a walk
 let walkBtn="";for(const w of area.walks){const ws=walkStops(w);const j=ws.findIndex(s=>s===id||(area.stops[s]&&area.stops[s].siteRef===id));if(j>=0){walkBtn=`<button class="btn small" data-walk="${w.id}" data-step="${j}">On a walk: ${esc(w.name||"walk")}, stop ${j+1} →</button>`;break}}
 // intro
 const hrsX=st.hours?st:site&&site.hours?site:null;
 const open=hrsX?siteOpen(hrsX,now):(st.outdoor?true:null);
 const cost=(site&&site.cost)||st.cost;
 const timeNeed=st.time||(kind==="site"?fmtDur(visitMins({id})/60):"");
 const take=st.take||(site&&site.take);
 const facts=[["Area",area.id==="teo"?"Day trip · Teotihuacan":area.name],timeNeed&&["Time needed",timeNeed],["Right now",hrsX?(open?"Open now":"Closed now"):st.outdoor?"Open-air":"Hours not published"],cost&&["Cost",cost.split(/[.;]/)[0]]].filter(Boolean);
 const intro=`<section class="hero">${kind==="stop"?stopArt(id,st):(ILLCAT[st.cat]||ILLCAT.museum)}<div class="hero-body"><span class="illus-note">${st.photos?`<a href="${st.photos}" target="_blank" rel="noopener">See real photos ↗</a>`:""}</span><span class="kicker">${esc((st.types||(site&&site.types)||[]).join(" · "))}</span><h1>${esc(st.name)}</h1></div></section>
 <section class="pintro"><p class="lede">${esc(st.summary||st.what||"")}</p>
 ${recHTML(st.rec,true)}${starsHTML(st.ta,true)}
 <div class="facts">${facts.map(([k,v])=>`<div class="fact"><span class="k">${esc(k)}</span><span class="v">${esc(v)}</span></div>`).join("")}</div>
 <div class="pacts"><button class="btn small" data-askabout="${id}">Ask about this place</button>${walkBtn}</div>${threadChips(id)}</section>`;
 // article: history
 const histBlocks=P.story.length?P.story:P.plain.length&&!P.look.length?P.plain:[];
 const whens=P.story.map(b=>b.pt.when).filter(Boolean);
 const histTeaser=(P.story.length?`${P.story.length} ${P.story.length===1?"part":"parts"}${whens.length>1?`, ${whens[0]} to ${whens[whens.length-1]}`:whens.length?`, ${whens[0]}`:""}. `:"")+firstSentence(histBlocks);
 const hist=histBlocks.length?histBlocks.map(b=>b.pt?ptArticle(b,fn):blockHTML(b,fn)).join("")+(take&&!P.look.length?blockHTML({take},fn):""):"";
 // article: what you'll see
 const otherPlain=histBlocks===P.plain?[]:P.plain;
 const findL=st.find&&st.find.length?`<h3><span>Look for</span></h3><ul class="findlist2">${st.find.map(t=>`<li>${esc(t)}</li>`).join("")}</ul>`:"";
 const seeBody=[findL,P.look.map(b=>ptArticle(b,fn)).join(""),otherPlain.map(b=>blockHTML(b,fn)).join(""),P.route.length?`<h3><span>A route through it</span></h3>${P.route.map(b=>blockHTML(b,fn)).join("")}`:"",tourCard(st),take&&P.look.length?blockHTML({take},fn):"",more.length?`<h3><span>Nearby, if you have time</span></h3>${more.map(b=>blockHTML(b,fn)).join("")}`:""].join("");
 const seeTeaser=P.look.length?P.look.map(b=>b.pt.h).join(" · "):st.find&&st.find.length?st.find[0]:firstSentence(otherPlain);
 const see=seeBody.replace(/\s/g,"")?seeBody:"";
 // article: background
 const ctxs=P.ctx.map(c=>ctxById(c)).filter(Boolean);
 const bg=ctxs.length?`<p class="hint" style="font-size:15px">The wider history this place belongs to. Each opens on its own.</p>${P.ctx.map(c=>ctxBlockHTML(c,fn)).join("")}`:"";
 // article: plan your visit
 const mapQ=encodeURIComponent(st.name+" "+((site&&site.addr)||"")+" Ciudad de México");
 const plan=`<div class="kv"><div class="meta">${openPill(hrsX?siteOpen(hrsX,now):st.outdoor?true:null)}</div>
  <p><strong>Hours:</strong> ${hrsX?esc(siteHours(hrsX))+(hrsX.hsrc?" "+srcTag([hrsX.hsrc]):""):st.outdoor?"Open-air, no set hours.":"Hours not published; check before you go."}</p>${site&&site.hoursNote?`<p class="hint">${esc(site.hoursNote)}</p>`:""}
  ${cost?`<p><strong>Cost:</strong> ${esc(cost)}</p>`:""}
  ${timeNeed?`<p><strong>Time needed:</strong> ${esc(timeNeed)}</p>`:""}
  <p><strong>Where:</strong> ${site&&site.addr?esc(site.addr)+" · ":""}<a href="https://www.google.com/maps/search/?api=1&query=${mapQ}" target="_blank" rel="noopener">Map ↗</a> · <a href="${dirURL(kind==="stop"?st:Object.assign({},st,{ll:st.ll}))}" target="_blank" rel="noopener">Directions ↗</a></p>
  ${P.where?`<p><strong>Where to stand:</strong> ${esc(P.where.where)}</p>`:""}${st.spot?`<p><strong>How to spot it:</strong> ${esc(st.spot)}</p>`:""}</div>
  ${P.prac.map(b=>blockHTML(b,fn)).join("")}
  ${P.after.map(b=>blockHTML(b,fn)).join("")}
  ${st.voices?voicesHTML(st.voices):""}${st.pick?pickHTML(st.pick):""}`;
 const planTeaser=[hrsX?siteHours(hrsX):st.outdoor?"Open-air":"",cost?cost.split(/[.;]/)[0]:"",st.voices?"what visitors say":""].filter(Boolean).join(" · ");
 const arts=[artCard("hist","📜",P.story.length?"The history":"About this place",histTeaser,hist),
  artCard("see","👁","What you'll see",seeTeaser,see),
  artCard("bg","🧭","The bigger story",ctxs.map(c=>c.title).join(" · "),bg),
  artCard("plan","🗺","Plan your visit",planTeaser||"Hours, cost, getting there",plan)].join("");
 return `${intro}<section class="arts"><span class="kicker">Read more</span>${arts}${LEGEND}</section>${fn.html()}`}

function render(){PTN=0;{const v0=cur().v,ar=["area","stop","more","walk","walkstart","tour"].includes(v0)&&AR?AR.id:null;document.documentElement.style.setProperty("--line",ar&&LINECOL[ar]?LINECOL[ar]:"var(--accent)");document.documentElement.dataset.view=v0}if(typeof TM!=="undefined")for(const k in TM)delete TM[k];topbar();if(typeof closeTermSheet==="function")closeTermSheet();const v=cur().v;if(v!=="explore"&&typeof LMAP!=="undefined"&&LMAP){LMAP.remove();LMAP=null}$("#main").innerHTML={howknow:vHowKnow,editorial:vEditorial,home:vHome,story:vStory,question:vQuestion,time:vTime,museums:vMuseums,museum:vMuseum,field:vField,near:vNear,journal:vJournal,mission:vMission,areas:vAreas,area:vArea,walk:vWalk,stop:vStop,more:vMore,sources:vSources,search:vSearch,threads:vThreads,thread:vThread,trip:vTrip,build:vBuild,season:vSeason,basics:vBasics,day:vDay,itin:vItin,itday:vItday,ask:vAsk,explore:vExplore,learn:vLearnHub,tour:vTour,glossary:vGlossary,night:vNight,walkstart:vWalkStart,ctx:vCtx}[v]();if(v==="explore")initHomeMap();if(v==="areas")startNowTimer();if(v==="journal"||v==="mission")jPhotoFill();if(v==="trip")runPhoneCheck();if(typeof afterRender==="function")afterRender()}

/* ===================== EVENTS ===================== */
const areaV=()=>({v:"area",a:AR.id});
document.addEventListener("click",e=>{
 const el=e.target.closest("button");if(!el)return;const d=el.dataset;
 if(d.nav){nav({trip:{v:"trip"},learn:{v:"learn"},explore:{v:"explore"},stories:{v:"home"},field:{v:"field"},journal:{v:"journal"},around:{v:"areas"},today:{v:"areas"}}[d.nav]||{v:"home"});return}
 if(el.hasAttribute("data-back")){back();return}
 if(d.area){useArea(d.area);areaTab="see";nav(areaV());return}
 if(d.tab){areaTab=d.tab;nav(areaV());return}
 if(d.walk){nav({v:"walk",w:d.walk,i:d.step!==undefined?+d.step:0});return}
 if(d.stop){nav({v:"stop",id:d.stop});return}
 if(d.more){nav({v:"more",id:d.more});return}
 if(d.thread){nav({v:"thread",id:d.thread});return}
 if(d.tour){nav({v:"tour",id:d.tour});return}
 if(d.go){const [v,id]=d.go.split(":");nav(id?{v,id}:{v});return}
 if(el.hasAttribute("data-sopen")){S.sopen=!S.sopen;save();render();return}
 if(el.hasAttribute("data-sclear")){S.stypes=[];S.sopen=false;S.sfilt="all";save();render();return}
 if(d.mode){S.mode=d.mode;save();render();return}
 if(d.learnby){S.learnBy=d.learnby;save();render();return}
 if(d.ltheme){S.learnTheme=d.ltheme;S.learnLens="all";S.learnOpen="";save();const y=scrollY;render();scrollTo(0,y);return}
 if(d.llens){S.learnLens=d.llens;save();const y=scrollY;render();scrollTo(0,y);return}
 if(d.lcell){const [eid,lk]=d.lcell.split(":");S.learnLens=lk||"all";S.learnOpen=eid;save();render();const t=document.getElementById("thx-"+eid);if(t)t.scrollIntoView({behavior:matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth",block:"start"});return}
 if(d.learnarea!==undefined){S.learnArea=d.learnarea;save();nav({v:"learn"});if(cur().v==="learn")render();return}
 if(d.askq){startAsk(d.askq,null);return}
 if(d.jump){const el=document.getElementById(d.jump);if(el){const det=el.closest("details");if(det)det.open=true;el.scrollIntoView({behavior:matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth",block:"start"})}return}
 if(d.sfilt){S.sfilt=d.sfilt;save();const y=scrollY;render();scrollTo(0,y);return}
 if(d.tsort){const y=scrollY;S.tsort=d.tsort;TSORTMSG="";save();
  if(d.tsort==="near"&&(!S.here||d.refresh)){if(!navigator.geolocation){TSORTMSG="This browser can't share your location. Set where you are on the Today screen instead.";render();scrollTo(0,y);return}
   render();scrollTo(0,y);navigator.geolocation.getCurrentPosition(pos=>{const y2=scrollY;setHere([pos.coords.latitude,pos.coords.longitude],"your location",true);render();scrollTo(0,y2)},
   ()=>{const y2=scrollY;TSORTMSG="Location isn't available. Allow location for this site in your phone's settings, or set where you are on the Today screen.";render();scrollTo(0,y2)},{enableHighAccuracy:true,timeout:10000});return}
  render();scrollTo(0,y);return}
 if(el.hasAttribute("data-topall")){S.topAll=true;const y=scrollY;render();scrollTo(0,y);return}
 if(d.srate!==undefined){S.srate=d.srate==="1";save();render();return}
 if(d.fork){S.forks[d.fork]=d.val;save();render();return}
 if(d.refork){delete S.forks[d.refork];save();render();return}
 if(d.route){S.route[d.route]=d.val==="yes";save();render();return}
 if(d.reroute){delete S.route[d.reroute];save();render();return}
 if(el.hasAttribute("data-open")){S.open=!S.open;save();render();return}
 if(d.f){const arr=S[d.f],v=d.f==="price"?+d.v:d.v,k=arr.indexOf(v);k>=0?arr.splice(k,1):arr.push(v);save();render();return}
 if(el.hasAttribute("data-clear")){S.price=[];S.types=[];S.meals=[];S.mood=[];S.open=false;save();render();return}
 if(el.hasAttribute("data-eat")){areaTab="eat";nav(areaV());return}
 if(el.hasAttribute("data-search")){nav({v:"search"});setTimeout(()=>{const q=document.getElementById("q");if(q)q.focus()},50);return}
 if(d.sr!==undefined){const r=(searchRun(searchQ)[+d.sr]||[])[1];if(!r)return;if(r.v.eat){useArea(r.v.eat);areaTab="eat";nav(areaV())}else{if(r.v.v==="walkstart"&&WALKIDX[r.v.w])useArea(WALKIDX[r.v.w]);nav(r.v)}return}
});
document.addEventListener("input",e=>{if(e.target.id==="q"){searchQ=e.target.value;const r=document.getElementById("results");if(r)r.innerHTML=searchResults(searchQ,cur().v==="areas")}});
document.addEventListener("change",e=>{const t=e.target;
 if(t.id==="tripStart"&&t.value){S.start=t.value;save();render();return}
 if(t.dataset&&t.dataset.book){const k=S.book.indexOf(t.dataset.book);k>=0?S.book.splice(k,1):S.book.push(t.dataset.book);save();render();return}});
document.addEventListener("submit",e=>{if(e.target.id==="learnAsk"){e.preventDefault();const q=$("#lq").value.trim();if(q)startAsk(q,null);return}if(e.target.id!=="whereForm")return;e.preventDefault();
 const q=norm($("#where").value.trim()),msg=$("#whereMsg");
 if(!q){msg.textContent="Type a place, like the Zócalo or Chapultepec.";return}
 const pin=q.length>=3?mapPins().find(p=>{const n=norm(p.name);return n.includes(q)||q.includes(n)}):null;
 if(pin){setHere(pin.ll,pin.name);return}
 const hit=AREAS.find(a=>a.land.some(l=>q.includes(l)||l.includes(q)));
 if(!hit){msg.textContent="No match yet. Try a landmark like the Zócalo, Bellas Artes or Chapultepec, or tap a pin and choose I'm here.";return}
 if(!AD[hit.id]){msg.textContent=`That's ${hit.name}. Its guide is coming next.`;return}
 setHere(hit.c,hit.name)});

/* ITIN */

/* ===================== ITINERARY =====================
   A preliminary day-by-day plan for Dec 31 – Jan 7, built from the walks, sites, food picks and
   sample days in this guide. Every day can be edited: change times and notes, remove or add items,
   swap in a sample day, and track reservations (To book / Booked, with confirmation details).
   Edits are saved in S.itin (copy-on-write over the draft below), so they sync like the rest of
   your progress. Refs: stop:id, site:id, walk:id, night:id, food:area:Name; "" = your own item. */
const ITIN_DRAFT={
"2026-12-31":{title:"Arrive, Roma on foot, New Year's Eve",why:"An easy first day: the Roma walk is all outdoors, so holiday hours don't matter, and the night is for dinner and the twelve grapes.",items:[
 ["12:00","","Arrive and check in","See City basics for the airport, taxis and altitude.",""],
 ["15:00","walk:romawalk","","Outdoors, about two hours. A gentle start at 2,240 meters.",""],
 ["17:30","","Rest","The altitude hits hardest on the first day.",""],
 ["20:30","food:roma:Rosetta","","New Year's Eve dinner. Ask whether it's a set menu that night and what time seatings are.","need"],
 ["23:45","","Twelve grapes at midnight","One grape for each chime. See the Holiday season page.",""]]},
"2027-01-01":{title:"New Year's Day: monuments and Tlatelolco",why:"Most museums are reported closed today, so this day is built on outdoor places. Expect a slow, quiet morning and confirm anything with a door.",items:[
 ["11:00","walk:reformawalk","","The monuments are outdoors, so the closures don't touch this walk.",""],
 ["13:30","food:roma:Contramar","","Lunch. Confirm it's open on Jan 1 when you book.","need"],
 ["15:30","stop:zona","","INAH lists the zone daily 9:00–17:00; holiday opening isn't confirmed. The Memorial del 68 may be shut.",""],
 ["16:15","stop:plaza","","The Plaza de las Tres Culturas, beside the zone.",""],
 ["20:30","night:lucha","","Friday is the big card. Confirm a show runs on New Year's Day before buying.","need"]]},
"2027-01-02":{title:"San Ángel's Saturday, then Coyoacán",why:"Saturday is the day for San Ángel: the artists' market fills Plaza San Jacinto. Coyoacán is a short taxi south-east.",items:[
 ["10:00","walk:sanangelwalk","","The Bazar Sábado and the artists in the square are only here on Saturdays.",""],
 ["13:30","food:sanangel:San Ángel Inn","","Lunch. Book through the restaurant's site.","need"],
 ["15:30","stop:casaazul","","Timed tickets, bought ahead at boletos.museofridakahlo.org.mx. Closes at 18:00.","need"],
 ["17:00","stop:hidalgo","","Coyoacán's square at dusk. The Trotsky museum closes at 17:00; swap the order if you'd rather see it.",""],
 ["17:45","food:coyo:Tostadas Coyoacán (Mercado de Coyoacán)","","An early supper; the market runs until about 19:00.",""]]},
"2027-01-03":{title:"Volcano and canals: the South",why:"Cuicuilco is older than Teotihuacan; Xochimilco is what's left of the lake. Sunday is free museum day for Mexican citizens, so expect crowds.",items:[
 ["9:30","stop:cuicuilco","","Opens at 9:00; closed Mondays.",""],
 ["11:30","stop:nativitas","","A trajinera from Nativitas. Agree the price per hour before you board.",""],
 ["14:00","food:south:Mercado de Xochimilco","","Lunch at the market; hours aren't published.",""],
 ["15:30","site:olmedo","","Optional: the Dolores Olmedo museum, open daily 10:00–18:00.",""],
 ["19:30","","Dinner near your hotel","An easy evening. Rosetta is closed on Sundays.",""]]},
"2027-01-04":{title:"A day at Teotihuacan",sample:"teo",why:"Monday closes most of the city's museums, but Teotihuacan is open every day, so this is its day.",extra:{"food:teo:La Gruta":"need"}},
"2027-01-05":{title:"Chapultepec: castle and museum",sample:"chapul",why:"Both big museums are open Tuesday. Navidades en México, the Ballet Folklórico's Christmas show at the castle, runs about Dec 15 – Jan 12; check whether there's an evening performance.",extra:{"food:chapul:Quintonil":"need","stop:castillo":"need"}},
"2027-01-06":{title:"Día de Reyes: Tenochtitlan and the Ballet Folklórico",why:"Three Kings' Day. The Centro museums are open Wednesday, and the Ballet Folklórico plays Bellas Artes on Wednesday night, a short walk from the Zócalo.",items:[
 ["8:30","food:centro:El Cardenal (Palma)","","Breakfast; it opens at 8:00.",""],
 ["9:15","stop:zocalo","","Start in the square.",""],
 ["9:40","stop:montepiedad","","",""],
 ["10:00","stop:templo","","Ruins first, then the museum: about 2.5 hours.",""],
 ["12:45","stop:catedral","","",""],
 ["13:30","food:centro:Azul Histórico","","Lunch; the kitchen reopens at 13:00.",""],
 ["15:00","stop:palacio","","Closes at 16:00. Email visitas_guiadas@hacienda.gob.mx to confirm how to visit on your date.","need"],
 ["17:00","","Rosca de Reyes and hot chocolate","The day ends with the Kings' bread. Whoever finds the hidden figure hosts on Feb 2.",""],
 ["18:30","food:centro:Café de Tacuba","","An early dinner before the show; hours aren't confirmed.",""],
 ["20:30","night:ballet","","Bellas Artes, about two hours. Book ahead on Ticketmaster or at the box office.","need"]]},
"2027-01-07":{title:"Departure: Zócalo to the Alameda",why:"A half day along Madero to Bellas Artes, then the airport. Cut it to fit your flight.",items:[
 ["9:00","food:centro:El Rey del Pavo","","A turkey torta to start.",""],
 ["10:00","stop:granhotel","","",""],
 ["10:20","stop:iturbide","","",""],
 ["10:45","stop:azulejos","","",""],
 ["11:20","stop:torre","","Optional: the observation deck.",""],
 ["12:15","stop:postal","","Open until 16:00 on weekdays.",""],
 ["12:30","stop:bellas","","Murals on the upper floors.",""],
 ["14:00","","Leave for the airport","Adjust to your flight time.",""]]}};
const ITKIND={stop:"Walk stop",site:"Site",walk:"Walk",night:"Evening",food:"Food"};
let ITEDIT=null;
const isoOf=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
function tripLen(){const a=new Date(S.start+"T12:00:00"),b=new Date((S.end||S.start)+"T12:00:00");const n=Math.round((b-a)/864e5)+1;return isFinite(n)?Math.max(1,Math.min(21,n)):5}
function tripIdx(){return [...Array(tripLen()).keys()]}
const hmOf=t=>{const[h,m]=String(t||"0").split(":").map(Number);return (h||0)+(m||0)/60};
function draftDay(iso){const D=ITIN_DRAFT[iso];if(!D)return null;
 let items;
 if(D.sample){const sd=DAYS.find(x=>x.id===D.sample);items=sd?sd.steps.map(([t,ref,note])=>{const r=ref?(ref.startsWith("food:")?"food:"+sd.area+":"+ref.slice(5):ref):"";return [t,r,ref?"":(/back/i.test(note)?"Getting back":"Getting there"),note||"",(D.extra||{})[r]||""]}):[]}
 else items=D.items;
 return {title:D.title,why:D.why,items:items.map(([t,ref,title,note,res],i)=>({id:"d"+i,t,ref,title,note,res,conf:""}))}}
function itinDay(iso){return (S.itin||{})[iso]||draftDay(iso)||{title:"",why:"",items:[]}}
function itinEdit(iso,fn){const d=JSON.parse(JSON.stringify(itinDay(iso)));fn(d);d.items.sort((a,b)=>hmOf(a.t)-hmOf(b.t));S.itin=S.itin||{};S.itin[iso]=d;save();render()}
function resolveItem(ref){if(!ref)return null;const i=ref.indexOf(":"),k=ref.slice(0,i),v=ref.slice(i+1);
 if(k==="stop"){const st=getStop(v);return st?{name:st.name,btn:`data-stop="${v}"`,kind:ITKIND.stop}:null}
 if(k==="site"){const s=siteById(v);return s?{name:s.name,btn:`data-more="${v}"`,kind:ITKIND.site}:null}
 if(k==="walk"){const w=walkById(v);return w?{name:w.name,btn:`data-walk="${v}"`,kind:ITKIND.walk}:null}
 if(k==="night"){const n=nightById(v);return n?{name:n.name,btn:`data-night="${v}"`,kind:ITKIND.night}:null}
 if(k==="food"){const j=v.indexOf(":"),area=v.slice(0,j),name=v.slice(j+1),f=AD[area]&&AD[area].food.find(x=>x.name===name);return f?{name:f.name,btn:`data-eatarea="${area}"`,kind:ITKIND.food,f}:{name,btn:"",kind:ITKIND.food}}
 return null}
const itName=it=>it.title||((resolveItem(it.ref)||{}).name)||"Untitled";
function resPill(it){return it.res==="booked"?`<span class="pill ok">Booked${it.conf?" · "+esc(it.conf):""}</span>`:it.res==="need"?`<span class="pill warn">To book</span>`:""}
function dayAlertsHTML(di){const ev=seasonFor(di.k);
 const closed=Object.values(AD).flatMap(a=>(a.closures||[]).filter(c=>c.lvl==="no"&&((c.dows&&c.dows.includes(di.dow))||(c.dates&&c.dates.includes(di.k)))).map(c=>a.name));
 return `${ev.length?`<span class="hint">${ev.map(e=>`<span class="pill warn">Season</span> ${esc(e.name)}`).join(" ")}</span>`:""}
 ${closed.length?`<span class="hint"><span class="pill no">Closures</span> Main museums closed in ${esc([...new Set(closed)].join(", "))}.</span>`:""}
 ${Object.values(AD).flatMap(a=>(a.closures||[]).filter(c=>c.lvl==="warn"&&c.dates&&c.dates.includes(di.k)).map(c=>`<span class="hint"><span class="pill warn">Holiday hours</span> ${esc(a.name)}: ${esc(c.t)}</span>`)).join("")}`}
function allBookings(){return tripIdx().flatMap(i=>{const di=dayInfo(i),iso=isoOf(di.d);return itinDay(iso).items.filter(x=>x.res).map(x=>({it:x,iso,i,di}))})}
function itinCardHTML(){const B=allBookings(),done=B.filter(b=>b.it.res==="booked").length,a=dayInfo(0),z=dayInfo(tripLen()-1);
 return `<button class="area-card" data-itin style="min-height:0"><span class="badge live">${esc(a.label)} – ${esc(z.label)}</span><b>Your itinerary</b><span>${tripLen()} days, editable. ${B.length?`${done} of ${B.length} reservations booked.`:"No reservations marked yet."}</span></button>`}
function vItin(){const B=allBookings();
 return `<section style="display:grid;gap:8px"><span class="kicker">Your trip · ${tripLen()} days</span><h1>Itinerary</h1><p class="lede muted">A preliminary plan built from this guide's walks, opening hours and holiday closures. Change anything: tap a day to edit times, add your own plans, swap in a sample day, and track reservations.</p></section>
 <section class="filters"><div style="display:flex;justify-content:space-between;align-items:baseline;gap:10px"><span class="kicker">Reservations</span><span class="hint">${B.filter(b=>b.it.res==="booked").length} of ${B.length} booked</span></div>
  ${B.length?`<div style="display:grid;gap:10px">${B.map(b=>`<div style="display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;border-top:1px solid var(--rule);padding-top:8px"><div style="min-width:0"><b>${esc(itName(b.it))}</b><div class="hint">${esc(b.di.label)} · ${esc(b.it.t)} ${resPill(b.it)}</div></div><button class="btn small" data-itday="${b.iso}" data-itfocus="${b.it.id}">${b.it.res==="booked"?"Details":"Book"}</button></div>`).join("")}</div>`:`<p class="hint">Mark any item "To book" and it shows up here.</p>`}</section>
 <div class="food-grid">${tripIdx().map(i=>{const di=dayInfo(i),iso=isoOf(di.d),d=itinDay(iso),edited=!!(S.itin||{})[iso],nb=d.items.filter(x=>x.res==="need").length;
  return `<button class="food" style="text-align:left" data-itday="${iso}"><div class="food-h"><b style="font-size:18px">Day ${i+1} · ${esc(di.label)}</b>${edited?`<span class="pill">Edited</span>`:""}</div><p>${esc(d.title||"Nothing planned yet")}</p><p class="hint">${d.items.length?d.items.slice(0,4).map(x=>esc(x.t+" "+itName(x))).join(" · ")+(d.items.length>4?" …":""):"Tap to add plans or a sample day."}</p>${nb?`<span class="pill warn" style="justify-self:start">${nb} to book</span>`:""}</button>`}).join("")}</div>
 <p class="hint">Times come from published opening hours; holiday hours around Dec 31, Jan 1 and Jan 6 often aren't published, so confirm anything with a door the day before.</p>`}
const itInput=`font:inherit;font-size:16px;color:var(--ink);background:var(--paper);border:1px solid var(--rule);border-radius:10px;padding:8px 10px;width:100%;min-width:0`;
function itFormHTML(iso,it){const r=resolveItem(it.ref);
 return `<form class="itform" data-itiso="${iso}" data-itid="${it.id}" style="display:grid;gap:8px;margin-top:6px">
  <div style="display:grid;grid-template-columns:110px 1fr;gap:8px"><input name="t" type="time" value="${esc(String(it.t).padStart(5,"0"))}" style="${itInput}" aria-label="Time"><input name="title" value="${esc(it.title||"")}" placeholder="${esc(r?r.name:"What")}" style="${itInput}" aria-label="Name"></div>
  <textarea name="note" rows="2" placeholder="Notes" style="${itInput}">${esc(it.note||"")}</textarea>
  <div style="display:grid;grid-template-columns:140px 1fr;gap:8px"><select name="res" style="${itInput}" aria-label="Reservation"><option value="" ${!it.res?"selected":""}>No booking</option><option value="need" ${it.res==="need"?"selected":""}>To book</option><option value="booked" ${it.res==="booked"?"selected":""}>Booked</option></select><input name="conf" value="${esc(it.conf||"")}" placeholder="Confirmation, time, party size" style="${itInput}" aria-label="Booking details"></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button type="submit" class="btn small primary">Save</button><button type="button" class="btn small" data-itcancel>Cancel</button><button type="button" class="btn small" data-itdel="${it.id}" data-itiso="${iso}" style="margin-left:auto;color:var(--no)">Remove</button></div></form>`}
function vItday(){const iso=cur().iso,idx=tripIdx().find(i=>isoOf(dayInfo(i).d)===iso),di=idx!=null?dayInfo(idx):null,d=itinDay(iso),edited=!!(S.itin||{})[iso];
 const fits=di?daysFitting(di):[];
 const label=di?`Day ${idx+1} · ${di.label}`:iso;
 return `<section style="display:grid;gap:8px"><span class="kicker">Itinerary · ${esc(label)}</span>
  ${ITEDIT==="__title"?`<form class="itform" data-ittitle="${iso}" style="display:grid;gap:8px"><input name="title" value="${esc(d.title||"")}" placeholder="Name this day" style="${itInput}"><div><button class="btn small primary" type="submit">Save</button> <button class="btn small" type="button" data-itcancel>Cancel</button></div></form>`:`<h1>${esc(d.title||"Nothing planned yet")}</h1><div><button class="linkbtn" data-itrename>Rename day</button></div>`}
  ${d.why?`<p class="lede">${esc(d.why)}</p>`:""}${di?dayAlertsHTML(di):""}</section>
 <ol class="thread dayline">${d.items.map(it=>{const r=resolveItem(it.ref);
  return `<li id="it-${it.id}"><span class="n">${esc(it.t)}</span><div style="display:grid;gap:4px;min-width:0"><span class="kicker">${r?r.kind:"Your plan"}</span><h3>${esc(itName(it))}</h3>${it.note?`<p class="hint">${esc(it.note)}</p>`:""}${r&&r.f?`<p class="hint">${esc(hoursText(r.f))}</p>`:""}${it.res?`<div>${resPill(it)}</div>`:""}
   ${ITEDIT===it.id?itFormHTML(iso,it):`<div style="display:flex;gap:8px;flex-wrap:wrap">${r&&r.btn?`<button class="btn small" ${r.btn}>Open →</button>`:""}<button class="btn small" data-itedit="${it.id}">Edit</button>${it.res==="need"?`<button class="btn small" data-itbooked="${it.id}" data-itiso="${iso}">Mark booked</button>`:""}</div>`}</div></li>`}).join("")}</ol>
 ${d.items.length?"":`<p class="empty">Nothing planned for this day yet.</p>`}
 <section class="filters"><span class="kicker">Add to this day</span>
  <form class="itform" data-itnew="${iso}" style="display:grid;gap:8px"><div style="display:grid;grid-template-columns:110px 1fr;gap:8px"><input name="t" type="time" value="12:00" style="${itInput}" aria-label="Time"><input name="title" placeholder="What: a meal, a tour, a show" required style="${itInput}" aria-label="What"></div>
  <textarea name="note" rows="2" placeholder="Notes (optional)" style="${itInput}"></textarea>
  <div style="display:grid;grid-template-columns:140px 1fr;gap:8px"><select name="res" style="${itInput}" aria-label="Reservation"><option value="">No booking</option><option value="need">To book</option><option value="booked">Booked</option></select><input name="conf" placeholder="Confirmation (optional)" style="${itInput}" aria-label="Booking details"></div>
  <div><button type="submit" class="btn small primary">Add</button></div></form></section>
 ${di?`<section class="filters"><span class="kicker">Swap the whole day</span><p class="hint">${fits.length?"These ready-made days fit this date. Swapping replaces the items above.":"None of the ready-made days fit this date."}</p>${fits.length?`<div class="chips">${fits.map(x=>`<button class="chip" data-itsample="${x.id}" data-itiso="${iso}">${esc(x.name)}</button>`).join("")}</div>`:""}
  ${edited&&ITIN_DRAFT[iso]?`<div><button class="linkbtn" data-itreset="${iso}">Reset this day to the draft</button></div>`:""}</section>`:""}
 <p class="hint">Times are suggestions from the opening hours in this guide. Holiday hours can differ; confirm the day before.</p>`}
function itinNextHTML(c,ti){const i=ti>=0&&ti<tripLen()?ti:ti<0?0:null;if(i==null)return null;const di=dayInfo(i),iso=isoOf(di.d),d=itinDay(iso);if(!d.items.length)return null;
 const today=ti===i,nxI=today?d.items.findIndex(x=>hmOf(x.t)>=c.n.h-0.25):0;
 const head=`<div class="dayhead"><span class="daynum">Day ${i+1}<small>of ${tripLen()}</small></span><span class="dayttl"><span class="kicker">${today?"Today":"First day"} · ${esc(di.label)}</span><b>${esc(d.title||"Your plan")}</b></span></div>`;
 const rows=d.items.map((x,k)=>{const r=resolveItem(x.ref),st=today&&nxI>=0&&k<nxI?"past":k===nxI?"next":"";return `<li class="${st}"><button ${r&&r.btn?r.btn:`data-itday="${iso}"`}><span class="lt">${esc(x.t)}</span><span class="ln"><b>${esc(itName(x))}</b>${k===nxI?`<span class="hint">${r?esc(r.kind):"Your plan"}${x.note?` · ${esc(x.note)}`:""}</span>`:""}${x.res==="need"?resPill(x):""}</span></button></li>`}).join("");
 return `<section class="daycard">${head}<ol class="dayline2">${rows}</ol>${today&&nxI<0?`<p class="hint">That's everything planned for today.</p>`:""}<div class="mc-btns"><button class="btn small" data-itday="${iso}">Edit the day</button><button class="btn small" data-itin>All ${tripLen()} days</button></div></section>`}
function itFormVals(f){const g=n=>(f.elements[n]&&f.elements[n].value||"").trim();return {t:g("t")||"12:00",title:g("title"),note:g("note"),res:g("res"),conf:g("conf")}}
document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(b.hasAttribute("data-itin")){ITEDIT=null;nav({v:"itin"});return}
 if(d.itday){ITEDIT=null;const f=d.itfocus;nav({v:"itday",iso:d.itday});if(f){ITEDIT=f;render();setTimeout(()=>{const el=document.getElementById("it-"+f);if(el)el.scrollIntoView({block:"center"})},30)}return}
 if(d.itedit){ITEDIT=d.itedit;render();setTimeout(()=>{const el=document.getElementById("it-"+d.itedit);if(el)el.scrollIntoView({block:"nearest"})},30);return}
 if(b.hasAttribute("data-itrename")){ITEDIT="__title";render();return}
 if(b.hasAttribute("data-itcancel")){ITEDIT=null;render();return}
 if(d.itdel){if(!confirm("Remove this item from the day?"))return;ITEDIT=null;itinEdit(d.itiso,x=>{x.items=x.items.filter(it=>it.id!==d.itdel)});return}
 if(d.itbooked){itinEdit(d.itiso,x=>{const it=x.items.find(y=>y.id===d.itbooked);if(it)it.res="booked"});return}
 if(d.itsample){const sd=DAYS.find(x=>x.id===d.itsample);if(!sd||!confirm(`Replace this day with "${sd.name}"?`))return;ITEDIT=null;
  itinEdit(d.itiso,x=>{x.title=sd.name;x.why=sd.summary;x.items=sd.steps.map(([t,ref,note],i)=>({id:"s"+Date.now().toString(36)+i,t,ref:ref?(ref.startsWith("food:")?"food:"+sd.area+":"+ref.slice(5):ref):"",title:ref?"":(/back/i.test(note||"")?"Getting back":"Getting there"),note:note||"",res:"",conf:""}))});return}
 if(d.itreset){if(!confirm("Undo your edits to this day and go back to the draft?"))return;ITEDIT=null;delete S.itin[d.itreset];save();render();return}});
document.addEventListener("submit",e=>{const f=e.target;if(!f.classList||!f.classList.contains("itform"))return;e.preventDefault();const v=itFormVals(f),dd=f.dataset;
 if(dd.ittitle){ITEDIT=null;itinEdit(dd.ittitle,x=>{x.title=v.title});return}
 if(dd.itnew){if(!v.title)return;itinEdit(dd.itnew,x=>{x.items.push({id:"u"+Date.now().toString(36),t:v.t,ref:"",title:v.title,note:v.note,res:v.res,conf:v.conf})});return}
 if(dd.itid){ITEDIT=null;itinEdit(dd.itiso,x=>{const it=x.items.find(y=>y.id===dd.itid);if(it)Object.assign(it,{t:v.t.replace(/^0(\d)/,"$1"),title:v.title,note:v.note,res:v.res,conf:v.conf})})}});
document.addEventListener("change",e=>{const t=e.target;if(t.id==="tripEnd"&&t.value){S.end=t.value;save();render()}});
function migrateTrip(){if(!S.start||S.start==="2026-12-28")S.start="2026-12-31";if(!S.end||S.end<S.start)S.end="2027-01-07";if(!S.itin)S.itin={}}

/* ===================== BOOT ===================== */
async function loadData(){
 if(window.__DATA__)return window.__DATA__;
 const get=u=>fetch(u).then(r=>{if(!r.ok)throw new Error(u+" "+r.status);return r.json()});
 const core=await get("data/core.json");
 const files=core.areas.filter(a=>a.file);
 const list=await Promise.all(files.map(a=>get("data/"+a.file)));
 const areas={};list.forEach(a=>areas[a.id]=a);
 try{core.stories=await get("data/stories.json")}catch(e){core.stories=null}
 try{core.verify=await get("data/verify.json")}catch(e){core.verify=null}
 return {core,areas};
}
function useData({core,areas}){
 CHECKED=core.checked;SRC=Object.assign(core.sources,BX_SRC);AREAS=core.areas;THREADS=core.threads||[];SEASON=core.season||null;BASICS=core.basics||null;DAYS=core.days||[];TRIPBOOK=core.tripBook||[];GLOSSARY=core.glossary||[];NIGHT=core.night||[];CTX=core.ctx||[];MOODS=core.ui.moods||[];INTS=core.ui.interests||[];buildTerms();TYPES=core.ui.foodTypes;STYPES=core.ui.siteTypes;PRICES=core.ui.prices;MEALS=core.ui.meals;
 AD=areas;STOPIDX={};SITEIDX={};WALKIDX={};
 for(const id in AD){const a=AD[id];Object.keys(a.stops).forEach(s=>STOPIDX[s]=id);a.sites.forEach(s=>SITEIDX[s.id]=id);a.walks.forEach(w=>WALKIDX[w.id]=id);(a.tours||[]).forEach(t=>TOURIDX[t.id]=id)}
 AR=AD[Object.keys(AD)[0]];
 if(typeof useStories==="function")useStories(core.stories||(window.__DATA__&&window.__DATA__.stories));
 VERIFY=((core.verify||(window.__DATA__&&window.__DATA__.verify))||{}).checks||[];CLAIMREG=null;
}
function registerSW(){if(window.__ARTIFACT__||!("serviceWorker" in navigator)||!/^https?:$/.test(location.protocol))return;const had=!!navigator.serviceWorker.controller;navigator.serviceWorker.addEventListener("controllerchange",()=>{if(had)showUpdateBar()});navigator.serviceWorker.register("sw.js").then(r=>{r.update().catch(()=>{});setInterval(()=>r.update().catch(()=>{}),30*60*1000)}).catch(()=>{})}
async function boot(){
 try{useData(await loadData())}catch(e){document.getElementById("main").innerHTML='<p class="empty">The guide\'s data could not load. If you opened index.html straight from your files, start a local server instead (see README).</p>';return}
 S=merge(Store.loadLocal());migrateTrip();
 if(S.route&&S.route.ildefonso===null)delete S.route.ildefonso;
 window.addEventListener("hashchange",applyHash);
 if(!location.hash&&S.last&&S.last!=="home"){try{location.hash=S.last}catch(e){}}
 applyHash();connect();registerSW();
}
boot();

function vWalkStart(){const w=walkById(cur().w),stops=walkStops(w),first=getStop(stops[0]),fn=new Footnotes();
 return `<section style="display:grid;gap:8px"><span class="kicker">Walk · ${esc(AR.name)}</span><h1>${esc(w.name)}</h1>
  <div class="startfacts"><span><b>${esc(w.time.replace(/^About /,""))}</b>time</span><span><b>${stops.length}</b>stops</span>${w.length?`<span><b>${esc(w.length)}</b>length</span>`:""}</div>
  <div class="article">${w.intro.map(([t])=>`<p>${esc(t)}</p>`).join("")}</div></section>
 ${w.q?`<section class="filters guideq"><span class="kicker">A question to carry</span><p class="gq">${esc(w.q)}</p><p class="hint">Keep it in mind as you go; the end of the walk comes back to it.</p></section>`:""}
 ${w.effort?`<section class="filters"><span class="kicker">Effort and comfort</span><dl class="logi">${w.effort.map(([k,t])=>`<dt>${esc(k)}</dt><dd>${esc(t)}</dd>`).join("")}</dl></section>`:""}
 ${ctxSection(ctxFor(stops),"The big history this walk sits inside. Read it once before you start; each stop then sticks to its own story.")}
 <div class="map">${mapSVG(w)}<div class="map-foot"><span>${esc(w.time)} · ${stops.length} stops</span><a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(w.mapsQuery)}" target="_blank" rel="noopener">Open in Google Maps ↗</a></div></div>
 <section class="filters"><span class="kicker">The route</span><ol class="route">${stops.map((x,j)=>{const st=getStop(x);return `<li><b>${esc(st.name)}</b><span class="hint">${esc(st.time||"")}${(w.optional||[]).includes(x)?" · optional":""}</span></li>`}).join("")}</ol></section>
 ${w.logistics&&w.logistics.length?`<section class="filters"><span class="kicker">Before you go</span><dl class="logi">${w.logistics.map(([k,t,src,tag])=>`<dt>${esc(k)}</dt><dd>${esc(t)}${fn.mark(src)} ${tagHTML(tag)}</dd>`).join("")}</dl></section>${fn.html()}`:""}
 <section class="filters startgo"><span class="kicker">Start at</span><h2>${esc(first.name)}</h2>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary big" data-walkgo="${w.id}">Start the walk</button><a class="btn" href="${dirURL(first)}" target="_blank" rel="noopener">Directions to the start ↗</a></div></section>`}
document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 if(d.found){S.found=S.found||{};const L=S.found[d.found]=S.found[d.found]||[],j=+d.fi,k=L.indexOf(j);if(k<0)L.push(j);else L.splice(k,1);save();const on=k<0;b.setAttribute("aria-pressed",on);b.querySelector(".fbox").textContent=on?"✓":"";return}
 if(d.walkgo){S.walkOn={w:d.walkgo,t:Date.now()};save();nav({v:"walk",w:d.walkgo,i:0});return}
 if(b.hasAttribute("data-walkmap")){S.walkMap=!S.walkMap;save();render();return}
 if(d.walkend){S.walkOn=null;save();const a=WALKIDX[d.walkend];useArea(a);areaTab="see";nav({v:"area",a});return}});

const _vTripNav=vTrip;vTrip=function(){return _vTripNav()+`<section class="filters"><span class="kicker">About this guide</span><p class="hint">Where every fact comes from, how claims are tagged, and when things were last checked.</p><div><button class="btn" data-go="sources:">Sources and checks</button></div></section>`};

/* Offline banner: the guide is cached, so say what still works */
function offlineBar(){let el=document.getElementById("offbar");const off=navigator.onLine===false;
 if(!off){if(el)el.remove();return}
 if(!el){el=document.createElement("div");el.id="offbar";el.className="offbar";el.setAttribute("role","status");document.body.appendChild(el)}
 el.textContent="You're offline. The whole guide still works; Ask the guide, the weather and new map areas need a connection."}
window.addEventListener("online",offlineBar);window.addEventListener("offline",offlineBar);setTimeout(offlineBar,0);

/* Your own photo per stop: kept in this browser only (IndexedDB), never uploaded */
const PDB={db:null,open(){if(this.db)return Promise.resolve(this.db);return new Promise((res,rej)=>{try{const r=indexedDB.open("cdmx-photos",1);r.onupgradeneeded=()=>r.result.createObjectStore("p");r.onsuccess=()=>{this.db=r.result;res(r.result)};r.onerror=()=>rej(r.error)}catch(e){rej(e)}})},
 tx(mode,fn){return this.open().then(db=>new Promise((res,rej)=>{try{const t=db.transaction("p",mode),q=fn(t.objectStore("p"));t.oncomplete=()=>res(q&&q.result);t.onerror=()=>rej(t.error)}catch(e){rej(e)}}))},
 get(k){return this.tx("readonly",s=>s.get(k))},put(k,v){return this.tx("readwrite",s=>s.put(v,k))},del(k){return this.tx("readwrite",s=>s.delete(k))}};
function photoSlotHTML(sid){if(typeof indexedDB==="undefined")return "";setTimeout(fillPhotos,0);
 return `<section class="myphoto" data-photo-sid="${sid}"><h2 class="lsec" id="your-photo">Your photo</h2><div class="myph-slot"></div><div class="mc-btns"><label class="btn small"><span class="myph-lbl">Add your photo</span><input type="file" accept="image/*" capture="environment" data-photoin="${sid}" class="vh"></label><button class="linkbtn" data-photodel="${sid}" hidden>Remove</button></div><p class="hint">Kept in this browser on this device only.</p></section>`}
const PHURL={};
function fillPhotos(){document.querySelectorAll("[data-photo-sid]").forEach(sec=>{const sid=sec.dataset.photoSid;
 PDB.get(sid).then(b=>{const slot=sec.querySelector(".myph-slot"),del=sec.querySelector("[data-photodel]"),lbl=sec.querySelector(".myph-lbl");if(!slot)return;
  if(PHURL[sid]){URL.revokeObjectURL(PHURL[sid]);delete PHURL[sid]}
  if(b){PHURL[sid]=URL.createObjectURL(b);slot.innerHTML=`<img class="myph" alt="Your photo of ${esc((getStop(sid)||{}).name||"this place")}" src="${PHURL[sid]}">`;del.hidden=false;lbl.textContent="Replace your photo"}
  else{slot.innerHTML="";del.hidden=true;lbl.textContent="Add your photo"}}).catch(()=>{sec.hidden=true})})}
function shrinkPhoto(file){return new Promise((res,rej)=>{const img=new Image(),u=URL.createObjectURL(file);img.onload=()=>{const m=1400,k=Math.min(1,m/Math.max(img.width,img.height)),c=document.createElement("canvas");c.width=Math.round(img.width*k);c.height=Math.round(img.height*k);c.getContext("2d").drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(u);c.toBlob(b=>b?res(b):rej(new Error("encode")),"image/jpeg",.82)};img.onerror=()=>{URL.revokeObjectURL(u);rej(new Error("That file isn't an image this browser can open."))};img.src=u})}
document.addEventListener("change",e=>{const t=e.target;if(!t.dataset||!t.dataset.photoin||!t.files||!t.files[0])return;const sid=t.dataset.photoin;
 shrinkPhoto(t.files[0]).then(b=>PDB.put(sid,b)).then(fillPhotos).catch(err=>{const sec=t.closest(".myphoto");if(sec){const p=document.createElement("p");p.className="hint";p.textContent="Couldn't save the photo: "+(err&&err.message||"storage is blocked in this browser")+".";sec.appendChild(p)}})});
document.addEventListener("click",e=>{const b=e.target.closest("[data-photodel]");if(!b)return;PDB.del(b.dataset.photodel).then(fillPhotos).catch(()=>{})});


/* ===================== BUILD YOUR DAYS =====================
   A day-by-day planner. Each trip day gets one to three areas; the planner lays out the walk stops
   in walking order, drops anything closed that weekday, fits stops to opening hours and the chosen
   pace, adds breakfast, lunch and dinner from the guide's food picks, and shows what's nearby and
   what forum travelers say about pairing those areas. Choices are stored in S.build by date (MM-DD). */
var BX_SRC={
 rdmar:{n:"Reddit r/MexicoCity, 'First timers in CDMX (March 2–7). Logistics check & itinerary feedback?' and replies (archived Feb 2026)",u:"https://reddit.sentinel-team.org/posts/1r7chkm/snapshots/2026-02-27T04%3A25%3A00.445591Z",t:"Forum"},
 rd6day:{n:"Reddit r/MexicoCity, '6 Day Itinerary Help' and replies (archived Mar 2026)",u:"https://reddit.sentinel-team.org/posts/1rkxxmi/snapshots/2026-03-05T08%3A51%3A47.494024Z",t:"Forum"},
 rdpace:{n:"Reddit r/MexicoCity, itinerary review thread for a trip from Tijuana, and replies (archived May 2026)",u:"https://reddit.sentinel-team.org/posts/1tizm4w/snapshots/2026-05-21T04%3A53%3A02.564225Z",t:"Forum"},
 rdfirst:{n:"Reddit r/MexicoCity, 'Recommendations for First Time Traveler to Mexico City' and replies (archived May 2026)",u:"https://reddit.sentinel-team.org/posts/1t13st9/snapshots/2026-05-02T02%3A46%3A21.811775Z",t:"Forum"}};
/* Forum advice, paraphrased. w(areas Set, dayInfo, dayIndex) decides when a note shows. */
var BX_NOTES=[
 {w:(A)=>A.has("coyo")&&A.has("sanangel"),t:"Several replies pair Coyoacán and San Ángel in one day. Commenters say Saturday is the best day for San Ángel, and Friday also works.",s:["rdmar","rd6day"]},
 {w:(A)=>A.has("sanangel")&&!A.has("coyo"),t:"Commenters suggest pairing San Ángel with Coyoacán. The flower market is small and quick; the time goes to Plaza San Jacinto and the museums.",s:["rdmar"]},
 {w:(A,di)=>A.has("sanangel")&&di.dow!==6&&di.dow!==5,t:"Commenters rate Saturday as the best day for San Ángel, with Friday next. Consider moving it.",s:["rdmar"]},
 {w:(A)=>A.has("coyo")&&A.has("south"),t:"Opinions split on Xochimilco. One reply rates a Coyoacán and Xochimilco day above a full day in Roma and Condesa; others say give Coyoacán the day and skip or shorten Xochimilco unless you want the party-boat atmosphere.",s:["rdfirst","rdmar"],g:"deb"},
 {w:(A)=>A.has("south"),t:"From Roma or Condesa, getting to Xochimilco can take one to two hours in traffic.",s:["rdpace"]},
 {w:(A)=>A.has("coyo"),t:"Casa Azul timed tickets can sell out weeks ahead. Book before you go.",s:["rdfirst","rdmar"]},
 {w:(A)=>A.has("chapul"),t:"Replies agree the castle and the Anthropology Museum together make a very long day; they're about a 30-minute walk apart. The usual advice: the castle at opening, then the museum. One visitor found about 2½ hours enough for a focused museum visit.",s:["rdpace","rdmar"]},
 {w:(A)=>A.has("chapul")&&!A.has("roma"),t:"One reply suggests pairing Chapultepec with Roma and Condesa rather than with Coyoacán or Xochimilco.",s:["rdfirst"]},
 {w:(A)=>A.has("roma"),t:"One commenter thinks half a day is enough for Roma and Condesa, which makes it a good partner for a museum morning.",s:["rdfirst"]},
 {w:(A,di)=>A.has("roma")&&di.dow===0,t:"On Sundays the streets around Parque México close to cars for cycling and running; commenters say skip the Uber that day.",s:["rd6day"]},
 {w:(A,di,i)=>A.has("teo")&&i===0,t:"Replies advise against Teotihuacan right after arriving. Move it later in the trip.",s:["rd6day"]},
 {w:(A)=>A.has("teo"),t:"Return traffic can stretch the drive back to about three hours, so don't plan a big evening across town afterward.",s:["rd6day","rdpace"]},
 {w:(A,di)=>A.has("teo")&&di.dow===1,t:"Teotihuacan is open every day, so commenters suggest it for a Monday, when most city museums are closed.",s:["rdfirst"]},
 {w:(A)=>A.has("centro"),t:"Pair the Alameda with the Zócalo and Bellas Artes on the same day, and don't treat the Templo Mayor as a quick stop; one commenter says you'd regret it.",s:["rdfirst"]},
 {w:(A)=>A.has("centro")||A.has("tlatelolco"),t:"The Basílica is close enough to downtown to pair with the Templo Mayor. Frida's house in Coyoacán is not.",s:["rd6day"]},
 {w:(A,di)=>A.has("centro")&&di.dow===1,t:"On Mondays the SEP's Rivera murals (Museo Vivo del Muralismo) are open while most museums aren't; they close Tuesdays instead.",s:["rdfirst"]},
 {w:(A,di,i)=>i===0,t:"After an overnight flight, commenters suggest a light first day: drop your bags at the hotel and stay local.",s:["rdmar"]}];
var BX_GENERAL=[
 {t:"The most common reply to posted itineraries: it's too much. One commenter suggests cutting 30–50% from each day, and others say to group sights by neighborhood because cross-town traffic eats hours.",s:["rdpace","rd6day"]},
 {t:"Most museums close on Mondays, including the Anthropology Museum and the castle. Teotihuacan is the usual Monday pick.",s:["rdfirst"]}];
/* Default five days; the suggester assigns them to dates. */
var BX_BUNDLES=[["centro"],["chapul"],["coyo","sanangel"],["teo"],["roma","reforma"]];
var BX_PACE={easy:[17,"Easy","Ends around 5 pm"],normal:[18,"Normal","Ends around 6 pm"],full:[19.5,"Pack it in","Until 7:30 pm, with extras"]};
let BXOPEN=null,BXCTR=null;

function bxDay(k){if(!S.build||typeof S.build!=="object")S.build={};return S.build[k]||(S.build[k]={areas:[],drop:[],add:[],meal:{}})}
function bxPeek(k){return (S.build||{})[k]||null}
function bxPace(){const p=(S.prefs&&S.prefs.pace)||"normal";return BX_PACE[p]?p:"normal"}
function bxCenters(){if(BXCTR)return BXCTR;BXCTR={};const by={};nowPlaces().forEach(p=>{(by[p.area]=by[p.area]||[]).push(p.ll)});
 for(const a in by){const l=by[a];BXCTR[a]=[l.reduce((s,x)=>s+x[0],0)/l.length,l.reduce((s,x)=>s+x[1],0)/l.length]}return BXCTR}
function bxNo(aid,di){return (AD[aid].closures||[]).filter(c=>c.lvl==="no"&&((c.dows&&c.dows.includes(di.dow))||(c.dates&&c.dates.includes(di.k))))}
function bxWarn(aid,di){return (AD[aid].closures||[]).filter(c=>c.lvl==="warn"&&((c.dows&&c.dows.includes(di.dow))||(c.dates&&c.dates.includes(di.k))))}
function bxTravel(a,b){const m=hav(a,b);if(m<1800)return {min:walkMin(m),mode:"walk",m};const km=m/1000;return {min:Math.round(km>20?20+km*1.4:12+km*3),mode:"ride",m}}
function bxTravelM(m){return m<1800?walkMin(m)+" min walk":"~"+Math.round(m>20000?20+m/1000*1.4:12+m/1000*3)+" min ride"}
const bxTravelText=tr=>tr.mode==="walk"?`${tr.min} min walk`:`~${tr.min} min by taxi or Uber (${(tr.m/1000).toFixed(1)} km, traffic permitting)`;
const bxHM=h=>{const H=Math.floor(h+1e-6),M=Math.round((h-H)*60/5)*5;return `${M===60?H+1:H}:${String(M===60?0:M).padStart(2,"0")}`};
function bxRanges(hours,dow){return (dow===0&&hours.sun)||(dow===6&&hours.sat)||hours.h}
function bxTypes(id){return (getStop(id)||siteById(id)||{}).types||[]}

/* Assign the default bundles to the five dates, avoiding closures and following forum advice. */
function bxScore(B,di,i){let s=0;B.forEach((a,j)=>{if(bxNo(a,di).length)s-=j===0?100:30});
 if(B.includes("teo")){if(i===0)s-=20;if(di.dow===1)s+=10}
 if(B.includes("sanangel")){if(di.dow===6)s+=15;else if(di.dow===5)s+=8}
 if(B.includes("roma")&&di.dow===0)s+=5;
 if(B.includes("chapul")&&di.dow===0)s-=5;
 if(i===0&&(B.includes("teo")||B.includes("coyo")))s-=6;
 return s}
function bxSuggest(){const D=tripIdx().map(dayInfo);let best=null;
 const perm=(arr,acc)=>{if(!arr.length){const sc=acc.reduce((s,b,i)=>s+bxScore(b,D[i],i),0);if(!best||sc>best.sc)best={sc,p:acc.slice()};return}
  arr.forEach((b,j)=>perm(arr.filter((_,x)=>x!==j),acc.concat([b])))};
 perm(BX_BUNDLES,[]);
 D.forEach((di,i)=>{const bd=bxDay(di.k);bd.areas=best.p[i].slice();bd.drop=[];bd.add=[];bd.meal={}})}

/* Pick a meal: open at h (or hours unknown), near the reference point, not already used on the trip. */
function bxFoodOpts(areas,h,dow,slot,ref){const out=[];
 areas.forEach(aid=>(AD[aid].food||[]).forEach(f=>{
  const t=f.types||[];
  if(slot!=="b"&&t.length===1&&t[0]==="Cafés and sweets")return;
  if(slot==="b"&&(t.includes("Fine dining")||t.includes("Bars and mezcal")))return;
  if(slot==="l"&&t.length===1&&t[0]==="Bars and mezcal")return;
  let st="unk";if(f.hours){if(f.days&&!f.days.includes(dow))return;st=f.hours.some(([a,b])=>h>=a&&h<b-0.5)?"open":"no"}
  if(st==="no")return;if(slot==="b"&&st==="unk"&&!t.includes("Cafés and sweets")&&!t.includes("Markets"))return;
  out.push({f,area:aid,st,d:ref&&f.ll?hav(ref,f.ll):9e9})}));
 const pen=x=>(x.st==="open"?0:1)+(slot!=="d"&&((x.f.types||[]).includes("Fine dining")||x.f.price>=4)?3:0);
 return out.sort((a,b)=>pen(a)-pen(b)||a.d-b.d)}
function bxMeal(bd,slot,areas,h,dow,ref,used){let o=bxFoodOpts(areas,h,dow,slot,ref);
 if(!o.length&&slot==="d")o=bxFoodOpts(["roma","centro"],h,dow,slot,null);
 if(!o.length)return null;const fresh=o.filter(x=>!used.has(x.f.name)),pool=fresh.length?fresh:o;
 const pick=pool[((bd.meal||{})[slot]||0)%pool.length];used.add(pick.f.name);return {...pick,n:pool.length}}

/* Lay out one day. Returns null if no areas are chosen. */
function bxPlan(i,used){const di=dayInfo(i),bd=bxPeek(di.k);if(!bd||!bd.areas||!bd.areas.length)return null;used=used||new Set();
 const pace=bxPace(),endH=BX_PACE[pace][0],P={};nowPlaces().forEach(p=>P[p.id]=p);
 const drop=new Set(bd.drop||[]),add=(bd.add||[]).filter(id=>P[id]&&!drop.has(id)),skipped=[],late=[];
 const closedDate=aid=>bxNo(aid,di).some(c=>c.dates&&c.dates.includes(di.k));
 const okHere=p=>{if(p.hours&&!p.hours.days.includes(di.dow)){skipped.push({p,why:`Closed ${DOWN[di.dow]}s`});return false}
  if(p.hours&&closedDate(p.area)){skipped.push({p,why:"Reported closed on this date"});return false}return true};
 /* backbone: each area's walk stops in their walking order */
 let seq=[];const inSeq=new Set();
 bd.areas.forEach(aid=>(AD[aid].walks||[]).forEach(w=>w.stops.forEach(sid=>{if((w.optional||[]).includes(sid)&&pace!=="full")return;const p=P[sid];if(!p||inSeq.has(sid)||drop.has(sid))return;inSeq.add(sid);if(okHere(p))seq.push(p)})));
 /* "Pack it in" adds the two extras that best match your interests, if they're close to the route */
 const extrasPool=nowPlaces().filter(p=>!inSeq.has(p.id)&&!drop.has(p.id)&&!add.includes(p.id));
 if(pace==="full"&&seq.length){extrasPool.filter(p=>bd.areas.includes(p.area)&&(!p.hours||p.hours.days.includes(di.dow))&&Math.min(...seq.map(q=>hav(q.ll,p.ll)))<900)
  .sort((a,b)=>intScore(bxTypes(b.id))-intScore(bxTypes(a.id))).slice(0,2).forEach(p=>add.push(p.id))}
 /* added places go where they cost the least extra walking */
 add.forEach(id=>{const p=P[id];if(!p||inSeq.has(id))return;inSeq.add(id);if(!okHere(p))return;
  if(!seq.length){seq.push(p);return}let bi=seq.length,bc=hav(seq[seq.length-1].ll,p.ll);
  for(let j=0;j<seq.length;j++){const c=j===0?hav(p.ll,seq[0].ll):hav(seq[j-1].ll,p.ll)+hav(p.ll,seq[j].ll)-hav(seq[j-1].ll,seq[j].ll);if(c<bc){bc=c;bi=j}}
  seq.splice(bi,0,{...p,added:true})});
 /* walk the day */
 const C=bxCenters(),cityRef=C.centro||[19.4326,-99.1332],first=seq[0];
 const out=[];let t=9,prev=null,lunch=false;
 const farStart=first&&hav(cityRef,first.ll)>20000;
 if(farStart){const tr=bxTravel(cityRef,first.ll);out.push({kind:"go",t:9-tr.min/60,txt:`Leave the city. ${bxTravelText(tr)} to ${AD[first.area].name}.`})}
 else{const b=bxMeal(bd,"b",[bd.areas[0]],8.5,di.dow,first&&first.ll,used);if(b)out.push({kind:"meal",slot:"b",lbl:"Breakfast",t:8.25,m:b})}
 const doLunch=(at,aid,ref)=>{const l=bxMeal(bd,"l",[aid].concat(bd.areas.filter(a=>a!==aid)),at,di.dow,ref,used);out.push({kind:"meal",slot:"l",lbl:"Lunch",t:at,m:l});lunch=true;return at+1};
 seq.forEach(p=>{const tr=prev?bxTravel(prev.ll,p.ll):null;let arr=t+(tr?tr.min/60:0);
  if(!lunch&&arr>=13.25){arr=doLunch(Math.max(13.25,t),prev?prev.area:p.area,prev?prev.ll:p.ll)+(tr?tr.min/60:0)}
  let r=null,cl=null;if(p.hours&&!p.outdoor){const rs=bxRanges(p.hours,di.dow)||[];r=rs.find(([a,b])=>b-arr>=0.5);if(!r){late.push({p,why:"Closes before you'd get there"});return}if(arr<r[0])arr=r[0];cl=r[1]}
  if(arr>=endH-0.1&&!p.added){late.push({p,why:`Doesn't fit before ${bxHM(endH)} at this pace`});return}
  let v=visitMins(p),fin=arr+v/60,short=false;if(cl&&fin>cl){fin=cl;short=true}
  out.push({kind:"place",p,t:arr,tr,v:Math.round((fin-arr)*60),short,cl});
  if(!lunch&&arr<13.25&&fin>14.25){const at=Math.max(13.25,arr+1.5);doLunch(at,p.area,p.ll);out[out.length-1].lbl="Lunch break";fin+=1}
  t=fin;prev=p});
 if(!lunch&&seq.length)t=doLunch(Math.max(t,13),prev?prev.area:bd.areas[0],prev&&prev.ll);
 const dAreas=bd.areas.slice().reverse();const dn=bxMeal(bd,"d",farStart?["roma","centro"]:dAreas,19.5,di.dow,farStart?null:prev&&prev.ll,used);
 if(dn)out.push({kind:"meal",slot:"d",lbl:"Dinner",t:Math.max(19.5,t+0.75),m:dn});
 /* nearby: places within ~12 minutes' walk of the route, best match first */
 const routeLL=seq.map(p=>p.ll);const near=routeLL.length?nowPlaces().filter(p=>!inSeq.has(p.id)&&(!p.hours||p.hours.days.includes(di.dow))).map(p=>({p,d:Math.min(...routeLL.map(l=>hav(l,p.ll)))})).filter(x=>x.d<1000)
  .sort((a,b)=>intScore(bxTypes(b.p.id))-intScore(bxTypes(a.p.id))||a.d-b.d).slice(0,5):[];
 const areaNear=Object.keys(C).filter(a=>!bd.areas.includes(a)).map(a=>({a,d:Math.min(...bd.areas.filter(x=>C[x]).map(x=>hav(C[x],C[a])))})).sort((x,y)=>x.d-y.d).slice(0,3);
 const A=new Set(bd.areas),notes=BX_NOTES.filter(n=>n.w(A,di,i));
 const removed=(bd.drop||[]).map(id=>P[id]).filter(Boolean);
 return {di,bd,out,skipped,late,near,areaNear,notes,removed,endT:t}}

function bxRowPlace(x,k){const p=x.p,meta=getStop(p.id)||siteById(p.id)||{};
 return `<li><span class="n">${bxHM(x.t)}</span><div style="display:grid;gap:4px;min-width:0">
  ${x.tr?`<span class="hint">${x.tr.mode==="walk"?"🚶":"🚕"} ${esc(bxTravelText(x.tr))}</span>`:""}
  <span class="kicker">${esc(AD[p.area].name)}${p.added?" · added":""}</span><h3>${esc(p.name)}</h3>
  ${meta.what||meta.summary?`<p class="hint">${esc(meta.what||meta.summary)}</p>`:""}
  <span class="meta"><span class="pill">~${x.v} min</span>${x.cl?`<span class="pill ${x.short?"warn":"ok"}">${x.short?`Closes ${bxHM(x.cl)}; shortened`:`Open until ${bxHM(x.cl)}`}</span>`:p.outdoor?`<span class="pill ok">Open-air</span>`:`<span class="pill">Hours not published</span>`}</span>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn small" ${p.open}>Open →</button><button class="btn small" data-bxdrop="${k}|${p.id}">Remove</button></div></div></li>`}
function bxRowMeal(x,k){const m=x.m;if(!m)return `<li><span class="n">${bxHM(x.t)}</span><div style="display:grid;gap:4px;min-width:0"><span class="kicker">${x.lbl}</span><p class="hint">No pick in the guide for this area at this hour. Try the Eat tab near you.</p></div></li>`;
 const f=m.f;return `<li><span class="n">${bxHM(x.t)}</span><div style="display:grid;gap:4px;min-width:0"><span class="kicker">${x.lbl} · ${esc(AD[m.area].name)}</span>
  <h3>${esc(f.name)} <span class="price">${PRICES[f.price-1]}</span></h3>${f.order?`<p class="hint">${esc(f.order.split(". ")[0])}</p>`:""}
  <span class="meta">${m.st==="open"?`<span class="pill ok">${esc(hoursText(f))}</span>`:`<span class="pill">Hours not published</span>`}${(f.pick&&f.pick.forum&&f.pick.forum.length)?`<span class="pill warn">Forum pick</span>`:""}</span>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn small" data-eatarea="${m.area}">Food in ${esc(AD[m.area].name)} →</button>${m.n>1?`<button class="btn small" data-bxmeal="${k}|${x.slot}">Another option</button>`:""}</div></div></li>`}
function bxDayHTML(i,used,fn){const di=dayInfo(i),pl=bxPlan(i,used),bd=bxPeek(di.k)||{areas:[]},k=di.k;
 const ev=seasonFor(k),open=BXOPEN===null?i===Math.max(0,Math.min(4,tripDayIndex())):BXOPEN===k;
 const sum=bd.areas.length?bd.areas.map(a=>AD[a].name).join(" + "):"Not planned yet";
 const chips=Object.keys(AD).map(a=>{const no=bxNo(a,di).length,on=bd.areas.includes(a);return `<button class="chip" aria-pressed="${on}" data-bxarea="${k}|${a}">${esc(AD[a].name)}${no?" · closures":""}</button>`}).join("");
 let body=`<div class="frow"><span class="kicker">Areas for this day (up to 3)</span><div class="chips">${chips}</div></div>`;
 body+=ev.length?`<p class="hint"><span class="pill warn">Season</span> ${ev.map(e=>esc(e.name)).join(", ")}. <button class="linkbtn" data-go="season:">What it means</button></p>`:"";
 if(pl){const flags=bd.areas.flatMap(a=>bxNo(a,di).concat(bxWarn(a,di)).map(c=>`<li><span class="pill ${c.lvl==="no"?"no":"warn"}">${c.lvl==="no"?"Closed":"Note"}</span> ${esc(c.t)}${fn.mark(c.s)}</li>`));
  if(flags.length)body+=`<ul class="nowlines">${flags.join("")}</ul>`;
  body+=`<ol class="thread dayline">${pl.out.map(x=>x.kind==="place"?bxRowPlace(x,k):x.kind==="meal"?bxRowMeal(x,k):`<li><span class="n">${bxHM(x.t)}</span><div style="display:grid;gap:4px;min-width:0"><span class="kicker">Getting there</span><p>${esc(x.txt)}</p></div></li>`).join("")}</ol>`;
  if(pl.late.length||pl.skipped.length)body+=`<div class="callout prac"><span class="lbl">Left out</span>${pl.skipped.map(s=>`<span>${esc(s.p.name)}: ${esc(s.why)}.</span>`).join("")}${pl.late.map(s=>`<span>${esc(s.p.name)}: ${esc(s.why)}. <button class="linkbtn" data-bxadd="${k}|${s.p.id}">Keep it anyway</button></span>`).join("")}</div>`;
  if(pl.removed.length)body+=`<p class="hint">Removed: ${pl.removed.map(p=>`${esc(p.name)} <button class="linkbtn" data-bxundrop="${k}|${p.id}">Put back</button>`).join(" · ")}</p>`;
  if(pl.near.length)body+=`<div class="frow"><span class="kicker">Also near your route</span>${pl.near.map(x=>`<div class="nowitem" style="display:grid;gap:4px"><span class="nowname">${esc(x.p.name)}</span><span class="hint">${esc(AD[x.p.area].name)} · ${walkMin(x.d)} min walk from your route${intScore(bxTypes(x.p.id))>=2?" · matches your interests":""}</span><span style="display:flex;gap:8px"><button class="btn small primary" data-bxadd="${k}|${x.p.id}">Add</button><button class="btn small" ${x.p.open}>Open →</button></span></div>`).join("")}</div>`;
  if(pl.areaNear.length&&bd.areas.length<3)body+=`<div class="frow"><span class="kicker">What's around</span><div class="chips">${pl.areaNear.map(x=>`<button class="chip" data-bxarea="${k}|${x.a}">+ ${esc(AD[x.a].name)} · ${bxTravelM(x.d)}</button>`).join("")}</div><span class="hint">Distances are between area centers.</span></div>`;
  if(pl.notes.length)body+=`<div class="callout voices"><span class="lbl">What Reddit travelers say</span><ul>${pl.notes.map(n=>`<li>${esc(n.t)}${fn.mark(n.s)}${n.g?" "+tagHTML(n.g):""}</li>`).join("")}</ul></div>`;
  body+=`<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn small" data-bxclear="${k}">Clear this day</button></div>`}
 else body+=`<p class="hint">Pick an area above, or use “Suggest a plan” at the top.</p>`;
 return `<details class="filters bxday" data-bxk="${k}" ${open?"open":""}><summary style="cursor:pointer;display:grid;gap:2px;list-style:none"><span class="kicker">Day ${i+1} · ${esc(di.label)}</span><b style="font-size:18px">${esc(sum)}</b>${pl?`<span class="hint">${pl.out.filter(x=>x.kind==="place").length} stops · done by about ${bxHM(pl.endT)}</span>`:""}</summary><div style="display:grid;gap:14px;margin-top:12px">${body}</div></details>`}
function vBuild(){const fn=new Footnotes(),used=new Set(),pace=bxPace();
 const days=tripIdx().map(i=>bxDayHTML(i,used,fn)).join("");
 return `<section style="display:grid;gap:8px"><span class="kicker">Your trip</span><h1>Build your days</h1>
  <p class="lede muted">Choose areas for each date. The planner orders the stops by walking distance, skips what's closed that day, fits the rest to opening hours and your pace, and adds meals from the guide's food picks.</p></section>
 <section class="filters"><span class="kicker">Pace</span><div class="chips">${Object.entries(BX_PACE).map(([k,v])=>`<button class="chip" aria-pressed="${pace===k}" data-bxpace="${k}">${esc(v[1])}</button>`).join("")}</div><span class="hint">${esc(BX_PACE[pace][2])}. Your interests (set on Home) decide which extras come first.</span>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn small primary" data-bxsuggest>Suggest a plan for all 5 days</button><button class="btn small" data-nav="trip">Change dates</button></div>
  <span class="hint">Suggest replaces what you've picked. It avoids closures, keeps Teotihuacan off day one, and puts San Ángel on a Friday or Saturday when it can.</span></section>
 <div class="callout voices"><span class="lbl">Before you plan: what Reddit travelers say</span><ul>${BX_GENERAL.map(n=>`<li>${esc(n.t)}${fn.mark(n.s)}</li>`).join("")}</ul></div>
 ${days}
 <p class="hint">Times are estimates: walking at an easy pace, rides as rough taxi times. Hours come from the guide's sources; holiday hours can differ.</p>${fn.html()}`}

document.addEventListener("toggle",e=>{const d=e.target;if(d.classList&&d.classList.contains("bxday")&&d.open)BXOPEN=d.dataset.bxk},true);
document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=b.dataset;
 const kp=v=>v.split("|");
 if(d.bxarea){const [k,a]=kp(d.bxarea),bd=bxDay(k),j=bd.areas.indexOf(a);if(j>=0)bd.areas.splice(j,1);else{if(bd.areas.length>=3)bd.areas.shift();bd.areas.push(a)}BXOPEN=k;save();render();return}
 if(d.bxdrop){const [k,id]=kp(d.bxdrop),bd=bxDay(k);bd.add=(bd.add||[]).filter(x=>x!==id);if(!bd.drop.includes(id))bd.drop.push(id);BXOPEN=k;save();render();return}
 if(d.bxundrop){const [k,id]=kp(d.bxundrop),bd=bxDay(k);bd.drop=bd.drop.filter(x=>x!==id);BXOPEN=k;save();render();return}
 if(d.bxadd){const [k,id]=kp(d.bxadd),bd=bxDay(k);bd.drop=(bd.drop||[]).filter(x=>x!==id);if(!bd.add.includes(id))bd.add.push(id);BXOPEN=k;save();render();return}
 if(d.bxmeal){const [k,sl]=kp(d.bxmeal),bd=bxDay(k);bd.meal=bd.meal||{};bd.meal[sl]=(bd.meal[sl]||0)+1;BXOPEN=k;save();render();return}
 if(d.bxclear){delete S.build[d.bxclear];BXOPEN=d.bxclear;save();render();return}
 if(b.hasAttribute("data-bxsuggest")){bxSuggest();BXOPEN=null;save();render();return}
 if(d.bxpace){S.prefs=S.prefs||{ints:[],pace:"normal",depth:"medium"};S.prefs.pace=d.bxpace;save();render();return}});

function bxPlanAt(i){const u=new Set();let r=null;for(let j=0;j<=i;j++)r=bxPlan(j,u);return r}
