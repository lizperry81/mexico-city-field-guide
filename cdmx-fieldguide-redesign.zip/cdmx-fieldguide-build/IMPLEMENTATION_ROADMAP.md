# Mexico City Field Guide — implementation roadmap

**Product direction:** an independent, evidence-led learning guide and travel companion. The product should help a traveler interpret the city, not merely rank attractions.

**Implementation status:** first editorial/learning-experience milestone implemented in this codebase. This document separates completed work from recommended future work. No backend, account system, deployment, or third-party service has been provisioned.

## What this codebase is

The supplied project is a static, vanilla-JavaScript application:
- `index.html` is the shell and loads scripts in dependency order.
- `js/app.js` owns navigation, shared state, rendering, and event delegation.
- `js/stories.js`, `js/field.js`, and `js/journal.js` own the core learning experiences.
- `js/integrity.js` and `js/checks.js` implement source/claim integrity and editorial tooling.
- `data/core.json`, nine area files, and `data/stories.json` contain structured content.
- `js/storage.js` provides local storage and an optional Claude-account adapter.
- `js/ai.js` currently supports Claude-hosted sampling and a direct browser-to-Anthropic API-key flow.
- `sw.js` caches app assets and browsed map tiles.

Do not migrate frameworks as a prerequisite. Keep the JSON-first model while the content corpus is edited by a small team. Introduce a backend only when shared contributions, secure AI access, or multi-device accounts are actually required.

## Verified baseline

The supplied archive contains:
- 9 geographic areas.
- 324 registered sources.
- 1,145 historical/cultural claims.
- 70 claims marked debated and 42 marked uncertain.
- 14 editorial stories, 3 field missions, and 4 historical threads.
- Existing Stories, Field, Journal, Getting Around, Ask the Guide, map, trip, and integrity/research surfaces.
- Local-device journal and community persistence, IndexedDB photo storage, service-worker caching.

The included `scripts/check.mjs` was run successfully. It passed source resolution, claim/source-or-Unknown coverage, the no-forum/no-travel-blog-as-fact rule, and stop/walk structural checks. It also surfaced thin content, unused sources, and established claims whose only support is journalism. These are review queues, not proof that every claim is factually correct.

All JavaScript files passed `node --check`. The Playwright flow/integrity browser tests could not run because Playwright is not installed in the supplied environment. No live source-link audit was performed.

## Implemented in this milestone

### 1. Inquiry-led home

`js/stories.js` now frames the home screen around a big question and its linked investigation. It includes:
- Editorial cover and product principle.
- Daily investigation with a direct story action.
- Relevant place links drawn from the selected story's existing place references.
- Continue-reading shelf.
- Ask the Guide prompt and existing mode chips.
- Related investigations.
- Editorial story index.
- Featured Field Mission with progress.
- Walks, time machine, eras, and quick links.

It reuses existing story and place data rather than inventing new historical claims.

### 2. Reflective Field Missions

`js/journal.js` now provides:
- Mission learning outcome.
- Observation progress indicator.
- Progressive hints, hidden until requested.
- Existing per-observation notes and photo support.
- A mission-level reflection saved in the existing local journal.
- Completion feedback.

`data/stories.json` now includes an outcome and reflection prompt for each of the three existing missions. These are learning prompts, not additional historical claims.

### 3. Visual system and offline cache

`styles.css` adds responsive editorial homepage and mission styling while preserving the existing visual language. `sw.js` cache version is bumped so deployed clients fetch the revised assets.

## What is still incomplete

- Human editorial review: a workflow/status field is not the same as an independently recorded human review.
- Practical verification: `data/verify.json` has no actual verification records.
- Research coverage: existing thin spots and journalism-only supports remain.
- Community: submissions are local to the device; there is no shared moderation service or contributor identity.
- AI security: the standalone browser path stores a user API key in local storage and calls the provider directly. This is not an appropriate production architecture for a public multi-user product.
- Offline: static assets and browsed map tiles are cached, but there is no deliberate offline content pack manager or clear offline readiness indicator.
- Cross-device journal sync: not implemented outside the optional Claude account adapter.
- Accessibility: no full keyboard, screen-reader, contrast, or reduced-motion audit has been completed.

## Prioritized backlog

Effort estimates are relative engineering estimates for one experienced developer, excluding research/editorial labor and deployment procurement.

| Priority | Work | Effort | Dependency | Acceptance criteria |
|---|---|---:|---|---|
| P0 | Human editorial review + claim review history | M | Claim/source registry | Every reviewed claim has reviewer, timestamp, decision, notes, and cited evidence; immutable review history |
| P0 | Practical verification workflow | M | `data/verify.json` schema | Each changing fact has underlying source, exact check date, result, verifier, and next review; UI never invents a verified date |
| P0 | Secure AI backend | L | Hosting/provider choice | No provider secret or user API key required in browser for production; server-side rate limits, quotas, logging minimization, retrieval, and citation validation |
| P1 | Claim-level evidence model v2 | M–L | Data migration plan | Separate classification from source type, provenance, confidence, review status, and claim-source relationship |
| P1 | Research desk queues | M | Review history + verification schema | Editors can filter claims/articles by missing evidence, conflicting evidence, stale practical data, and review state |
| P1 | Shared community field notes | L | Backend, auth, privacy policy | Submissions are server-backed, attributed/pseudonymous, reportable, moderated, and separate from historical claims |
| P1 | Story/destination cross-linking | M | Existing place/story IDs | Every story and destination exposes related investigations, missions, routes, and places where references exist |
| P1 | Offline content packs | M | Cache manifest/content model | User can save an area/story pack and see what is and isn't available offline |
| P2 | Journal export | M | Journal data model | User can export a readable, illustrated trip journal; private by default |
| P2 | Coverage expansion | L editorial | Research priorities | Thin areas expanded with primary/academic/institutional research and reviewed before publication |
| P2 | Accessibility and field usability | M | UI stabilization | Keyboard, screen reader, focus, touch target, contrast, text scaling, and low-connectivity tests pass |
| P2 | Product analytics | M | Privacy design | Aggregate, consent-aware metrics identify which stories/missions help users learn without collecting sensitive location trails |

## Evidence model v2

Keep evidence classification separate from source type and editorial workflow.

Recommended claim fields:
- `claim_id`: stable identifier.
- `statement`: smallest meaningful factual proposition.
- `classification`: `established`, `scholarly_debate`, `attributed_tradition`, or `uncertain`.
- `confidence`: editorial assessment such as `high`, `moderate`, `low`, with a written rationale.
- `sources[]`: source ID, relation (`supports`, `challenges`, `contextualizes`), evidence type, exact page/passage/record, and access date.
- `attributions[]`: community/tradition/author attribution where applicable.
- `limitations`: what the evidence cannot establish.
- `review_status`: `unreviewed`, `researching`, `fact_checked`, `editor_review`, `approved`, `needs_revision`.
- `review_history[]`: actor, timestamp, action, rationale, version.
- `last_reviewed_at`, `next_review_at`.

Do not encode a colonial written source as automatically more authoritative than Indigenous oral history. Evaluate evidence in context: provenance, transmission, purpose, temporal distance, corroboration, community authority, material evidence, and the specific question being asked. Oral and traditional accounts should be attributed and interpreted on their own terms, not flattened into a generic "folklore" category.

Keep these information classes separate:
1. Historical/cultural claims.
2. Editorial interpretation and recommendations.
3. Community experience and visitor reports.
4. Changing practical facts.
5. AI-generated explanations.

A visitor report may support "several visitors report a long queue" but cannot support an ancient historical claim. An official venue page may support today's opening hours but not necessarily a contested historical interpretation.

## Recommended architecture evolution

### Keep now
- Static app shell and vanilla JS.
- JSON content for editorial stories and area data.
- Existing stable place/story/thread IDs.
- Existing service worker and IndexedDB for local-first experience.
- Existing integrity checks as pre-publication quality gates.

### Add next
- A versioned content schema and migration validator.
- A review-history data file initially, then a small authenticated editorial API when multiple editors are needed.
- A `PracticalFact` record distinct from historical `Claim`.
- A service layer in front of storage so local and remote adapters share one interface.
- A backend AI endpoint that owns provider credentials and retrieval.
- Server-side community submissions and moderation queue.
- Content build step that validates JSON and generates a searchable claim index.

### Security and privacy requirements
- Never ship provider secrets in static files.
- Treat browser local storage as accessible to scripts running in the origin; do not describe it as a secure vault.
- Avoid storing location histories by default.
- Keep private journal entries private and exportable/deletable.
- Validate and sanitize user-generated text and uploaded images.
- Add rate limits, abuse reporting, moderation audit trail, and retention policy before opening community submissions.
- Do not log raw private conversations or precise location unless necessary and explicitly disclosed.

## Phased implementation plan

### Phase 1 — Editorial learning MVP (implemented in this build)
**Goal:** make the app feel like a field guide and learning companion from the first screen.

Deliverables:
- Inquiry-led homepage.
- Story-to-place links.
- Mission outcomes, progress, hints, reflection.
- Responsive styling and service-worker version bump.

Acceptance:
- Existing story/place/mission routes still use the current router.
- All new controls use existing event delegation.
- Existing journal data remains backward-compatible.
- Content integrity checks pass.
- JavaScript syntax checks pass.

### Phase 1.1 — Editorial quality gate
**Goal:** ensure what the app teaches is defensible.

Deliverables:
- Claim/source relationship schema.
- Human review history.
- Practical fact verification records.
- Research Desk queues.
- Explicit source passage/page references.

Acceptance:
- No claim is marked human-reviewed without reviewer and timestamp.
- No practical fact displays "verified" without an actual record.
- A reviewer can see supporting and challenging evidence.
- Automated checks and human editorial approval remain distinct.

### Phase 2 — Contextual field learning
**Goal:** make place, story, and observation one connected experience.

Deliverables:
- Destination page reading levels and consistent editorial template.
- Missions linked to destination, story, and walk records.
- Context-aware route narrative.
- Journal reflection timeline and export.

Acceptance:
- A user can start with a question, visit a linked place, complete an observation, and find it in their journal.
- Each factual passage retains its source trail.

### Phase 3 — Secure intelligence and shared community
**Goal:** support multiple travelers without compromising trust.

Deliverables:
- Backend AI retrieval and citation verification.
- Shared field-note database.
- Contributor controls and moderation.
- Account/backup model and privacy controls.

Acceptance:
- Browser contains no provider secret.
- AI claims cite retrieved guide evidence or are explicitly marked external/uncertain.
- Community notes cannot silently enter the historical claim registry.
- Users can delete or export their own contributions.

### Phase 4 — Offline and travel operations
**Goal:** make the guide dependable while walking around the city.

Deliverables:
- Area/story offline packs.
- Visible offline status.
- Verified transit/practical data.
- Accessibility audit and low-connectivity behavior.

Acceptance:
- Saved guide content opens without network.
- Dynamic information is clearly labeled unavailable when offline rather than presented as current.
- Critical interactions remain usable on a small phone.

## First recommended follow-up milestone

Implement **Phase 1.1: Editorial quality gate** before expanding the historical corpus or building a public community.

Reason: the app already has a substantial amount of content. The highest leverage is making it possible to know exactly what is supported, what is debated, what has been reviewed by a person, and what practical information is current.

## Decisions required before backend implementation

These cannot be safely inferred from the static archive:
1. Hosting target and whether the app should remain static/PWA or move to a hosted application.
2. Whether you want public accounts, private accounts, or pseudonymous community contributions.
3. Who will perform human editorial review and whether a second reviewer is required for sensitive/contested topics.
4. Whether users should be able to use Ask the Guide without bringing their own API key, which implies an operating budget and backend provider account.
5. Data retention and privacy policy for journal photos, location, AI questions, and community submissions.
